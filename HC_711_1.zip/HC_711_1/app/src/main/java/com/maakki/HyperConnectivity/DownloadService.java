package com.maakki.HyperConnectivity;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class DownloadService extends IntentService {
    //private final String url_download="http://152.101.178.115:8081/download.aspx";
    public static final int UPDATE_PROGRESS = 8344;
    //private String file_name="",path;
    public DownloadService() {
        super("DownloadService");
    }
    @Override
    protected void onHandleIntent(Intent intent) {
        String url_download=staticVar.Server_url + "download.aspx";
        String file_name="",path="";
        //String url_download = intent.getStringExtra("url_download");
        //String urlToDownload = "https://share.weiyun.com/5xGc1UD";
        file_name = intent.getStringExtra("file_name");
        ResultReceiver receiver = (ResultReceiver) intent.getParcelableExtra("receiver");
        try {
            //create url and connect
            URL url = new URL(url_download);
            URLConnection connection = url.openConnection();
            //connection.setRequestProperty("Accept-Encoding", "identity"); // <--- Add this line

            //int fileLength = connection.getContentLength(); // i get negetive length
            int fileLength = 1024*1024*15;
            // this will be useful so that you can show a typical 0-100% progress bar
            // download the file
            InputStream input = new BufferedInputStream(connection.getInputStream());
            path = "/sdcard/HyperConn/" + file_name;
            OutputStream output = new FileOutputStream(path);

            byte data[] = new byte[1024*1024*16];
            long total = 0;
            int count;
            while ((count = input.read(data)) != -1) {
                total += count;

                // publishing the progress....
                Bundle resultData = new Bundle();
                resultData.putInt("progress", (int) (total * 100 / fileLength));
                receiver.send(UPDATE_PROGRESS, resultData);
                output.write(data, 0, count);
            }
            // close streams
            output.flush();
            output.close();
            input.close();

        } catch (IOException e) {
            //e.printStackTrace();
        }

        Bundle resultData = new Bundle();
        resultData.putInt("progress", 100);
        resultData.putString("path", path);
        receiver.send(UPDATE_PROGRESS, resultData);
    }
    private void Invoke_BlockchainBroadcasting(String mess){
        Intent i = new Intent("INVOKE_BlockChain_Broadcasting");
        mess+="\n";
        i.putExtra("What", mess);
        sendBroadcast(i);
    }

}
