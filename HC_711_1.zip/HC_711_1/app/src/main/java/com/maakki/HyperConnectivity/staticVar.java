package com.maakki.HyperConnectivity;

//靜態參數 / 全域參數 設置(不可變更內容之參數)
public class staticVar {
    public static final String Server_url = "http://152.101.178.115:8081/";  //線上Server的位址
    public static final String APP_dir = "HyperConn";     //APP的目錄

    //public static String myHCID=Utils.setStaticHCID();
    public static String myHCID = "";
    public static String myStrPrivateKey = "";

    //region APP 緩存Key
    public static final String SPKey24 = "Last_getCB_Time";
    public static final String SPKey25 = "language";
    public static final String SPKey26 = "Last_HCtoPCB_Time";
    public static final String SPKey27 = "Last_checkData_Time";
    public static final String SPKey28 = "account_name";
    public static final String SPKey29 = "account_no";
    public static final String SPKey30 = "bank_name";
    public static final String SPKey31 = "bank_branch";

    public static final String SPKey100 = "HCID";
    public static final String SPKey101 = "strPrivateKey";
    public static final String SPKey102 = "strPublicKey";
    public static final String SPKey103 = "APK_link";
    public static final String SPKey104 = "Introducer";
    public static final String SPKey105 = "nickname";
    public static final String SPKey106 = "photo_realpath";
    public static final String SPKey107 = "Register_Time";
    public static final String SPKey108 = "service_term_time";
    //endregion

}
