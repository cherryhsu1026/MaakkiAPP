package com.maakki.HyperConnectivity;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ResultReceiver;
import android.os.StatFs;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.content.FileProvider;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Base64OutputStream;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

//import com.blikoon.qrcodescanner.QrCodeActivity;

public class HyperConnActivity extends Activity {
    //region 各項參數設置
    //private static final int REQUEST_CODE_QR_SCAN = 49374; //for QRCode recall,Don't delete it!
    //private static final int REQUEST_CALL_QRCODE_READER = 1;
    //private final int REQUEST_NEWAPK_BROADCAST = 102;
    //private final int REQUEST_REGISTRATION = 49374;
    private final int REQUEST_CODE_TAKE_PHOTO = 12;
    private final int PHOTO_REQUEST_CUT = 15;// 結果
    //private int code_stop_message=false;
    private String link_weiyun;
    ImageView iv_statistics, iv_titleIMG, iv_memberlist, iv_sharetext, iv_bluetooth, iv_notify_newapk, iv_scancall, iv_blocktest, iv_QRcode, iv_share, iv_more, iv_setting, iv_phone, iv_block;
    TextView tv_CR, tv_HC, tv_CB, tv_msg, tv_connecting;
    //String FILE_DIR = "HyperConn";

    String FILE_QRcode = "QRcode_HCID";
    String url_download, APK_link, introducer, nickname, filename, strPublickey;
    private Bitmap icon_bitmap = null;
    File tmpFile;
    LinearLayout ll_share, ll_admin;
    String realPath, block_message, phone_message, content_title = "";//, apkPath;
    Context context;
    ConnectivityBenifitDAO cbDAO;
    View view;
    String HCID, apk_name, device_id;
    private boolean
            is_Dialog_Display = false,
            AlreadyRegistered = false;
    //private boolean isAdmin = false;
    private ScrollView scrollView;
    //private static final int REQUEST_CODE_QR_SCAN = 101;
    BroadcastReceiver receiver, receiver1, receiver2, receiver3, receiver4, receiver5, receiver6;
    // declare the dialog as a member field of your activity
    ProgressDialog mProgressDialog;
    //no_page 0:phone, 1:block, 2:share, 3:statistics

    private int no_page = 1;
    //endregion

    //region onCreate方法 Activity 在建立時會執行onCreate 方法 ，當Activity finish()後，再重新呼叫此頁 onCreate 才會再被執行，否則單純跳頁是不會再執行onCreate
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hyperconn);
        context = this;
        Log.e("cherry", "HyperConnectivity.class onCreate方法");
        //setLocale();
        HCID = "";
        content_title = Utils.getCurrentTime();
        link_weiyun = getResources().getString(R.string.link_weiyun);
        //is_Share_on = false;
        cbDAO = new ConnectivityBenifitDAO(context);
        introducer = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key104, "");
        realPath = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key106, "");
        nickname = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key105, "");
        //region 設定各元件的click 動作
        tv_msg = findViewById(R.id.tv_msg);
        tv_connecting = findViewById(R.id.connecting);
        tv_HC = findViewById(R.id.tv_HC);
        tv_HC.setOnClickListener((View view) -> {
            tv_HC.setVisibility(View.INVISIBLE);
            Intent i = new Intent(HyperConnActivity.this, HCList.class);
            startActivity(i);
        });

        tv_HC.setOnClickListener(view -> {
            tv_HC.setVisibility(View.INVISIBLE);
            Intent i = new Intent(HyperConnActivity.this, HCList.class);
            HyperConnActivity.this.startActivity(i);
        });
        tv_CB = findViewById(R.id.tv_CB);
        tv_CB.setOnClickListener((View view) -> {
            tv_CB.setVisibility(View.INVISIBLE);
            Intent i = new Intent(HyperConnActivity.this, CBList.class);
            startActivity(i);

        });
        tv_CR = findViewById(R.id.tv_CR);
        tv_CR.setOnClickListener((View view) -> {
            tv_CR.setVisibility(View.INVISIBLE);
            Intent i = new Intent(HyperConnActivity.this, CB_OrderList.class);
            startActivity(i);

        });
        scrollView = findViewById(R.id.scrollView);
        iv_phone = findViewById(R.id.iv_phone);
        phone_message = "";
        iv_phone.setOnClickListener((View view) -> {
            no_page = 0;
            //is_Share_on = false;
            iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_green_18dp));
            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_white_18dp));
            iv_statistics.setImageDrawable(getResources().getDrawable(R.drawable.baseline_equalizer_white_18dp));
            scrollView.setVisibility(View.VISIBLE);
            ll_share.setVisibility(View.GONE);
            if (!phone_message.isEmpty()) {
                tv_msg.setText(phone_message);
                tv_msg.setVisibility(View.VISIBLE);
                tv_connecting.setVisibility(View.GONE);
            } else {
                tv_msg.setVisibility(View.GONE);
                tv_connecting.setVisibility(View.VISIBLE);
            }

        });
        block_message = "";
        iv_block = findViewById(R.id.iv_block);
        iv_block.setOnClickListener((View view) -> {
            //is_Share_on = false;
            no_page = 1;
            scrollView.setVisibility(View.VISIBLE);
            ll_share.setVisibility(View.GONE);
                /*if (code_stop_message) {
                    code_stop_message = false;
                    iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_white_18dp));
                } else {
                    code_stop_message = true;
                    iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_green_18dp));
                }*/
            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_green_18dp));
            iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_white_18dp));
            iv_statistics.setImageDrawable(getResources().getDrawable(R.drawable.baseline_equalizer_white_18dp));
            if (!block_message.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                sb.append(content_title).append("\n\n").append(block_message);
                tv_msg.setText(sb.toString());
                //tv_msg.setText(content_title+"\n\n"+block_message);
                tv_msg.setVisibility(View.VISIBLE);
                tv_connecting.setVisibility(View.GONE);
            } else {
                tv_msg.setVisibility(View.GONE);
                tv_connecting.setVisibility(View.VISIBLE);
            }

        });
        iv_share = findViewById(R.id.iv_share);
        ll_share = findViewById(R.id.ll_share);
        iv_QRcode = findViewById(R.id.iv_QRcode);
        iv_scancall = findViewById(R.id.iv_scancall);
        iv_share.setOnClickListener((View view) -> {
            no_page = 2;
            //is_Share_on = true;
            iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_green_18dp));
            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_white_18dp));
            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_white_18dp));
            iv_statistics.setImageDrawable(getResources().getDrawable(R.drawable.baseline_equalizer_white_18dp));
            scrollView.setVisibility(View.GONE);
            ll_share.setVisibility(View.VISIBLE);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bit = null;
            try {
                bit = encoder.encodeBitmap(HCID, BarcodeFormat.QR_CODE,
                        120, 120);
                iv_QRcode.setImageBitmap(bit);
            } catch (WriterException e) {
                //e.printStackTrace();
            }
            //String file_path = Environment.getExternalStorageDirectory().getAbsolutePath() +
            //        "/PhysicsSketchpad";
            File file = Utils.getDevicesDir(context, FILE_QRcode);
            FileOutputStream fOut;
            try {
                fOut = new FileOutputStream(file);
                if (bit != null)
                    bit.compress(Bitmap.CompressFormat.PNG, 85, fOut);
                fOut.flush();
                fOut.close();
            } catch (Exception e) {
                Log.e("cherry", e.toString());
            }

        });
        iv_sharetext = findViewById(R.id.iv_sharetext);
        iv_sharetext.setOnClickListener(view -> HyperConnActivity.this.share_text());
        iv_bluetooth = findViewById(R.id.iv_bluetooth);
        iv_bluetooth.setOnClickListener(view -> HyperConnActivity.this.share_bluetooth());
        iv_statistics = findViewById(R.id.iv_statistics);
        iv_statistics.setOnClickListener((View view) -> {
            no_page = 3;
            ll_share.setVisibility(View.GONE);
            iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_white_18dp));
            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_white_18dp));
            iv_statistics.setImageDrawable(getResources().getDrawable(R.drawable.baseline_equalizer_green_18dp));
            scrollView.setVisibility(View.VISIBLE);
            Async_getStatistics getStatisticsTask = new Async_getStatistics();
            getStatisticsTask.execute();
            tv_msg.setVisibility(View.VISIBLE);
            tv_connecting.setVisibility(View.GONE);
        });
        ll_admin = findViewById(R.id.ll_admin);
        iv_notify_newapk = findViewById(R.id.iv_notify_newapk);
        iv_notify_newapk.setOnClickListener((View view) -> {
            Drawable start_drawable = getResources().getDrawable(R.drawable.baseline_volume_up_green_18dp);
            Drawable end_drawable = getResources().getDrawable(R.drawable.baseline_volume_up_white_18dp);
            Utils.ImageViewAnimatedChange(context, iv_notify_newapk, start_drawable, end_drawable);
            showNewAPKBroadcastDialog();
        });
        //iv_addSponsor = (ImageView) findViewById(R.id.iv_addSponsor);
        iv_blocktest = findViewById(R.id.iv_blocktest);
        iv_blocktest.setOnClickListener((View view) -> {
            Drawable start_drawable = getResources().getDrawable(R.drawable.baseline_developer_mode_green_18dp);
            Drawable end_drawable = getResources().getDrawable(R.drawable.baseline_developer_mode_white_18dp);
            Utils.ImageViewAnimatedChange(context, iv_blocktest, start_drawable, end_drawable);
            makeBlock("Sync", "What a wonderful world!");
        });
        iv_more = findViewById(R.id.iv_more);
        iv_more.setOnClickListener((View view) -> {
            Intent i = new Intent(HyperConnActivity.this, BlockchainList.class);
            startActivity(i);
        });
        iv_memberlist = findViewById(R.id.iv_memberlist);
        iv_memberlist.setOnClickListener((View view) -> {
            Drawable start_drawable = getResources().getDrawable(R.drawable.baseline_account_circle_green_18dp);
            Drawable end_drawable = getResources().getDrawable(R.drawable.baseline_account_circle_white_18dp);
            Utils.ImageViewAnimatedChange(context, iv_memberlist, start_drawable, end_drawable);
            Intent i = new Intent(HyperConnActivity.this, MemberList.class);
            //Intent i = new Intent(HyperConnActivity.this, MemberList.class);
            startActivity(i);
        });
        iv_setting = findViewById(R.id.iv_setting);
        iv_setting.setOnClickListener((View view) -> {
            Drawable start_drawable = getResources().getDrawable(R.drawable.baseline_settings_green_18dp);
            Drawable end_drawable = getResources().getDrawable(R.drawable.baseline_settings_white_18dp);
            Utils.ImageViewAnimatedChange(context, iv_setting, start_drawable, end_drawable);
            Intent i = new Intent(HyperConnActivity.this, QuickPrefsActivity.class);
            startActivity(i);
        });
        //endregion

        //region 設置各種BroadcastReceiver; 寫法待調整(之後要改寫法，並移去別的地方)
        //region get connect_status from coreservice_sendmemessage
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_to_HyperConn");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String connect_status = intent.getStringExtra("connect_status");
                if (connect_status.equals("connected")) {
                    //if(isAdmin){
                    iv_blocktest.setVisibility(View.VISIBLE);
                    iv_notify_newapk.setVisibility(View.VISIBLE);
                    //}
                    iv_more.setImageDrawable(getResources().getDrawable(R.drawable.iv_more_green));
                    if (no_page == 1) {
                        if (!block_message.isEmpty()) {
                            StringBuilder sb = new StringBuilder();
                            sb.append(content_title).append("\n\n").append(block_message);
                            tv_msg.setText(sb.toString());
                            //tv_msg.setText(content_title + "\n\n" + block_message);
                            tv_msg.setVisibility(View.VISIBLE);
                            tv_connecting.setVisibility(View.GONE);
                            //iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_white_18dp));
                            //iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_green_18dp));
                            //iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
                        } else {
                            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_green_18dp));
                            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_white_18dp));
                            //iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
                            if (!phone_message.isEmpty()) {
                                tv_msg.setText(phone_message);
                            } else {
                                tv_msg.setVisibility(View.GONE);
                                tv_connecting.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                } else if (connect_status.equals("disconnected")) {
                    iv_blocktest.setVisibility(View.GONE);
                    iv_notify_newapk.setVisibility(View.GONE);
                    iv_more.setImageDrawable(getResources().getDrawable(R.drawable.iv_more_gray));
                }
            }
        };
        registerReceiver(receiver, filter);
        //endregion
        //finally,I can get message from BlockChain_Broadcasting
        IntentFilter filter1 = new IntentFilter();
        filter1.addAction("INVOKE_BlockChain_Broadcasting");
        //Service call activity 待問== 用處
        receiver1 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (no_page == 1) {
                    iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_white_18dp));
                    iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_green_18dp));
                    String mess = intent.getStringExtra("What");
                    String[] bm_array = block_message.split("\n\n");
                    StringBuilder sb = new StringBuilder();
                    int length = 50;
                    if (bm_array.length < length) {
                        length = bm_array.length;
                    }
                    for (int i = 0; i < length; i++) {
                        sb.append(bm_array[i]).append("\n\n");
                    }
                    //block_message=new_bm;
                    block_message = mess + "\n" + sb.toString();
                    StringBuilder sb1 = new StringBuilder();
                    sb1.append(content_title).append("\n\n").append(block_message);
                    tv_msg.setText(sb1.toString());
                    //tv_msg.setText(content_title+"\n\n"+block_message);
                    tv_msg.setVisibility(View.VISIBLE);
                    tv_connecting.setVisibility(View.GONE);
                    //}
                }
            }
        };
        registerReceiver(receiver1, filter1);
        //Got the notice for new coming apk 待問== 用處
        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("INVOKE_NewAPKArrived");
        receiver2 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                url_download = intent.getStringExtra("What").split(";")[1];
                SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key103, url_download);
                String apk_name = intent.getStringExtra("What").split(";")[0];
                //String apk_name=intent.getStringExtra("What");
                showNewAPKAlertDialog(apk_name);
            }
        };
        registerReceiver(receiver2, filter2);
        //Got the notice for alertDialog 待問== 用處
        IntentFilter filter3 = new IntentFilter();
        filter3.addAction("INVOKE_registration_result_Dialog");
        receiver3 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String title = intent.getStringExtra("title");
                String message = intent.getStringExtra("message");
                String submessage = intent.getStringExtra("submessage");
                if (!is_Dialog_Display) {
                    if (title.equals("Congratulations!") || title.equals("Registration processing")) {
                        if (title.equals("Congratulations!")) {
                            title = getResources().getString(R.string.dialog_congratulations);
                        } else {
                            title = getResources().getString(R.string.dialog_processing);
                        }
                        if (message.equals("Succeed")) {
                            message = getResources().getString(R.string.dialog_succeed);
                        } else if (message.contains("introduced")) {
                            message = getResources().getString(R.string.dialog_intrsucceed);
                        } else if (message.contains("checking")) {
                            message = getResources().getString(R.string.dialog_registration_checking);
                        }
                        iv_share.setVisibility(View.VISIBLE);
                        showDialog(title, message, submessage);
                    } else {
                        showDialogWithCancel(title, message, submessage);
                    }
                }
            }
        };
        registerReceiver(receiver3, filter3);
        //Got the notice for unregistered
        IntentFilter filter4 = new IntentFilter();
        filter4.addAction("INVOKE_registrationDialog");
        receiver4 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                //showDialog("RegistrationDialog",!is_Dialog_Display+" / "+!HCID.isEmpty()+" / "+HCID.equals(device_id)+" / "+!HCID.isEmpty(),"what's up?");
                //Log.e("cherryaa","HCID:"+HCID);
                //Log.e("cherryaa","device_id:"+device_id);
                //Log.e("cherry", "Receiver action:INVOKE_registrationDialog");
                if (!is_Dialog_Display && !HCID.isEmpty() &&
                        HCID.equals(device_id) && !isRegistering()) {
                    registrationDialog();
                }
                //registrationDialog();
            }
        };
        registerReceiver(receiver4, filter4);
        //Got the notice for renew tv_HC,tv_CB,tv_CR 待問== 用處
        IntentFilter filter5 = new IntentFilter();
        filter5.addAction("INVOKE_HyperConnActivity_RenewTvValue");
        receiver5 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String strHC = "HC:" + Utils.formatDoubleToString(new HyperConnectivityDAO(context).getBalanceByHCID(HCID));
                tv_HC.setText(strHC);
                String strCB = "CB:" + Utils.formatDoubleToString(getCB(HCID));
                tv_CB.setText(strCB);
                String str_CR = "CR:" + Utils.formatDoubleToString(new CB_TradingDAO(context).getCR() * 100) + "% USD";
                tv_CR.setText(str_CR);
            }
        };
        registerReceiver(receiver5, filter5);
        //get content title from coreservice 待問== 用處
        IntentFilter filter6 = new IntentFilter();
        filter6.addAction("INVOKE_to_HyperConn_content_title");
        receiver6 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                content_title = intent.getStringExtra("content_title");
            }
        };
        registerReceiver(receiver6, filter6);
        //endregion

        // instantiate it within the onCreate method
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Download new APK");
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        mProgressDialog.setCancelable(true);
        is_Dialog_Display = false;

        if (getIntent().getExtras() != null) {
            Bundle bundle = this.getIntent().getExtras();
            if (bundle.getBoolean("isDownload")) {
                showNewAPKAlertDialog("HyperConn.apk");
            }
        }
    }
    //endregion

    //region QRCode scanner (Zxing)
    private void qrcodereader() {
        new IntentIntegrator(this).initiateScan();
    }
    //endregion

    //region 返回此Activity時會執行的方法
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        //showDialog("QRcode Reader Result",requestCode+" / "+result.getContents(),"right?");
        int REQUEST_NEWAPK_BROADCAST = 102;
        int REQUEST_REGISTRATION = 49374;
        if (requestCode == REQUEST_CODE_TAKE_PHOTO) {
            //String mess = "";
            Uri[] results = null;
            // Check that the response is a good one
            if (resultCode == Activity.RESULT_OK) {
                if (data == null) {
                    //results=new Uri[]{Uri.fromFile(tmpFile)};
                    //icon_bitmap = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + "/image.jpg");
                    icon_bitmap = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + "/" + filename);
                    realPath = Environment.getExternalStorageDirectory() + "/" + filename;
                    results = new Uri[]{getImageUri(icon_bitmap)};
                    //iv_icon.setImageBitmap(bitmap);
                    //String path=Environment.getExternalStorageDirectory() + "/image.jpg";
                    //results=new Uri[]{Uri.parse(path)};
                } else {
                    realPath = RealPathUtil.getRealPathFromURI_API19(this, data.getData());
                    String dataString = data.getDataString();
                    //mess="data is null:"+dataString;
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                }
                //showAlertDialog("realPath",realPath);
                if (results != null && results[0] != null) {
                    startPhotoZoom(results[0]);
                }
            }
        } else if (requestCode == PHOTO_REQUEST_CUT) {
            if (data != null)
                sentPicToNext(data);
        } else if (requestCode == REQUEST_NEWAPK_BROADCAST) {
            //IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
            if (result != null && result.getContents() != null) {
                EditText editText_NewAPK_dialog = view.findViewById(R.id.et_url);
                editText_NewAPK_dialog.setText(result.getContents());
            }
        } else if (requestCode == REQUEST_REGISTRATION) {
            //IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
            if (result != null) {
                if (result.getContents() != null) {
                    //Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
                //} else {
                    EditText et_intrducer = view.findViewById(R.id.et_intrducer);
                    et_intrducer.setText(result.getContents());
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    //endregion

    //region 取得HCID
    private void getHCID() {
        //檢查應用程式在此裝置的權限
        if (checkREAD_PHONE_STATEPermission()) {
            //判斷網路是否有連線
            if (isConnected()) {
                //執行一個非同步的Thread ，抓取GUID
                Async_getGUID getGUIDTask = new Async_getGUID();
                getGUIDTask.execute();

            }
        } else {
            checkPermissionDialog(); //跳出警告，要求使用者需要開啟相關存取權限
        }
    }
    //endregion

    //region onStart方法---執行完onCreate方法，則會繼續執行 onStart 此方法在Activity 被呼叫時會執行（例如切換到別頁再切回此頁)
    //Activity生命週期：onCretat -> onStart -> onResume -> onPause -> onStop -> onDestroy
    @Override
    protected void onStart() {
        super.onStart();
        Log.e("cherry", "執行到HyperConnActivity 的onStart 了");
        //code_stop_message = false;
        setLocale();    //設定語系
        tv_CR.setVisibility(View.VISIBLE);
        String str_CR = "CR:" + Utils.formatDoubleToString(new CB_TradingDAO(context).getCR() * 100) + "% USD";
        tv_CR.setText(str_CR);
        //staticVar xx = new staticVar(); //實例化此class，讓系統將各static 值存入記憶體
        if (!Utils.isBlank(staticVar.myHCID))
            HCID = staticVar.myHCID;
        if (Utils.isBlank(HCID)) {
            Log.e("cherry", "HCID is empty,  get HCID");
            getHCID();
        } else {
            tv_HC.setVisibility(View.VISIBLE);
            String strHC = "HC:" + Utils.formatDoubleToString(new HyperConnectivityDAO(context).getBalanceByHCID(HCID));
            tv_HC.setText(strHC);
            tv_CB.setVisibility(View.VISIBLE);
            String strCB = "CB:" + Utils.formatDoubleToString(getCB(HCID));
            tv_CB.setText(strCB);
        }
        if (!isServiceRunning(CoreService.class)) {
            iv_blocktest.setVisibility(View.GONE);
            //iv_more.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.circle_shadow_rect));
            iv_more.setImageDrawable(getResources().getDrawable(R.drawable.iv_more_gray));
        }
        scrollView.setVisibility(View.VISIBLE);
        ll_share.setVisibility(View.GONE);
        if (!block_message.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            sb.append(content_title).append("\n\n").append(block_message);
            tv_msg.setText(sb.toString());
            //tv_msg.setText(content_title + "\n\n" + block_message);
            tv_msg.setVisibility(View.VISIBLE);
            tv_connecting.setVisibility(View.GONE);
            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_white_18dp));
            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_green_18dp));
            iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
            iv_statistics.setImageDrawable(getResources().getDrawable(R.drawable.baseline_equalizer_white_18dp));

        } else {
            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_green_18dp));
            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_white_18dp));
            iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
            if (!phone_message.isEmpty()) {
                tv_msg.setText(phone_message);
            } else {
                tv_msg.setVisibility(View.GONE);
                tv_connecting.setVisibility(View.VISIBLE);
            }
        }
    }
    //endregion

    //region 當Activity 結束時會觸發 onDestroy()
    @Override
    protected void onDestroy() {
        Log.e("cherry", "Activity is finish(onDestroy)");
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        if (receiver1 != null) {
            unregisterReceiver(receiver1);
            receiver1 = null;
        }
        if (receiver2 != null) {
            unregisterReceiver(receiver2);
            receiver2 = null;
        }
        if (receiver3 != null) {
            unregisterReceiver(receiver3);
            receiver3 = null;
        }
        if (receiver4 != null) {
            unregisterReceiver(receiver4);
            receiver4 = null;
        }
        if (receiver5 != null) {
            unregisterReceiver(receiver5);
            receiver5 = null;
        }
        if (receiver6 != null) {
            unregisterReceiver(receiver6);
            receiver6 = null;
        }
        super.onDestroy();
    }
    //endregion

    private boolean checkREAD_PHONE_STATEPermission() {
        String permission = android.Manifest.permission.READ_PHONE_STATE;
        int res = context.checkCallingOrSelfPermission(permission);
        String storagePermission = android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
        int res1 = context.checkCallingOrSelfPermission(storagePermission);
        //必須要有手機狀態讀取權限 跟外部儲存的讀寫權限才行
        return (res == PackageManager.PERMISSION_GRANTED && res1 == PackageManager.PERMISSION_GRANTED);
    }

    public void checkPermissionDialog() {
        is_Dialog_Display = true;
        String check_permission_title = getResources().getString(R.string.check_permission_title);
        String check_permission_message = getResources().getString(R.string.check_permission_message);
        String check_permission_submessage = getResources().getString(R.string.check_permission_submessage);

        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = HyperConnActivity.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_title = view.findViewById(R.id.tv_title);
        tv_title.setText(check_permission_title);
        TextView tv_message = view.findViewById(R.id.tv_message);
        tv_message.setText(check_permission_message);
        TextView tv_submessage = view.findViewById(R.id.tv_submessage);
        //String submessage = "free the limitation of battery usage";
        tv_submessage.setText(check_permission_submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                (dialog, which) -> {
                    is_Dialog_Display = false;
                    dialog.dismiss();
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                });
        alertDialog.show();
    }

    /*public void showAlertDialog(String title, String message) {
        is_Dialog_Display = true;
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        is_Dialog_Display = false;
                        dialog.dismiss();
                        Intent intent = new Intent();
                        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        Uri uri = Uri.fromParts("package", getPackageName(), null);
                        intent.setData(uri);
                        startActivity(intent);
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        is_Dialog_Display = false;
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }*/

    public void showNewAPKAlertDialog(String apk_name) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        LayoutInflater inflater = HyperConnActivity.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(apk_name);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_now),
                (dialog, which) -> {
                    dialog.dismiss();
                    mProgressDialog.show();
                    Intent intent = new Intent(HyperConnActivity.this, DownloadService.class);
                    //intent.putExtra("url", "url of the file to download");
                    intent.putExtra("receiver", new DownloadReceiver(new Handler()));
                    //startService(intent);
                    //Intent intent = new Intent(HyperConnActivity.this, DownloadService.class);
                    //intent.putExtra("url_download", url_download);
                    intent.putExtra("file_name", apk_name);
                    startService(intent);
                    //fireDownload(url_download,apk_name);
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_later),
                (dialog, which) -> dialog.dismiss());
        alertDialog.show();
    }

    public void showNewAPKBroadcastDialog() {

        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = HyperConnActivity.this.getLayoutInflater();
        view = inflater.inflate(R.layout.newapk_dialog, null);
        final EditText editText_NewAPK_name_dialog = view.findViewById(R.id.et_name);
        apk_name = getResources().getString(R.string.app_ver) + ".apk";
        editText_NewAPK_name_dialog.setHint(apk_name);
        final EditText editText_NewAPK_url_dialog = view.findViewById(R.id.et_url);
        url_download = link_weiyun;
        editText_NewAPK_url_dialog.setHint(url_download);

        editText_NewAPK_url_dialog.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                //strCall=editText_NewAPK_url_dialog.getText().toString().trim()+";"+apk_name;
                url_download = editText_NewAPK_url_dialog.getText().toString().trim();
            }
        });
        editText_NewAPK_name_dialog.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                //strCall=editText_NewAPK_url_dialog.getText().toString().trim()+";"+editText_NewAPK_name_dialog.getText().toString().trim();
                apk_name = editText_NewAPK_name_dialog.getText().toString().trim();
            }
        });

        ImageView iv_scan = view.findViewById(R.id.iv_scan);
        iv_scan.setOnClickListener(v -> {
            Drawable start = getResources().getDrawable(R.drawable.baseline_fullscreen_green_18dp);
            Drawable end = getResources().getDrawable(R.drawable.baseline_fullscreen_white_18dp);
            Utils.ImageViewAnimatedChange(context, iv_scan, start, end);
            registrationDialog();
            alertDialog.dismiss();
        });
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                (dialog, which) -> {
                    //SignalRUtil.setHubConnect(context);
                    //SignalRUtil.NewAPKBroardcast(strCall);
                    AsyncCallWS_ReleaseAPK releaseAPKTask = new AsyncCallWS_ReleaseAPK();
                    releaseAPKTask.execute(apk_name, getStringAPK(), url_download);
                    dialog.dismiss();
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                (dialog, which) -> dialog.cancel());
        alertDialog.show();
    }

    private void registrationDialog() {
        is_Dialog_Display = true;
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = HyperConnActivity.this.getLayoutInflater();
        view = inflater.inflate(R.layout.registration_dialog, null);
        final EditText et_intrducer = view.findViewById(R.id.et_intrducer);
        final EditText et_nickname = view.findViewById(R.id.et_nickname);
        if (!nickname.isEmpty()) {
            et_nickname.setText(nickname);
        }
        ImageView iv_icon = view.findViewById(R.id.iv_icon);
        if (!realPath.isEmpty()) {
            Bitmap bitmap = BitmapFactory.decodeFile(realPath);
            iv_icon.setImageBitmap(ServiceUtil.getRoundedCornerBitmap(bitmap));
        }
        final TextView tv_alert = view.findViewById(R.id.tv_alert);
        final TextView tv_alerttext = view.findViewById(R.id.tv_alerttext);
        if (!nickname.isEmpty() || !realPath.isEmpty()) {
            tv_alert.setVisibility(View.VISIBLE);
            tv_alerttext.setVisibility(View.VISIBLE);
        }
        iv_icon.setOnClickListener((View v) -> {
            Intent[] intentArray;
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            filename = getPhotoFileName();
            tmpFile = new File(Environment.getExternalStorageDirectory(), filename);
            Uri outputFileUri = Uri.fromFile(tmpFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
            intentArray = new Intent[]{intent};
            Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
            contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
            contentSelectionIntent.setType("image/*");
            Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
            chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
            chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser");
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
            startActivityForResult(chooserIntent, REQUEST_CODE_TAKE_PHOTO);
        });
        et_intrducer.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                introducer = et_intrducer.getText().toString().trim();
            }
        });
        et_nickname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                nickname = et_nickname.getText().toString().trim();
            }
        });

        ImageView iv_scan = view.findViewById(R.id.iv_scan);
        iv_scan.setOnClickListener((View v) -> {
            Drawable start = getResources().getDrawable(R.drawable.baseline_fullscreen_green_18dp);
            Drawable end = getResources().getDrawable(R.drawable.baseline_fullscreen_white_18dp);
            Utils.ImageViewAnimatedChange(context, iv_scan, start, end);
            //qrcodereader(REQUEST_REGISTRATION);
            qrcodereader();
        });
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_submit),
                (dialog, which) -> {
                    check_registration();
                    is_Dialog_Display = false;
                    dialog.dismiss();
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_registered),
                (dialog, which) -> {
                    check_registration();
                    is_Dialog_Display = false;
                    AlreadyRegistered = true;
                    dialog.dismiss();
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                (dialog, which) -> {
                    is_Dialog_Display = false;
                    dialog.dismiss();
                });
        alertDialog.show();
    }

    private Boolean isRegistering() {
        return new applyBlockDAO(context).isRegistering() ||
                new BlockDAO(context).isRegistering(HCID) != null ||
                new MemberDAO(context).isRegistered(HCID) ||
                AlreadyRegistered;
        /*if (new applyBlockDAO(context).isRegistering() ||
                new BlockDAO(context).isRegistering(HCID) != null ||
                new MemberDAO(context).isRegistered(HCID) ||
                AlreadyRegistered) {
            return true;
        } else {
            return false;
        }*/
    }

    private void check_registration() {
        if (!introducer.isEmpty()) {
            SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key104, introducer);
            SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key105, nickname);
            String data = introducer + " " + HCID + " " + strPublickey;
            block_message = R.string.check_registration + block_message;
            StringBuilder sb = new StringBuilder();
            sb.append(content_title).append("\n\n").append(block_message);
            tv_msg.setText(sb.toString());
            //tv_msg.setText(content_title + "\n\n" + block_message);
            AlreadyRegistered = true;
            applyBlock("RG_1", data);
        }
    }

    private void preCoreService() {
        Intent intentservice = new Intent(context, CoreService.class);
        intentservice.putExtra("Message", "startCoreservice");
        context.startService(intentservice);
    }

    private String getStrPrivateKey() {
        //String strPrivateKey="";
        String strPrivateKey = RSAEncryptionJava8.readDeviceID(HyperConnActivity.this);//获取缓存在  sharepreference 里面的 设备唯一标识
        String string = SharedPreferencesHelper.getSharedPreferencesString(HyperConnActivity.this, SharedPreferencesHelper.SharedPreferencesKeys.key101, "");
        if (!Utils.isBlank(strPrivateKey)) {
            //APP缓存与档案中不同，以档案中为准
            if (!string.equals(strPrivateKey)) {
                SharedPreferencesHelper.putSharedPreferencesString(HyperConnActivity.this, SharedPreferencesHelper.SharedPreferencesKeys.key101, strPrivateKey);
            }
        } else {
            //App缓存中有
            if (!Utils.isBlank(string)) {
                    RSAEncryptionJava8.saveDeviceID(string, HyperConnActivity.this);
                //App缓存和存档中都没有
            } else {
                try {
                    strPrivateKey = RSAEncryptionJava8.PrivateKeyToString(RSAEncryptionJava8.getPrivateKey(HCID));
                    RSAEncryptionJava8.saveDeviceID(strPrivateKey, HyperConnActivity.this);
                    SharedPreferencesHelper.putSharedPreferencesString(HyperConnActivity.this, SharedPreferencesHelper.SharedPreferencesKeys.key101, strPrivateKey);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        //strPrivateKey = RSAEncryptionJava8.PrivateKeyToString(RSAEncryptionJava8.getPrivateKey(HCID));
        //showDialog("strPrivateKey",strPrivateKey,"");
        return strPrivateKey;
    }

    private String getGUID() {
        HCID = "";
        //try {//Toast.makeText(context, "Hi...Thread", Toast.LENGTH_LONG).show();
        //获取保存在sd中的 设备唯一标识符
        UniqueID uID = new UniqueID();

        String readDeviceID = uID.readDeviceID(HyperConnActivity.this);
        //Log.e("cherry","readDeviceID="+readDeviceID);
        String string = SharedPreferencesHelper.getSharedPreferencesString(HyperConnActivity.this, staticVar.SPKey100, "");
        //Log.e("cherry","string="+string);
        device_id = uID.getDeviceId(HyperConnActivity.this);
        //String string = SharedPreferencesHelper.getSharedPreferencesString(HyperConnActivity.this, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        //HC_ID.txt 檔案中有讀取到HCID
        if (!Utils.isBlank(readDeviceID)) {
            //SharedPreferences 與HC_ID.txt中的HCID不同，以檔案內容為準，並變更SharedPreferences內容
            if (!string.equals(readDeviceID)) {
                Log.e("cherry", "HC_ID.txt 跟 SharedPreferences 不同 ");
                Log.e("cherry","readDeviceID="+readDeviceID+",string="+string);
                SharedPreferencesHelper.putSharedPreferencesString(HyperConnActivity.this, staticVar.SPKey100, readDeviceID);
            }
            HCID = readDeviceID;
            //showDialog("HCID:",HCID,"!StringUtil.isBlank(readDeviceID)");
        }
        //SharedPreferences 有值，將值回存至HC_ID.txt
        /*else if (!Utils.isBlank(string)) {
            Log.e("cherry", "沒有HC_ID.txt 但SharedPreferences 有值");
            uID.saveDeviceID(string, HyperConnActivity.this);
            HCID = string;
        }*/
        //SharedPreferences 與HC_ID.txt 都沒有取到HCID，則產生HCID，並分別存入 SharedPreferences 以及 HC_ID.txt中
        else {

            readDeviceID = device_id;
//            Log.e("cherry","存入之前的device_id:"+device_id);
//            Log.e("cherry","存入之前的readDeviceID:"+readDeviceID);
            uID.saveDeviceID(readDeviceID, HyperConnActivity.this);
            SharedPreferencesHelper.putSharedPreferencesString(HyperConnActivity.this, staticVar.SPKey100, readDeviceID);
            HCID = readDeviceID;
        }
        staticVar.myHCID = HCID;
        return HCID;
    }

    private String getTelephoneInfo() {
        //Get the instance of TelephonyManager
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        //Get the phone type
        String strphoneType = "";

        int phoneType = tm != null ? tm.getPhoneType() : 0;

        switch (phoneType) {
            case (TelephonyManager.PHONE_TYPE_CDMA):
                strphoneType = "CDMA";
                break;
            case (TelephonyManager.PHONE_TYPE_GSM):
                strphoneType = "GSM";
                break;
            case (TelephonyManager.PHONE_TYPE_NONE):
                strphoneType = "NONE";
                break;
        }

        //getting information if phone is in roaming
        //boolean isRoaming = tm != null ? tm.isNetworkRoaming() : false;
        String info = "Phone Details:";
        try {
            //Calling the methods of TelephonyManager the returns the information
            if (tm != null) {
                info += "\nSim Serial Number " + tm.getSimSerialNumber();
                info += "\nSoftware Version " + tm.getDeviceSoftwareVersion();
                info += "\nOperator Name " + tm.getNetworkOperatorName();   // Get carrier name (Network Operator Name)
            }
        } catch (SecurityException e) {
            //
        }
        // Get Phone model and manufacturer name
        info += "\nManufacturer " + Build.MANUFACTURER;
        info += "\nModel " + Build.MODEL;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        //NetworkInfo netInfo = cm.getActiveNetworkInfo();
        //should check null because in airplane mode it will be null
        if (Build.VERSION.SDK_INT >= 23) {
            if (cm != null) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
                //抓取網路上傳跟下載的速率，並顯示在畫面上
                if (nc != null) {
                    int downSpeed = nc.getLinkDownstreamBandwidthKbps();
                    int upSpeed = nc.getLinkUpstreamBandwidthKbps();
                    info += "\nPhone Network Type " + strphoneType;
                    info += "\nUpload Bandwidth(Kbps) " + upSpeed;
                    info += "\nDownload Bandwidth(Kbps) " + downSpeed;
                    StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                    long bytesAvailable;
                    /*if (android.os.Build.VERSION.SDK_INT >=
                            android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {*/
                    bytesAvailable = stat.getBlockSizeLong() * stat.getAvailableBlocksLong();
                    //} else {
                    //bytesAvailable = (long) stat.getBlockSize() * (long) stat.getAvailableBlocks();
                    //}
                    long megAvailable = bytesAvailable / (1024 * 1024);
                    info += "\nAvailable Storage(MB) " + megAvailable;
                }
            }

        }

        return info;
    }
    //endregion

    /*private void resultCodeNOTGOOD(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            //Log.d(LOGTAG,"COULD NOT GET A GOOD RESULT.");
            if (data == null)
                return;
            //Getting the passed result
            String result = data.getStringExtra("com.blikoon.qrcodescanner.error_decoding_image");
            if (result != null) {
                AlertDialog alertDialog = new AlertDialog.Builder(HyperConnActivity.this).create();
                alertDialog.setTitle("Error");
                alertDialog.setMessage("Is this correct QRcode？");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_ok),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        }
    }*/

    private void share_text() {
        //Uri imageUri = FileProvider.getUriForFile(context, "com.example.myfileprovider",Utils.getDevicesDir(context,FILE_QRcode));
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        //intent.setType("*/*");
        APK_link = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key103, "");
        if (APK_link.isEmpty()) {
            APK_link = link_weiyun + " ";
        }
        String Welcome_text = getResources().getString(R.string.share_text1) + "\n\n" + APK_link + " \n\n" +
                getResources().getString(R.string.share_text2) + "\n\n" + HCID.substring(0, 6) + "\n\n" +
                getResources().getString(R.string.share_text3);
        //+"\n\n"+new BlockchainDAO(context).getByIndex(6).getData().split(" ")[1]
        //;
        intent.putExtra(Intent.EXTRA_TEXT, Welcome_text);
        //intent.putExtra(Intent.EXTRA_STREAM, imageUri);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(Intent.createChooser(intent, "Share HyperConn via:"));
    }

    /*private String getHCID_abbreviated() {
        return HCID;
    }*/

    private void share_bluetooth() {
        ApplicationInfo app = getApplicationContext().getApplicationInfo();
        String filePath = app.sourceDir;

        // Append file and send Intent
        File originalApk = new File(filePath);
        try {
            //Make new directory in new location
            File tempFile = getDevicesDir();
            //Copy file to new location
            InputStream in = new FileInputStream(originalApk);
            OutputStream out = new FileOutputStream(tempFile);

            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
            Intent intent = new Intent(Intent.ACTION_SEND);
            // MIME of .apk is "application/vnd.android.package-archive".
            // but Bluetooth does not accept this. Let's use "*/*" instead.
            intent.setType("*/*");
            //intent.setType("text/plain");
            Uri apkUri = FileProvider.getUriForFile(context, "com.example.myfileprovider", tempFile);
            intent.putExtra(Intent.EXTRA_STREAM, apkUri);
            startActivity(Intent.createChooser(intent, "Share HyperConn via:"));
        } catch (IOException e) {
            //e.printStackTrace();
        }
    }

//    private void share_attathfile() {
//        ApplicationInfo app = getApplicationContext().getApplicationInfo();
//        String apk_name = app.name;
//        String filePath = app.sourceDir;
//        // Append file and send Intent
//        File originalApk = new File(filePath);
//
//        try {
//            //Make new directory in new location
//            File tempFile = getDevicesDir();
//            //Copy file to new location
//            InputStream in = new FileInputStream(originalApk);
//            OutputStream out = new FileOutputStream(tempFile);
//
//            byte[] buf = new byte[1024];
//            int len;
//            while ((len = in.read(buf)) > 0) {
//                out.write(buf, 0, len);
//            }
//            in.close();
//            out.close();
//            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
//            // MIME of .apk is "application/vnd.android.package-archive".
//            // but Bluetooth does not accept this. Let's use "*/*" instead.
//            intent.setType("*/*");
//            ArrayList<Uri> Uris = new ArrayList<>();
//            Uri apkUri = FileProvider.getUriForFile(context, "com.example.myfileprovider", tempFile);
//            Uri imageUri = FileProvider.getUriForFile(context, "com.example.myfileprovider", Utils.getDevicesDir(context, FILE_QRcode));
//            Uris.add(apkUri);
//            Uris.add(imageUri);
//            APK_link = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key103, "");
//            if (APK_link.isEmpty()) {
//                APK_link = link_weiyun;
//            }
//            String Welcome_text = "Welcome to the world of HyperConn,\n" +
//                    " Piease follow next 2 steps and start your adventure.\n\n" +
//                    " 1.Download APK by clicking link below:\n" + APK_link + "\n\n" +
//                    " 2.Insert registration code below to Complete procedure of registration\n" + HCID + "\n\n" +
//                    " With my best regards!";
//            intent.putExtra(Intent.EXTRA_TEXT, Welcome_text);
//            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
//            intent.putExtra(Intent.EXTRA_SUBJECT, "A good message I'd like to share");
//            intent.putExtra(Intent.EXTRA_STREAM, Uris);
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(Intent.createChooser(intent, "Share HyperConn via:"));
//        } catch (IOException e) {
//            //e.printStackTrace();
//        }
//    }

    public File getDevicesDir() {
        String FILE_APK = "HyperConn.apk";
        File mCropFile;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File cropdir = new File(Environment.getExternalStorageDirectory(), staticVar.APP_dir);
            //程式一進來就會 Get HCID，那時就會檢查目錄存不存在了，所以這裡不需要再檢查...
            /*if (!cropdir.exists()) {
                cropdir.mkdirs();
            }*/
            mCropFile = new File(cropdir, FILE_APK);
        } else {
            File cropdir = new File(context.getFilesDir(), staticVar.APP_dir);
            /*if (!cropdir.exists()) {
                cropdir.mkdirs();
            }*/
            mCropFile = new File(cropdir, FILE_APK);
        }
        return mCropFile;
    }

    private String getPhotoFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "'IMG'_yyyyMMdd_HHmmss");
        return dateFormat.format(date) + ".jpg";
    }

    public Uri getImageUri(Bitmap inImage) {
        String path =
                MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage,
                        "Title", null);
        return Uri.parse(path);
    }

    private void startPhotoZoom(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        // crop为true是設置在開启的intent中設置顯示的view可以剪裁
        intent.putExtra("crop", "true");

        // aspectX aspectY 是寬高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);

        // outputX,outputY 是剪裁圖片的寬高
        intent.putExtra("outputX", 300);
        intent.putExtra("outputY", 300);
        intent.putExtra("return-data", true);
        intent.putExtra("noFaceDetection", true);
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

    private void sentPicToNext(Intent picdata) {
        Bundle bundle = picdata.getExtras();
        if (bundle != null) {
            icon_bitmap = bundle.getParcelable("data");
            ImageView iv_icon = view.findViewById(R.id.iv_icon);
            if (icon_bitmap == null) {
                iv_icon.setImageResource(R.drawable.no_picture);
            } else {
                iv_icon.setImageBitmap(icon_bitmap);
                saveImage(icon_bitmap);
            }
        }
    }

    private void saveImage(Bitmap bitmap) {
        SaveImageTask saveImageTask = new SaveImageTask(context, filePath -> onSaveComplete(filePath));
        saveImageTask.execute(bitmap);
    }

    private void onSaveComplete(File filePath) {
        if (filePath == null) {
            //Log.w(TAG, "onSaveComplete: file dir error");
            return;
        }
        realPath = filePath.getPath();
        //save realpath
        SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key3, realPath);
    }

    private void applyBlock(String datatype, String data) {
        applyBlock ab = new applyBlock();
        ab.setApplicant(HCID);
        //ab.setCreateTime(new Date().getTime());
        ab.setData(data);
        ab.setDatatype(datatype);
        ab.setHash(ab.calculateHash(ab));
        new applyBlockDAO(context).insert(ab);
        SharedPreferencesHelper.putSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key107, new Date().getTime());
        Intent intent = new Intent(HyperConnActivity.this, CoreService.class);
        intent.putExtra("Message", "check_applyBlock");
        startService(intent);
    }

    private void makeBlock(String datatype, String data) {
        Intent intent = new Intent(HyperConnActivity.this, CoreService.class);
        intent.putExtra("Message", datatype + ":" + data);
        startService(intent);
    }

    public void showDialogWithCancel(String title, String message, String submessage) {
        is_Dialog_Display = true;
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = HyperConnActivity.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_title = view.findViewById(R.id.tv_title);
        tv_title.setText(title);
        TextView tv_message = view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        TextView tv_submessage = view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                (dialog, which) -> {
                    is_Dialog_Display = false;
                    dialog.dismiss();
                    registrationDialog();
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                (dialog, which) -> {
                    is_Dialog_Display = false;
                    dialog.dismiss();
                });
        alertDialog.show();
    }

    public void showDialog(String title, String message, String submessage) {
        is_Dialog_Display = true;
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = HyperConnActivity.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_title = view.findViewById(R.id.tv_title);
        tv_title.setText(title);
        TextView tv_message = view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        TextView tv_submessage = view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                (dialog, which) -> {
                    is_Dialog_Display = false;
                    dialog.dismiss();
                    //registrationDialog();
                });
        alertDialog.show();
    }

    public boolean isServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if(manager!=null)
        {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (service.service.getClassName().contains(serviceClass.getName())) {
                    return true;
                }
            }
        }
        return false;
    }

    // Converting File to Base64.encode String type using Method
    public String getStringAPK() {
        ApplicationInfo app = getApplicationContext().getApplicationInfo();
        String filePath = app.sourceDir;
        // Append file and send Intent
        File originalApk = new File(filePath);
        InputStream inputStream;
        String encodedFile = "", lastVal;
        try {
            //inputStream = new FileInputStream(f.getAbsolutePath());
            inputStream = new FileInputStream(originalApk);
            byte[] buffer = new byte[10240];//specify the size to allow
            int bytesRead;
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            Base64OutputStream output64 = new Base64OutputStream(output, Base64.DEFAULT);

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                output64.write(buffer, 0, bytesRead);
            }
            output64.close();
            encodedFile = output.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        lastVal = encodedFile;
        return lastVal;
    }

    private class AsyncCallWS_ReleaseAPK extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            String filename = params[0];
            String Base64Str = params[1];
            String url = params[2];
            ReleaseAPK(filename, Base64Str, url);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {

        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private void ReleaseAPK(String filename, String Base64Str, String url) {
        String METHOD_NAME = "ReleaseAPK";
        //String NAMESPACE = "http://152.101.178.115:8081/";
        String NAMESPACE = staticVar.Server_url;
        String SOAP_ACTION = NAMESPACE + METHOD_NAME;
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        String URL_WS = NAMESPACE + "webService.asmx";
        String timeStamp = String.valueOf(new Date().getTime());
        String encryptStr = HCID + "@HyperConn@" + timeStamp.trim();
        String identifyStr = getHashCode(encryptStr).toUpperCase();
        request.addProperty("fileName", filename);
        request.addProperty("Base64Str", Base64Str);
        request.addProperty("url_download", url);
        request.addProperty("HCID", HCID);
        request.addProperty("timeStamp", timeStamp);
        request.addProperty("identifyStr", identifyStr);
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        //Set output SOAP object
        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        //Create HTTP call object
        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL_WS);

        SoapPrimitive soapPrimitive = null;
        try {
            androidHttpTransport.call(SOAP_ACTION, envelope);
            soapPrimitive = (SoapPrimitive) envelope.getResponse();
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
        }/**/
        //String tmp = soapPrimitive.toString();
        //一開始從網路接收通常為String型態,tmp為接收到的String,為避免串流內有其他資料只需抓取{}間的內容
        //tmp = tmp.substring(tmp.indexOf("{"), tmp.lastIndexOf("}") + 1);
        //JSONObject json_read;
        //將資料丟進JSONObject
    }

    public static String getHashCode(String Gkey) { //得到毫秒数

        MessageDigest shaCode;
        //Date curDate = new Date();
        //String dataStructure = Gkey;
        try {
            shaCode = MessageDigest.getInstance("SHA-256");
            shaCode.update(Gkey.getBytes());
            //System.out.println("dataStructure="+Gkey);
        } catch (Exception e) {
            //e.printStackTrace();
            return "";
        }
        return byte2Hex(shaCode.digest());
    }

    private static String byte2Hex(byte[] data) {
        String hexString = "";
        String stmp;

        for (int i = 0; i < data.length; i++) {
            stmp = Integer.toHexString(data[i] & 0XFF);

            if (stmp.length() == 1) {
                hexString = hexString + "0" + stmp;
            } else {
                hexString = hexString + stmp;
            }
        }
        return hexString.toUpperCase();
    }

    private class DownloadReceiver extends ResultReceiver {

        public DownloadReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {

            super.onReceiveResult(resultCode, resultData);

            if (resultCode == DownloadService.UPDATE_PROGRESS) {

                int progress = resultData.getInt("progress"); //get the progress
                String path = resultData.getString("path"); //get the progress

                mProgressDialog.setProgress(progress);

                if (progress == 100) {
                    mProgressDialog.dismiss();
                    //Install new APK automatically
                    //File cropdir = new File(Environment.getExternalStorageDirectory(), FILE_DIR);
                    //File mCropFile = new File(cropdir, apk_name);
                    //String apkPath = "/sdcard/HyperConn/" + apk_name;
                    openAPK(path);
                    /*Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.fromFile(mCropFile), "application/vnd.android.package-archive");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);*/
                }
            }
        }
    }

    private void openAPK(String fileSavePath) {
        File file = new File(Uri.parse(fileSavePath).getPath());
        String filePath = file.getAbsolutePath();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri data;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {//判断版本大于等于7.0
            // 生成文件的uri，，
            // 注意 下面参数com.ausee.fileprovider 为apk的包名加上.fileprovider，
            data = FileProvider.getUriForFile(context, "com.example.myfileprovider", new File(filePath));
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);// 给目标应用一个临时授权
        } else {
            data = Uri.fromFile(file);
        }
        intent.setDataAndType(data, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
        //setPendingIntent();
    }

    private class Async_getGUID extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            //Log.i(TAG, "doInBackground");
            return getGUID();
        }

        @Override
        protected void onPostExecute(String result) {
            HCID = result;
            staticVar.myHCID = result;
            Log.e("cherry", "取得HCID了:" + staticVar.myHCID);
            //showAlertDialog("HCID",HCID);
            if (!HCID.isEmpty()) {
                String strHC = "HC:" + Utils.formatDoubleToString(new HyperConnectivityDAO(context).getBalanceByHCID(HCID));
                tv_HC.setText(strHC);
                String strCB = "CB:" + Utils.formatDoubleToString(getCB(HCID));
                tv_CB.setText(strCB);
                Async_getPrivatekey getPrivatekeyTask = new Async_getPrivatekey();
                getPrivatekeyTask.execute();
                if (new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)) {
                    //isAdmin=true;
                    ll_admin.setVisibility(View.VISIBLE);
                }
                if (isRegistering()) {
                    iv_share.setVisibility(View.VISIBLE);
                    iv_statistics.setVisibility(View.VISIBLE);
                }
                if (isConnected()) {
                    preCoreService();
                }
            }
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private class Async_getPrivatekey extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            //Log.i(TAG, "doInBackground");
            return getStrPrivateKey();
        }

        @Override
        protected void onPostExecute(String strPrivateKey) {
            //showDialog("onPostExecute", "onPostExecute", result);
            //String strPrivateKey = result;
            PublicKey publicKey = null;
            PrivateKey privateKey;
            String message = "";
            try {
                privateKey = RSAEncryptionJava8.stringToPrivateKey(strPrivateKey);
                publicKey = RSAEncryptionJava8.getFromPrivateKey(privateKey);
                UniqueID uID = new UniqueID();
                String originalStr = uID.getPhonenumber(context);
                if (Utils.isBlank(originalStr)) {
                    originalStr = "Not Available!";
                }
                message = RSAEncryptionJava8.getCryphotography(originalStr, publicKey, privateKey);
            } catch (Exception e) {
                phone_message = e.getMessage();
            }
            strPublickey = RSAEncryptionJava8.PublicKeyToString(publicKey);
            if (strPublickey == null) {
                strPublickey = "";
            }
            SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key102, strPublickey);
            phone_message += message + "\n\n" +
                    "HCID:\n" + HCID + "\n\n" +
                    getTelephoneInfo();
            tv_connecting.setVisibility(View.GONE);
            tv_msg.setVisibility(View.VISIBLE);
            tv_msg.setText(phone_message);
            iv_share.setImageDrawable(getResources().getDrawable(R.drawable.baseline_share_white_18dp));
            iv_phone.setImageDrawable(getResources().getDrawable(R.drawable.baseline_call_green_18dp));
            iv_block.setImageDrawable(getResources().getDrawable(R.drawable.baseline_contact_support_white_18dp));
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    public void setLocale() {
        Locale locale;
        //Toast.makeText(context,"Locale.getDefault():"+Locale.getDefault().toString(),Toast.LENGTH_LONG).show();
        String languageToLoad;
        if (SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key25, "").isEmpty()) {
            if (Locale.getDefault().toString().contains("zh_CN") || Locale.getDefault().toString().contains("sc")) {
                languageToLoad = "sc";
            } else if (Locale.getDefault().toString().contains("zh_TW")) {
                languageToLoad = "tc";
            } else {
                languageToLoad = "en";
            }
            SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key25, languageToLoad);
        } else {
            languageToLoad = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key25, "");
        }
        //if(!languageToLoad.isEmpty()){
        iv_titleIMG = findViewById(R.id.titleIMG);
        if (languageToLoad.equals("sc")) {
            iv_titleIMG.setImageDrawable(getResources().getDrawable(R.drawable.hyperconnectivity2));
        } else if (languageToLoad.equals("tc")) {
            iv_titleIMG.setImageDrawable(getResources().getDrawable(R.drawable.hyperconnectivity_tc));
        } else {
            iv_titleIMG.setImageDrawable(getResources().getDrawable(R.drawable.hyperconnectivity1));
        }

        locale = new Locale(languageToLoad);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }


    private Double getCB(String HCID) {
        return cbDAO.getBalanceByHCID(HCID);
    }

    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm != null ? cm.getActiveNetworkInfo() : null;
        //should check null because in airplane mode it will be null
        return (networkInfo != null && networkInfo.isConnected());
    }

    private class Async_getStatistics extends AsyncTask<String, Void, String> {
        //String type;
        @Override
        protected String doInBackground(String... params) {
            return getStatistics();
        }

        @Override
        protected void onPostExecute(String result) {
            tv_msg.setText(result);
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    private String getStatistics() {
        //double pcb_registration = 25d;
        //double pcb_comp_reg = pcb_registration - new preConnectivityBenifitDAO(context).getPCBForWhat(HCID, "registration");
        //double pcb_comp_intro = new MemberDAO(context).getintro_PCB(HCID) - new preConnectivityBenifitDAO(context).getPCBForWhat(HCID, "introduction");
        //double pcb_comp_fromHC = new HyperConnectivityDAO(context).getSumtoPCBByHcid(HCID) * 3 - new preConnectivityBenifitDAO(context).getPCBForWhat(HCID, "fromHC");
        //double HC_comp_fromCB = new ConnectivityBenifitDAO(context).getSumtoHC(HCID) * 0.85 - new HyperConnectivityDAO(context).getSumfromCBByHcid(HCID);
        //double HC_comp_fromintroCB = new ConnectivityBenifitDAO(context).getSumintrotoHC(HCID) * 0.85 * 0.05 - new HyperConnectivityDAO(context).getSumintro_fromCBByHcid(HCID);
        double CB_sell_CBOrder = new CB_TradingDAO(context).getUSDSum_Sell(HCID);
        double CB_Sold = new CB_TradingDAO(context).getCBSum_Sold(HCID);
        //double CB_comp_sellCB = CB_sell_CBOrder - CB_Sold;
        //Long intervaTime = new Date().getTime() - new HyperConnectivityDAO(context).getLastTimeToPcbByHCID(HCID());
        //Long intervaTime0 = new Date().getTime() - new BlockchainDAO(context).getLastTimeOfHCtoPCB(HCID());
        //Long intervaTime1 = new Date().getTime() - new BlockDAO(context).getLastTimeOfHCtoPCB(HCID());
        String message =
                "HCID: " + HCID + "\n\n" +
                        getResources().getString(R.string.HA_reigistration_block) + " #" + new BlockchainDAO(context).isRegistering(HCID).getIndex() + "\n" +
                        context.getResources().getString(R.string.HA_reigistration_date) + ": " + getDate(new BlockchainDAO(context).isRegistering(HCID).getTimestamp()) + "\n" +
                        context.getResources().getString(R.string.HA_index_pros) + ": " + Utils.formatDoubleToString(new CB_OrderDAO(context).Index_prosperity()) + "\n" +
                        context.getResources().getString(R.string.HA_er) + ": " + Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getGR_byPhase(HCID) * 100) + " %\n" +
                        context.getResources().getString(R.string.HA_em) + ": " + new MemberDAO(context).getExtensioncount(HCID) + "\n" +
                        "\nHC " + context.getResources().getString(R.string.HA_balance) + ": " + Utils.formatDoubleToString(new HyperConnectivityDAO(context).getBalanceByHCID(HCID)) + "\n" +
                        "HC " + context.getResources().getString(R.string.HA_toPCB) + ": " + Utils.formatDoubleToString(new HyperConnectivityDAO(context).getSumtoPCBByHcid(HCID)) + "\n" +
                        //"HC_fromCB: "+Utils.formatDoubleToString(new HyperConnectivityDAO(context).getSumfromCBByHCID(HCID()))+"\n"+
                        //"HC " + context.getResources().getString(R.string.HA_fromCB) + ": "+ new ConnectivityBenifitDAO(context).getSumtoHC(HCID)*0.85+" / "+new HyperConnectivityDAO(context).getSumfromCBByHcid(HCID)+"\n"+
                        "HC " + context.getResources().getString(R.string.HA_introfromCB) + ": " + Utils.formatDoubleToString(new HyperConnectivityDAO(context).getSumintro_fromCBByHcid(HCID)) + "\n" +
                        "HCQ " + getResources().getString(R.string.HA_sum) + ": " + Utils.formatDoubleToString(new MemberDAO(context).getHCQ_sum(HCID)) + "\n" +
                        //"HCQ Sum details" + ": \n"+new MemberDAO(context).getStrHCQ_sum(HCID)+"\n"+

                        "HCQ " + context.getResources().getString(R.string.HA_Oedered) + ": " + Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getSumtoHC(HCID) * 0.85) + "\n" +
                        "HCQ " + getResources().getString(R.string.HA_balance) + ": " + Utils.formatDoubleToString(new MemberDAO(context).getHCQ_balance(HCID)) + "\n" +
                        //"HC_comp_fromCB: "+ Utils.formatDoubleToString(HC_comp_fromCB)+"\n"+
                        //"HC_comp_fromintroCB: "+ Utils.formatDoubleToString(HC_comp_fromintroCB)+"\n"+
                        "\nCB " + context.getResources().getString(R.string.HA_balance) + ": " + Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getBalanceByHCID(HCID)) + "\n" +
                        "CB " + context.getResources().getString(R.string.HA_toHC) + ": " + Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getSumtoHC(HCID)) + "\n" +
                        "CB " + context.getResources().getString(R.string.HA_introtoHC) + ": " + Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getSumintrotoHC(HCID)) + "\n" +
                        "CB " + getResources().getString(R.string.HA_CB_order) + ": " + Utils.formatDoubleToString(new CB_TradingDAO(context).getUSDSum_Order(HCID)) + " USD\n" +
                        "CB " + getResources().getString(R.string.HA_CB_exchanged) + Utils.formatDoubleToString(new CB_TradingDAO(context).getCBSum_Exchanged(HCID)) + "\n" +
                        //"CBQ Exchanged details" + ": \n"+new CB_TradingDAO(context).getStrCBSum_Exchanged(HCID)+"\n"+
                        "CB " + getResources().getString(R.string.HA_CB_selling) + ": " + Utils.formatDoubleToString(CB_sell_CBOrder) + " USD\n" +
                        "CB " + context.getResources().getString(R.string.HA_CB_sold) + ": " + Utils.formatDoubleToString(CB_Sold) + "\n" +
                        //"CB_comp_sellCB: "+Utils.formatDoubleToString(CB_comp_sellCB)+"\n"+
                        "CBQ " + context.getResources().getString(R.string.HA_sum) + ": " + Utils.formatDoubleToString(new MemberDAO(context).getCBQ_sum(HCID)) + " USD\n" +
                        //"CBQ " + context.getResources().getString(R.string.HA_Oedered) + ": "+Utils.formatDoubleToString(new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(HCID))+" USD\n"+
                        "CBQ " + context.getResources().getString(R.string.HA_CBQ_order_balance) + ": " + Utils.formatDoubleToString(new MemberDAO(context).getCBQ_sum(HCID) - new CB_TradingDAO(context).getUSDSum_Order(HCID)) + " USD\n" +
                        "CBQ " + context.getResources().getString(R.string.HA_CBQ_selling_balance) + ": " + Utils.formatDoubleToString(new MemberDAO(context).getCBQ_sum(HCID) - new CB_TradingDAO(context).getUSDSum_Sell(HCID)) + " USD\n" +

                        "\nPCB " + getResources().getString(R.string.HA_balance) + ": " + Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getBalanceByHCID(HCID)) + "\n" +
                        "PCB " + context.getResources().getString(R.string.HA_fromRegistration) + ": " + Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getPCBForWhat(HCID, "registration")) + "\n" +
                        "PCB " + context.getResources().getString(R.string.HA_fromIntroduction) + ": " + new preConnectivityBenifitDAO(context).getPCBForWhat(HCID, "introduction") + "\n" +
                        "PCB " + context.getResources().getString(R.string.HA_fromHC) + ": " + Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getPCBForWhat(HCID, "fromHC")) + "\n" +
                        "PCB " + context.getResources().getString(R.string.HA_activity) + ": " + Utils.formatDoubleToString(Math.abs(new preConnectivityBenifitDAO(context).getPCBForWhat(HCID, "activity"))) + "\n";
        //"PCB_ShouldTake: "+Utils.formatDoubleToString(new MemberDAO(context).getCalculatedPCB_registration_introduction(HCID))+"\n"+
        //"PCB_comp_reg: "+pcb_comp_reg+"\n"+
        //"PCB_comp_intro: "+pcb_comp_intro+"\n"+
        //"PCB_comp_fromHC: "+ Utils.formatDoubleToString(pcb_comp_fromHC);

        return message;
    }

    public String getDate(Long timestamp) {
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy.MM.dd");
        return dt1.format(timestamp);
    }

}
