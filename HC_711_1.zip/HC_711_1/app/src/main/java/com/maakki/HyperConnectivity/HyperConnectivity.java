package com.maakki.HyperConnectivity;


public class HyperConnectivity {
    private String note,hcid;
    private Double amount;
    private Long id,block_index;
    private long createtime;

    public HyperConnectivity() {}

    public void setId( Long id){this.id=id;}
    public Long getId(){return id;}

    public void setBlockIndex( Long block_index){this.block_index=block_index;}
    public Long getBlockIndex(){return block_index;}

    public void setHcid(String hcid){this.hcid=hcid;}
    public String getHcid(){return hcid;}

    public void setAmount(Double amount){this.amount=amount;}
    public double getAmount(){return amount;}

    public void setNote(String note){this.note=note;}
    public String getNote(){return note;}

    public long getCreateTime() {
        return createtime;
    }
    public void setCreateTime(long createtime) {this.createtime = createtime;}
}


