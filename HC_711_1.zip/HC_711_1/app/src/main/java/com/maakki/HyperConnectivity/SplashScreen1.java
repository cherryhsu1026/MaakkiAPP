package com.maakki.HyperConnectivity;

/**
 * Created by ryan on 2015/12/13.
 */

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import java.util.Locale;

public class SplashScreen1 extends Activity {

    // Splash screen timer
    private static int SPLASH_TIME_OUT = 2400;
    //private GifView mGifView;
    //private ImageView imgV;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!isTaskRoot()) {
            final Intent intent = getIntent();
            final String intentAction = intent.getAction();
            if (intent.hasCategory(Intent.CATEGORY_LAUNCHER) && intentAction != null && intentAction.equals(Intent.ACTION_MAIN)) {
                finish();
                return;
            }
        }
        setContentView(R.layout.activity_splash);
        //init();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity
                Intent i = new Intent(SplashScreen1.this, HyperConnActivity.class);
                //Intent i = new Intent(SplashScreen1.this, MainActivity1.class);
                startActivity(i);
                // close this activity
                SplashScreen1.this.finish();
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        }, SPLASH_TIME_OUT);
        setLocale();
    }
    private void setLocale(){
        String languageToLoad="";
        if(Locale.getDefault().getDisplayLanguage().equals("中文")){
            languageToLoad="sc";
        };
        if(!languageToLoad.isEmpty()){
            Locale locale = new Locale(languageToLoad);
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getResources().updateConfiguration(config,getResources().getDisplayMetrics());
        }
        //Toast.makeText(context,"languageToLoad："+languageToLoad,Toast.LENGTH_LONG).show();
    }
    private void init() {
        /*imgV=(ImageView) findViewById(R.id.imgView);
        imgV.setImageResource(R.drawable.welcome0013);*/
        //mGifView = (GifView) findViewById(R.id.gifView);
        //mGifView.setGifImage(R.drawable.logo0504);
        //ImageView iv_splash=(ImageView)findViewById(R.id.iv_splash);
        /*mGifView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println(" Click ");
            }		});*/
        //mGifView.setShowDimension(300, 300);
        // /加载方式
        //mGifView.setGifImageType(GifView.GifImageType.COVER);
    }

}
