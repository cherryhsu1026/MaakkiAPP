package com.maakki.HyperConnectivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class applyBlock {
    private long id;
    private String hash;
    private String datatype;
    private String data,applicant;
    private long createtime;

    public void setId(long id){
        this.id=id;
    }
    public long getId() {
        return id;
    }

    public applyBlock() {
        //hash = apply_Block.calculateHash(this);
    }


    public void setHash(String hash) {this.hash=hash;}
    public String getHash() {return hash;}

    public void setData(String data) {
        this.data=data;
    }
    public String getData() {
        return data;
    }

    public String str() {
        return applicant + createtime +  datatype + data ;
    }

    public String calculateHash(applyBlock ab) {
        if (ab != null) {
            MessageDigest digest;
            try {
                digest = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException e) {
                return null;
            }
            String txt = ab.str();
            final byte bytes[] = digest.digest(txt.getBytes());
            final StringBuilder builder = new StringBuilder();
            for (final byte b : bytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    builder.append('0');
                }
                builder.append(hex);
            }
            return builder.toString();
        }
        return null;
    }

    public void setDatatype(String datatype) {this.datatype=datatype;}
    public String getDatatype() {return datatype;}

    public void setCreateTime(long createtime) {this.createtime=createtime;}
    public long getCreateTime() {return createtime;}

    public void setApplicant(String applicant) {this.applicant=applicant;}
    public String getApplicant() {return applicant;}
}
