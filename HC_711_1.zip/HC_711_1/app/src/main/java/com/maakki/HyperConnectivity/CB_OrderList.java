package com.maakki.HyperConnectivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;

public class CB_OrderList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon;
    Integer count;
    FloatingActionButton fab;
    String HCID,strAccountname;
    private boolean isAscending = false;
    private Context context;
    private List<CB_Order> listcbo;
    private CB_OrderDAO cboDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private CBOAdapter adapter;
    private BroadcastReceiver receiver;
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    //Block block;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            switch (menuItem.getItemId()) {
                case R.id.cb_trading:
                    Intent i =new Intent(CB_OrderList.this,CB_TradingList.class);
                    startActivity(i);
                    break;
                case R.id.addorder_buy:
                    if(new MemberDAO(context).getCBQ_sum(HCID)-new CB_TradingDAO(context).getUSDSum_Order(HCID)>20){
                        show_addOrder_Dialog1();
                    }else{
                        String title=getResources().getString(R.string.addorder_noCBQ_title);
                        String message=getResources().getString(R.string.addorder_noCBQ_message);
                        showMessageAlertDialog(title,message);
                    }
                    break;
                case R.id.addorder_sell:
                    String title="";
                    String message="";
                    if(getSellCBAvailable()==0){
                        show_addOrder_sell_Dialog1();
                    }else if(getSellCBAvailable()==1) {
                        title = getResources().getString(R.string.addorder_sell_fail_title);
                        message = getResources().getString(R.string.addorder_sell_fail_message1);
                    }else if(getSellCBAvailable()==2) {
                        title = getResources().getString(R.string.addorder_sell_fail_title);
                        message = getResources().getString(R.string.addorder_sell_fail_message2);
                    }else if(getSellCBAvailable()==3) {
                        title = getResources().getString(R.string.addorder_sell_fail_title);
                        message = getResources().getString(R.string.addorder_sell_fail_message3);
                    }else if(getSellCBAvailable()==4) {
                        title = getResources().getString(R.string.addorder_sell_fail_title);
                        message = getResources().getString(R.string.addorder_sell_fail_message4);
                    }
                    if(getSellCBAvailable()>0){
                        showMessageAlertDialog(title,message);
                    }
                    break;
                case R.id.delete:
                    AlertDialog alertDialog = new AlertDialog.Builder(CB_OrderList.this).create();
                    alertDialog.setTitle("将要删除CB_Order记录");
                    alertDialog.setMessage("您确定要删除所有CB_Order的记录吗？");
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "确定",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    listview.setVisibility(View.INVISIBLE);
                                    fab.setVisibility(View.INVISIBLE);
                                    RL_nothing.setVisibility(View.VISIBLE);
                                    cboDAO.deleteAll();
                                    cboDAO=new CB_OrderDAO(context);
                                    listcbo.clear();
                                    myToolbar.setTitle("");
                                    //adapter.notifyDataSetChanged();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "略过",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    break;
            }
            return true;
        }
    };

    private int getSellCBAvailable() {
        int result=0;
        if (new ConnectivityBenifitDAO(context).getBalanceByHCID(HCID) < 1000) {
            result=1;
        }else if(new RequestActivationDAO(context).isActivated(HCID) & new MemberDAO(context).getExtensioncount(HCID)<3){
            result=2;
        }else if(!new RequestActivationDAO(context).isActivated(HCID) & new MemberDAO(context).getExtensioncount(HCID)<6){
            result=3;
        }else if(new MemberDAO(context).getCBQ_sum(HCID)-new CB_TradingDAO(context).getUSDSum_Sell(HCID) < 10){
            result=4;
        }
        return result;
    }

    public void show_addOrder_sell_Dialog1() {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.cb_order_dialog, null);
        ImageView iv=(ImageView) view.findViewById(R.id.iv);
        iv.setImageDrawable(getResources().getDrawable(R.drawable.cb));
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        String title=getResources().getString(R.string.addorder_sell_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        String message1=getResources().getString(R.string.addorder_sell_message1);
        String message2=getResources().getString(R.string.addorder_sell_message2);
        String message3=getResources().getString(R.string.addorder_sell_message3);
        String message4=getResources().getString(R.string.addorder_sell_message4);
        String message5=getResources().getString(R.string.addorder_sell_message5);
        Double CB_amount=new ConnectivityBenifitDAO(context).getBalanceByHCID(HCID);
        String strCB_amount=Utils.formatDoubleToString(CB_amount);
        if(CB_amount>1000){
            //String message=message1 +new MemberDAO(context).getCBQ_balance(HCID)+ " " +message2+ getEstimatedDate() + message3;
            //String message=message1 + "1,000" + message2 + " "+ getEstimatedUSD() + message3 + getEstimatedDate() + " " + message4 + Utils.formatDoubleToString(getEstimatedFee()) +" " + message5;
            String message=message1 + strCB_amount + message2 + " "+ getEstimatedUSD(CB_amount) + message3 + getEstimatedDate() + " " + message4 + Utils.formatDoubleToString(getEstimatedFee(CB_amount)) +" " + message5;
            tv_message.setText(message);
            TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
            String submessage=getResources().getString(R.string.hclist_dialog_submessage);
            tv_submessage.setText(submessage);
            alertDialog.setView(view);
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            CB_Order cbo=new CB_Order();
                            cbo.setHcid(HCID);
                            cbo.setIsbuy(false);
                            cbo.setCurrency("RMB");
                            cbo.setCB_Amount(Double.parseDouble(String.format( "%.0f", CB_amount )));
                            cbo.setCreateTime(new Date().getTime());
                            String hash=cbo.calculateHash(cbo);
                            cbo.setHash(hash);
                            show_addOrder_sell_accountdata(cbo);
                            dialog.dismiss();

                        }
                    });
        }
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_termsofservice),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i=new Intent(context,ServiceTerm_Activity.class);
                        startActivity(i);
                        //dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        Button theButton = alertDialog.getButton(DialogInterface.BUTTON_NEUTRAL);
        theButton.setOnClickListener(new CustomListener(alertDialog));
    }

    class CustomListener implements View.OnClickListener {
        private final Dialog dialog;

        public CustomListener(Dialog dialog) {
            this.dialog = dialog;
        }

        @Override
        public void onClick(View v) {
            // Do whatever you want here
            Intent i=new Intent(context,ServiceTerm_Activity.class);
            startActivity(i);
            // If you want to close the dialog, uncomment the line below
            //dialog.dismiss();
        }
    }

    private void show_addOrder_sell_accountdata(CB_Order cbo){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.sellcb_accountdata, null);
        /*String bankdata=getResources().getString(R.string.bankdata_accountname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_accountno_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_bankname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_branchname_cashflow_1);*/
        TextView tv_message=(TextView) view.findViewById(R.id.tv_message);
        String message=getResources().getString(R.string.sellcb_accountdata_message);
        tv_message.setText(message);
        strAccountname="";
        final EditText et_account_name=(EditText)view.findViewById(R.id.et_accountname);
        String straccount_name=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key28,"");
        if(!straccount_name.isEmpty()){
            et_account_name.setText(straccount_name);
        }
        final EditText et_account_no=(EditText)view.findViewById(R.id.et_accountno);
        String straccount_no=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key29,"");
        if(!straccount_no.isEmpty()){
            et_account_no.setText(straccount_no);
        }
        final EditText et_bank_name=(EditText)view.findViewById(R.id.et_bank_name);
        String strbank_name=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key30,"");
        if(!strbank_name.isEmpty()){
            et_bank_name.setText(strbank_name);
        }
        final EditText et_bank_bank_branch=(EditText)view.findViewById(R.id.et_bank_branch);
        String strbank_branch=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key31,"");
        if(!strbank_branch.isEmpty()){
            et_bank_bank_branch.setText(strbank_branch);
        }
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (!et_account_name.getText().toString().trim().isEmpty() &
                                !et_account_no.getText().toString().trim().isEmpty() &
                                !et_bank_name.getText().toString().trim().isEmpty() &
                                !et_bank_bank_branch.getText().toString().trim().isEmpty()) {
                            SharedPreferencesHelper.putSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key28,et_account_name.getText().toString().trim());
                            SharedPreferencesHelper.putSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key29,et_account_no.getText().toString().trim());
                            SharedPreferencesHelper.putSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key30,et_bank_name.getText().toString().trim());
                            SharedPreferencesHelper.putSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key31,et_bank_bank_branch.getText().toString().trim());
                            String note = et_account_name.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" +
                                    et_account_no.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" +
                                    et_bank_name.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_"  +
                                    et_bank_bank_branch.getText().toString().trim().replace("_", "-").replace(" ", "-") ;

                            String datatype = "CB_Order";
                            String data = cbo.getIsbuy() + " " + cbo.getHash() + " " + cbo.getHcid() + " 26 " +  "n/a " + cbo.getCB_Amount()  + " " + cbo.getCreateTime() + " " + cbo.getCurrency() + " " + note;
                            makeBlock(datatype,data);
                            Block block = new Block();
                            block.setDatatype(datatype);
                            block.setData(data);
                            block.insertCB_OrderDAO(context,block);
                            renewlist();
                        }
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private Double getEstimatedFee(Double cb){
        Double result=5d;
        if(new RequestActivationDAO(context).isActivated(HCID)){
            if(cb*new CB_TradingDAO(context).getCR()*0.15>result){
                result=cb*new CB_TradingDAO(context).getCR()*0.15;
            }
        }else if(cb*new CB_TradingDAO(context).getCR()*0.5>result){
            result=cb*new CB_TradingDAO(context).getCR()*0.5;
        }
        return result;
    }

    private void show_addOrder_Dialog1() {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.cb_order_dialog, null);
        ImageView iv=(ImageView) view.findViewById(R.id.iv);
        iv.setImageDrawable(getResources().getDrawable(R.drawable.cb));
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        String title=getResources().getString(R.string.cb_orderlist_dialog_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        String message1=getResources().getString(R.string.cb_orderlist_dialog_message1);
        String message2=getResources().getString(R.string.cb_orderlist_dialog_message2);
        String message3=getResources().getString(R.string.cb_orderlist_dialog_message3);
        String message4=getResources().getString(R.string.cb_orderlist_dialog_message4);
        //String message=message1 +new MemberDAO(context).getCBQ_balance(HCID)+ " " +message2+ getEstimatedDate() + message3;
        String message=message1 + Utils.formatDoubleToString(new MemberDAO(context).getCBQ_balance(HCID))+ " " +message2 + getEstimatedCB() + message3+ getEstimatedDate()+ message4;
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        String submessage=getResources().getString(R.string.hclist_dialog_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        CB_Order cbo=new CB_Order();
                        cbo.setHcid(HCID);
                        cbo.setIsbuy(true);
                        String cashflow1=getResources().getString(R.string.hcid_cashflow_1);
                        cbo.setCashflow_1(cashflow1);
                        Double amount=Utils.multiply(
                                new MemberDAO(context).getCBQ_balance(HCID) ,
                                Double.parseDouble(getResources().getString(R.string.exchangerate_RMB)));
                        if(amount>0) {
                            cbo.setAmount(amount);
                            cbo.setCurrency("RMB");
                            cbo.setCreateTime(new Date().getTime());
                            String hash = cbo.calculateHash(cbo);
                            cbo.setHash(hash);
                            String datatype = "CB_Order";
                            String currency = "RMB";
                            String note = "_";
                            Boolean isBuy = true;
                            String data = isBuy + " " + hash + " " + HCID + " 20 " + cashflow1 + " " + amount + " " + new Date().getTime() + " " + currency + " " + note;
                            makeBlock(datatype, data);
                            Block block = new Block();
                            block.setDatatype(datatype);
                            block.setData(data);
                            block.insertCB_OrderDAO(context, block);
                            renewlist();
                            showActivationDialog2(hash);
                        }

                        dialog.dismiss();

                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_termsofservice),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i=new Intent(context,ServiceTerm_Activity.class);
                        startActivity(i);
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        Button theButton = alertDialog.getButton(DialogInterface.BUTTON_NEUTRAL);
        theButton.setOnClickListener(new CustomListener(alertDialog));
    }

    private class Async_checkData extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            return checkData();
            //return true;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            renewlist();

        }

        @Override
        protected void onPreExecute() {
            //RL_nothing.setVisibility(View.VISIBLE);
            //tv_nothing.setText(getResources().getString(R.string.Async_checkdata_Onpre));
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private Boolean checkData() {
        BlockchainDAO blockchainDAO = new BlockchainDAO(context);
        cboDAO.clear();
        for (Block block : blockchainDAO.getAll()) {
            if (block.getDatatype().equals("CB_Order")) {
                block.insertCB_OrderDAO(context,block);
                //updateCB_OrderDAO(block);
            }
        }
        for (Block block : new BlockDAO(context).getAll()) {
            if (block.getDatatype().equals("CB_Order")) {
                block.insertCB_OrderDAO(context,block);
            }
        }
        return true;
    }

    private void renewlist(){
        listcbo.clear();
        for(CB_Order cbo:cboDAO.getAll()){
            if(cbo.getStatus()<30){
                listcbo.add(cbo);
            }
        };
        //Collections.reverse(listcbo);
        adapter.notifyDataSetChanged();
        if(cboDAO.getCount()>0){
            listview.setVisibility(View.VISIBLE);
            RL_nothing.setVisibility(View.GONE);
            myToolbar.setTitle(getResources().getString(R.string.title_cbOrderList)+" "+listcbo.size());
        }else{
            listview.setVisibility(View.GONE);
            RL_nothing.setVisibility(View.VISIBLE);
            myToolbar.setTitle("");
        }
    }

    private void feedbackRemittance(CB_Order cbo){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.feedback_remittance_dialog, null);
        String bankdata=getResources().getString(R.string.bankdata_accountname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_accountno_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_bankname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_branchname_cashflow_1);
        TextView tv_message=(TextView) view.findViewById(R.id.tv_message);
        String message=getResources().getString(R.string.feedback_remittance_message)+"\n\n"+bankdata+"\n"+cbo.getAmount()+" "+cbo.getCurrency();
        tv_message.setText(message);
        TextView tv_submessage=(TextView) view.findViewById(R.id.tv_submessage);
        String submessage=HCID+"\n"+getResources().getString(R.string.feedback_remittance_submessage);
        tv_submessage.setText(submessage);
        strAccountname="";
        final EditText et_account_name=(EditText)view.findViewById(R.id.et_accountname);
        final EditText et_account_no=(EditText)view.findViewById(R.id.et_accountno);
        final EditText et_bank_name=(EditText)view.findViewById(R.id.et_bank_name);
        //final EditText et_bank_branch=(EditText)view.findViewById(R.id.et_bank_branch);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (!et_account_name.getText().toString().trim().isEmpty() &
                                !et_account_no.getText().toString().trim().isEmpty() &
                                !et_bank_name.getText().toString().trim().isEmpty() ) {
                            String note = et_account_name.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" +
                                    et_account_no.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" +
                                    et_bank_name.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" ;

                            String datatype = "CB_Order";
                            String data = cbo.getIsbuy() + " " + cbo.getHash() + " " + cbo.getHcid() + " 21 " + cbo.getCashflow_1() + " " + cbo.getAmount() + " " + cbo.getCreateTime() + " " + cbo.getCurrency() + " " + note;
                            makeBlock(datatype,data);
                            Block block = new Block();
                            block.setDatatype(datatype);
                            block.setData(data);
                            block.insertCB_OrderDAO(context,block);
                            renewlist();
                        }
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public void showMessageAlertDialog(String title,String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        alertDialog.show();
    }

    public String getEstimatedDate(){
        Date d = new Date();
        Long satrtdate=d.getTime()+24*60*60*1000;
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy.MM.dd");
        int count=new CB_OrderDAO(context).getCount();
        long interval_time=1000*60*60*24*count*Long.parseLong(getResources().getString(R.string.intervalDays_activation_estimation));
        return dt1.format(satrtdate+interval_time);
        //return "2019.10.01";
    }

    public String getEstimatedUSD(Double cb){
        return Utils.formatDoubleToString(cb * new CB_TradingDAO(context).getCR()-getEstimatedFee(cb));
    }

    public String getEstimatedCB(){
       return Utils.formatDoubleToString(new MemberDAO(context).getCBQ_balance(HCID) / new CB_TradingDAO(context).getCR());
    }

    public void showActivationDialog2(String hash) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        ImageView iv=(ImageView) view.findViewById(R.id.iv);
        iv.setImageDrawable(getResources().getDrawable(R.drawable.ic_launcher));
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        String title=getResources().getString(R.string.hclist_dialog2_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        String message1=getResources().getString(R.string.hclist_dialog2_message);
        String message2=getResources().getString(R.string.bankdata_accountname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_accountno_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_bankname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_branchname_cashflow_1);
        String message=message1+"\n\n"+message2;
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        String submessage=getResources().getString(R.string.hclist_dialog2_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_now),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        feedbackRemittance(cboDAO.getByHash(hash));
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_later),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void makeBlock(String datatype, String data) {
        Intent intent = new Intent(CB_OrderList.this, CoreService.class);
        intent.putExtra("Message", datatype + ":" + data);
        startService(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        //HCID = getResources().getString(R.string.hcid_cashflow_1);
        //ShortcutBadger.with(getApplicationContext()).remove();
        listcbo = new ArrayList<>();
        cboDAO = new CB_OrderDAO(this);
        //block = new Block();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();;
            }
        });
        //
        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no CBOrder created..");
        listcbo = cboDAO.getUnder30();
        count = listcbo.size();
        adapter = new CBOAdapter(this, R.layout.list_item, listcbo);
        listview.setAdapter(adapter);
        if (count > 0) {
            myToolbar.setTitle(getResources().getString(R.string.title_cbOrderList)+" "+count);
            if (count > 20) {
                fab.setVisibility(View.VISIBLE);
            }
            //setOnClick();
            fab.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }

                    Collections.reverse(listcbo);
                    adapter.notifyDataSetChanged();
                }
            });

        } else {
            myToolbar.setTitle("");
            RL_nothing.setVisibility(View.VISIBLE);
        }
        //set Receiver
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_CB_OrderList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

            }
        };
        registerReceiver(receiver, filter);

        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //if (new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)) {
            setOnClick();
        //}
        Async_checkData checkDataTask=new Async_checkData();
        checkDataTask.execute();
    }

    public void setOnClick() {
        //listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                CB_Order cbo = listcbo.get(position);
                if(cbo.getHcid().equals(HCID)){
                    if(cbo.getStatus()==20){
                        feedbackRemittance(cbo);
                    }
                }
                if(cbo.getCashflow_1().equals(HCID)){
                    if((cbo.getStatus()==20 & !cbo.getHcid().equals(HCID))||cbo.getStatus()==21) {
                        confirmRemittance_cf1_part1(cbo);
                    }
                }
                if(cbo.getCashflow_2().equals(HCID)){
                    if(cbo.getStatus()==22){
                        confirmRemittance_cf2(cbo);
                    }
                }
                if(new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)){
                    if(cbo.getStatus()==26) {
                        if(new CB_OrderDAO(context).getBalance(cbo.getHash())>0) {
                            confirmCBRealease(cbo);
                        }
                    }
                }
            }
        });
    }

    private void confirmRemittance_cf1_part1(CB_Order cbo){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_remittance, null);
        String bankdata = cbo.getHcid()+"\n\n"+cbo.getNote().replace("_","\n");
        TextView tv_bankdata=(TextView)view.findViewById(R.id.tv_bankdata);
        tv_bankdata.setText(bankdata);
        TextView tv_amount =(TextView)view.findViewById(R.id.tv_amount);
        tv_amount.setText(String.valueOf(cbo.getAmount()));
        TextView tv_currency =(TextView)view.findViewById(R.id.tv_currency);
        tv_currency.setText(cbo.getCurrency());
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        confirmRemittance_cf1_part2(cbo);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_delete),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String datatype="CB_Order";
                        String note="_";
                        String data = cbo.getIsbuy() + " " + cbo.getHash() + " " + cbo.getHcid() + " 41 " + cbo.getCashflow_1() + " " + cbo.getAmount() + " " + cbo.getCreateTime() + " " + cbo.getCurrency() + " " + note;
                        //String data=cbo.getHash()+" "+cbo.getHcid()+" 22 "+cbo.getCashflow_2()+" "+cbo.getAmount()+" RMB "+cbo.getCreateTime()+" "+note;
                        makeBlock(datatype,data);
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        block.insertCB_OrderDAO(context,block);
                        renewlist();
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void confirmRemittance_cf1_part2(CB_Order cbo){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_remittance, null);
        TextView tv_title=(TextView)view.findViewById(R.id.tv_title);
        tv_title.setText(getResources().getString(R.string.confirm_remittance1_title_part2));
        TextView tv_message=(TextView)view.findViewById(R.id.tv_message);
        tv_message.setText(getResources().getString(R.string.confirm_remittance1_message_part2));
        TextView tv_submessage=(TextView)view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(getResources().getString(R.string.confirm_remittance1_submessage_par2));
        //String[] bankdata=ra.getNote().split("_");
        TextView tv_bankdata=(TextView)view.findViewById(R.id.tv_bankdata);
        String bankdata=getResources().getString(R.string.bankdata_accountname_cashflow_2)+"\n"+
                getResources().getString(R.string.bankdata_accountno_cashflow_2)+"\n"+
                getResources().getString(R.string.bankdata_bankname_cashflow_2)+"\n"+
                getResources().getString(R.string.bankdata_branchname_cashflow_2);
        tv_bankdata.setText(bankdata);
        TextView tv_amount =(TextView)view.findViewById(R.id.tv_amount);
        tv_amount.setText(String.valueOf(cbo.getAmount()));
        TextView tv_currency =(TextView)view.findViewById(R.id.tv_currency);
        tv_currency.setText(cbo.getCurrency());
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String note=getResources().getString(R.string.bankdata_accountname_cashflow_1)+"_"+
                                getResources().getString(R.string.bankdata_accountno_cashflow_1)+"_"+
                                getResources().getString(R.string.bankdata_bankname_cashflow_1)+"_"+
                                getResources().getString(R.string.bankdata_branchname_cashflow_1);
                        cbo.setNote(note);
                        cbo.setStatus(22);
                        //new RequestActivationDAO(context).update(ra);
                        String datatype="CB_Order";
                        String data = cbo.getIsbuy() + " " + cbo.getHash() + " " + cbo.getHcid() + " 22 " + cbo.getCashflow_1() + " " + cbo.getAmount() + " " + cbo.getCreateTime() + " " + cbo.getCurrency() + " " + note;
                        //String data=cbo.getHash()+" "+cbo.getHcid()+" 22 "+cbo.getCashflow_2()+" "+cbo.getAmount()+" RMB "+cbo.getCreateTime()+" "+note;
                        makeBlock(datatype,data);
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        block.insertCB_OrderDAO(context,block);
                        renewlist();
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void confirmRemittance_cf2(CB_Order cbo){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_remittance, null);
        TextView tv_title=(TextView)view.findViewById(R.id.tv_title);
        tv_title.setText(getResources().getString(R.string.confirm_remittance2_title));
        String bankdata=cbo.getNote().replace("_","\n");
        TextView tv_bankdata=(TextView)view.findViewById(R.id.tv_bankdata);
        tv_bankdata.setText(bankdata);
        TextView tv_amount =(TextView)view.findViewById(R.id.tv_amount);
        tv_amount.setText(String.valueOf(cbo.getAmount()));
        TextView tv_currency =(TextView)view.findViewById(R.id.tv_currency);
        tv_currency.setText(String.valueOf(cbo.getCurrency()));
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String note=getResources().getString(R.string.note_status26);
                        cbo.setNote(note);
                        String datatype="CB_Order";
                        //String data=cbo.getHash()+" "+cbo.getHcid()+" 26 "+cbo.getCashflow_1()+" "+cbo.getAmount()+" RMB "+cbo.getCreateTime()+" "+note;
                        String data = cbo.getIsbuy() + " " + cbo.getHash() + " " + cbo.getHcid() + " 26 " + cbo.getCashflow_1() + " " + cbo.getAmount() + " " + cbo.getCreateTime()+ " " + cbo.getCurrency() + " " + note;
                        makeBlock(datatype,data);
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        block.insertCB_OrderDAO(context,block);
                        renewlist();
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private Double getAmount_realease(CB_Order cbo){
        double result=7200d;
        double amount=0d;
        if(cbo.getIsbuy()){
            if(cbo.getCurrency().equals("USD")){
                amount=Utils.multiply(new CB_OrderDAO(context).getBalance(cbo.getHash()),Double.parseDouble(getResources().getString(R.string.exchangerate_RMB)));
            }else{
                amount=new CB_OrderDAO(context).getBalance(cbo.getHash());
            }
            if(amount>720){
                result=720;
            }else{
                result=amount;
            }
        }
        return result;
    }

    private void confirmCBRealease(CB_Order cbo){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_OrderList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_activation, null);
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy.MM.dd");
        String title=getResources().getString(R.string.confirm_newCB_title);
        TextView tv_ttile=(TextView)view.findViewById(R.id.tv_title);
        tv_ttile.setText(title);
        String message=getResources().getString(R.string.confirm_newCB_message);
        TextView tv_message=(TextView)view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        String submessage=getResources().getString(R.string.confirm_newCB_submessage);
        TextView tv_submessage=(TextView)view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(submessage);
        String message1=dt1.format(cbo.getCreateTime())+"\n"+cbo.getHcid()+
                    "\n\nCBOHash.size(): "+new CB_TradingDAO(context).getListByCBOrderHash(cbo.getHash()).size()+
                    "\ngetCR()*100(%): "+Utils.formatDoubleToString(new CB_TradingDAO(context).getCR()*100)+"%"+
                    "\ngetBalance(hash):"+new CB_OrderDAO(context).getBalance(cbo.getHash())+" "+cbo.getCurrency()+
                    "\nAmount_realease: "+getAmount_realease(cbo);

        TextView tv_message1 = (TextView) view.findViewById(R.id.tv_message1);
        tv_message1.setText(message1);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //String note=String.valueOf(new CB_OrderDAO(context).getOrderBalance());
                        String datatype = "CB_Trading";
                        //CR up 0.1%
                        Double newCR=new CB_TradingDAO(context).getCR()*1.001;
                        String strCR=Utils.formatDouble_point5(newCR);
                        Double amount=getAmount_realease(cbo);
                        String strAmount=String.format( "%.2f", amount );
                        Double cb_amount=amount/newCR;
                        cb_amount=cb_amount/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
                        String strCB_amount=String.format( "%.2f", cb_amount );
                        String data = "HyperConn " + cbo.getHash() + " " + strAmount + " RMB "+strCR+" 31 "+strCB_amount ;
                        makeBlock(datatype,data);
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        block.insertCB_TradingDAO(context,block);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_cb_orderlist, menu);
        return true;
    }
    @Override
    protected void onStop() {
        super.onStop();
        //finish();
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class CBOAdapter extends ArrayAdapter<CB_Order> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public CBOAdapter(Context context, int textViewResourceId, List<CB_Order> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            CB_Order cbo  = (CB_Order) getItem(position);

            if (convertView == null) {
                //Toast.makeText(CB_OrderList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(CB_OrderList.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();
            int icon = R.drawable.buy_cb;
            if(!cbo.getIsbuy()){
                icon=R.drawable.sell_cb;
            }
            String fm = "";
            //Date date = new Date(time);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            fm = formatter.format(cbo.getCreateTime());
            //new SimpleDateFormat(dateFormat).format(new Date(p.getLastModify()));
            String title="Block #"+cbo.getBlockIndex();
            String message=cbo.getStatus()+" / ";
            if(cbo.getIsbuy()){
                title += " "+cbo.getAmount()+" "+cbo.getCurrency();
                message += Utils.formatDoubleToString(cbo.getAmount()/new CB_TradingDAO(context).getCR()/Double.parseDouble(getResources().getString(R.string.exchangerate_RMB)));
            }else{
                title += " "+cbo.getCB_Amount();
                message += Utils.formatDoubleToString( cbo.getCB_Amount()*new CB_TradingDAO(context).getCR())+" "+cbo.getCurrency();
            }
            message += " "+Utils.formatDoubleToString(new CB_TradingDAO(context).getCR()*100)+"%"+
                    "\n"+cbo.getHcid()+"\n"+cbo.getHash();
            holder.text_title.setText(title);
            holder.text_message.setText(message);

            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            //}
            return view;
            //return convertView;
        }
        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

}
