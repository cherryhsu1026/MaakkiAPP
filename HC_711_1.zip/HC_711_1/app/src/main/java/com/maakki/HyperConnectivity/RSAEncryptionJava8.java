package com.maakki.HyperConnectivity;

import android.content.Context;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.interfaces.ECPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;

// Java 8 example for RSA encryption/decryption.
// Uses strong encryption with 2048 key size.
public class RSAEncryptionJava8 {

    private static String encryptedMessage="";
    private static PublicKey publicKey=null;
    private static PrivateKey privateKey=null;
    private static Map<String, Object> keys;
    //保存文件的路径
    private static final String CACHE_IMAGE_DIR = "HyperConn";
    //保存的文件 采用隐藏文件的形式进行保存
    private static final String DEVICES_FILE_NAME = "Privatekey.txt";
    //private static final String DOCUMENT_FILE_NAME = "Document.txt";

    public static String getCryphotography(String plainText,PublicKey publicKey,PrivateKey privateKey) throws Exception {

        String message_processing="";
        String encryptedText = encryptMessage(plainText, privateKey);
        String descryptedText = decryptMessage(encryptedText, publicKey);
        //String encryptedText = encryptMessage(plainText, publicKey);
        //String descryptedText = decryptMessage(encryptedText, privateKey);
        message_processing="Phone number:\n" + plainText +
                //"\n\nPrivateKey:\n"+ privateKeyToString()+
                "\n\nEncrypted Message:\n" + encryptedText +
                "\nPublicKey:\n"+ PublicKeyToString(publicKey);
        if(descryptedText.equals(plainText)){
            message_processing+="\nAsymetric Cryptography Works!";
        }else{
            message_processing+="\nAsymetric Cryptography Fails!";
        }
        return message_processing;
    }

    // Get RSA keys. Uses key size of 1024.
    public static Map<String,Object> getRSAKeys(String hcid) throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        SecureRandom sr = new SecureRandom(hcid.getBytes());
        keyPairGenerator.initialize(1024,sr);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        privateKey = keyPair.getPrivate();
        publicKey = keyPair.getPublic();
        keys = new HashMap<String,Object>();
        keys.put("private", privateKey);
        keys.put("public", publicKey);
        return keys;
    }

    // Decrypt using RSA public key
    public static String decryptMessage(String encryptedText, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, publicKey);
        //return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedText)));
        return new String(cipher.doFinal(android.util.Base64.decode(encryptedText, android.util.Base64.DEFAULT)));
    }

    // Encrypt using RSA private key
    public static String encryptMessage(String plainText, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, privateKey);
        //encryptedMessage=Base64.getEncoder().encodeToString(cipher.doFinal(plainText.getBytes()));
        encryptedMessage =  android.util.Base64.encodeToString(cipher.doFinal(plainText.getBytes()),android.util.Base64.DEFAULT);

        return encryptedMessage;
    }
    public static String getEncryptedMessage(){
        return encryptedMessage;
    }

    public static PublicKey stringToPublicKey(String publStr) throws Exception{
        //byte[] publicBytes = Base64.getDecoder().decode(publStr);
        byte[] publicBytes = android.util.Base64.decode(publStr, android.util.Base64.DEFAULT);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(publicBytes);
        KeyFactory fact = KeyFactory.getInstance("RSA");
        return fact.generatePublic(spec);
    }
    public static PrivateKey stringToPrivateKey(String strPrivateKey) throws Exception{
        //byte[] privateBytes = Base64.getDecoder().decode(strPrivateKey);
        byte[] privateBytes = android.util.Base64.decode(strPrivateKey, android.util.Base64.DEFAULT);
        PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateBytes);
        KeyFactory fact = KeyFactory.getInstance("RSA");
        return fact.generatePrivate(privateKeySpec);
    }
    public static PrivateKey getPrivateKey(String hcid) throws Exception{
        privateKey=(PrivateKey) getRSAKeys(hcid).get("private");
        return privateKey;
    }
    public static PublicKey getPublicKey() throws Exception{
        return publicKey;
    }

    public static String PrivateKeyToString(PrivateKey key) throws Exception{
        byte[] encodedPrivateKey = key.getEncoded();
        //String b64PrivteKey = Base64.getEncoder().encodeToString(encodedPrivateKey);
        String b64PrivteKey = android.util.Base64.encodeToString(encodedPrivateKey,android.util.Base64.DEFAULT);
        return b64PrivteKey;
    }

    public static String PublicKeyToString(PublicKey key){
        byte[] encodedPublicKey = key.getEncoded();
        //String b64PublicKey = Base64.getEncoder().encodeToString(encodedPublicKey);
        String b64PublicKey = android.util.Base64.encodeToString(encodedPublicKey,android.util.Base64.DEFAULT);
        return b64PublicKey;
    }

    public static void saveDeviceID(String str, Context context) {
        File file = getDevicesDir(context);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            Writer out = new OutputStreamWriter(fos, "UTF-8");
            out.write(str);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String readDeviceID(Context context) {
        File file = getDevicesDir(context);
        StringBuffer buffer = new StringBuffer();
        try {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
            Reader in = new BufferedReader(isr);
            int i;
            while ((i = in.read()) > -1) {
                buffer.append((char) i);
            }
            in.close();
            return buffer.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    private static File getDevicesDir(Context context) {
        File mCropFile = null;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File cropdir = new File(Environment.getExternalStorageDirectory(), CACHE_IMAGE_DIR);
            if (!cropdir.exists()) {
                cropdir.mkdirs();
            }
            mCropFile = new File(cropdir, DEVICES_FILE_NAME);
        } else {
            File cropdir = new File(context.getFilesDir(), CACHE_IMAGE_DIR);
            if (!cropdir.exists()) {
                cropdir.mkdirs();
            }
            mCropFile = new File(cropdir, DEVICES_FILE_NAME);
        }
        return mCropFile;
    }

    public static PublicKey getFromPrivateKey(PrivateKey privateKey)throws Exception{
        PublicKey publicKey=null;
            KeyFactory kf = KeyFactory.getInstance("RSA");
            RSAPrivateKeySpec priv = kf.getKeySpec(privateKey, RSAPrivateKeySpec.class);
            RSAPublicKeySpec keySpec = new RSAPublicKeySpec(priv.getModulus(), BigInteger.valueOf(65537));
            publicKey = kf.generatePublic(keySpec);
            return publicKey;
    }
    //public String getDigitalSignature(String text, String strPrivateKey)  {
    public String getDigitalSignature(String text,String hcid)  {

            try {
            // Get private key from String
            //PrivateKey pk = stringToPrivateKey(strPrivateKey);
            PrivateKey pk = getPrivateKey(hcid);
            // text to bytes
            byte[] data = text.getBytes("UTF8");

            // signature
            //Signature sig = Signature.getInstance("MD5WithRSA");
            Signature sig = Signature.getInstance("SHA1withRSA");
            sig.initSign(pk);
            sig.update(data);
            byte[] signatureBytes = sig.sign();
            //return javax.xml.bind.DatatypeConverter.printBase64Binary(signatureBytes);
            //return new String(signatureBytes);
            //return Base64.getEncoder().encodeToString(signatureBytes);
            return android.util.Base64.encodeToString(signatureBytes,android.util.Base64.DEFAULT);

        }catch(Exception e){
            return null;
        }

    }
    public static boolean verfiySignature(String signature, String original, String publicKey){
        try{
            // Get public key from String
            PublicKey pk = stringToPublicKey(publicKey);

            // text to bytes
            byte[] originalBytes = original.getBytes("UTF8");

            //signature to bytes
            //byte[] signatureBytes = signature.getBytes("UTF8");
            //byte[] signatureBytes =javax.xml.bind.DatatypeConverter.parseBase64Binary(signature);
            //byte[] signatureBytes = Base64.getDecoder().decode(signature);
            byte[] signatureBytes = android.util.Base64.decode(signature, android.util.Base64.DEFAULT);            Signature sig = Signature.getInstance("MD5WithRSA");
            sig.initVerify(pk);
            sig.update(originalBytes);

            return sig.verify(signatureBytes);

        }catch(Exception e){
            e.printStackTrace();
            //Logger log = Logger.getLogger(RsaCipher.class);
            //log.error("error for signature:" + e.getMessage());
            return false;
        }

    }


}
