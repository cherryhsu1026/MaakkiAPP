package com.maakki.HyperConnectivity;


public class ConnectivityBenifit {
    private String sender,receiver,note;
    private Double amount;
    private Long id,block_index;
    private long createtime;

    public ConnectivityBenifit() {}

    public void setId( Long id){this.id=id;}
    public Long getId(){return id;}

    public void setBlockIndex( Long block_index){this.block_index=block_index;}
    public Long getBlockIndex(){return block_index;}

    public void setSender(String sender){this.sender=sender;}
    public String getSender(){return sender;}

    public void setReceiver(String receiver){this.receiver=receiver;}
    public String getReceiver(){return receiver;}

    public void setAmount(Double amount){this.amount=amount;}
    public double getAmount(){return amount;}

    public void setNote(String note){this.note=note;}
    public String getNote(){return note;}

    //TimeStamp
    public long getCreateTime() {
        return createtime;
    }
    public void setCreateTime(long createtime) {this.createtime = createtime;}


}


