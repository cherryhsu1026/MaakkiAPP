package com.maakki.HyperConnectivity;



import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;

/**
 * Created by ryan on 2017/7/17.
 */

public class CB_TradingList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon;
    Integer count;
    FloatingActionButton fab;
    String HCID,strAccountname;
    private boolean isAscending = false;
    private Context context;
    private List<CB_Trading> listcbt, newlist;
    private CB_TradingDAO cbtDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private CBTAdapter adapter;
    private BroadcastReceiver receiver;
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            switch (menuItem.getItemId()) {
                case R.id.cb_order:
                    Intent i =new Intent(CB_TradingList.this,CB_OrderList.class);
                    startActivity(i);
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);

        //ShortcutBadger.with(getApplicationContext()).remove();
        listcbt = new ArrayList<>();
        cbtDAO = new CB_TradingDAO(this);
        //block = new Block();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();;
            }
        });
/*        if(cbtDAO.getCount()>0){
            myToolbar.setTitle(getResources().getString(R.string.title_cbTradingList)+" "+cbtDAO.getCount());
        }else{
            myToolbar.setTitle("");
        }*/
        //
        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no CBTrading created..");
        count = cbtDAO.getCount();
        listcbt = cbtDAO.getAll();
        adapter = new CBTAdapter(this, R.layout.list_item, listcbt);
        listview.setAdapter(adapter);
        if (count > 0) {
            Collections.reverse(listcbt);
            //listtop=new ArrayList<PrevNotification>();
            //tv.setText("(" + count.toString() + ")");
            if (count > 1) {
                fab.setVisibility(View.VISIBLE);
            }
            //setOnClick();
            fab.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }

                    Collections.reverse(listcbt);
                    adapter.notifyDataSetChanged();
                }
            });

        } else {
            //tv.setText("");
            RL_nothing.setVisibility(View.VISIBLE);
        }
        //
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_CB_TradingList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

            }
        };
        registerReceiver(receiver, filter);

        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        /*if (getIntent().getExtras() != null) {
            Bundle bundle = this.getIntent().getExtras();
            feedbackRemittance(new CB_OrderDAO(context).getByHash(bundle.getString("Message")));
            setOnClick();
        }else{
            //Async_checkData checkDataTask=new Async_checkData();
            //checkDataTask.execute();
        }*/
        if (new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)) {
            setOnClick();
        }
        Async_checkData checkDataTask=new Async_checkData();
        checkDataTask.execute();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cb_tradinglist, menu);
        return true;
    }
    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    private void insertCB_OrderDAO(Block block){
        CB_Order cbo=new CB_Order();
        //data=hash+" "+HCID+" 20 "+cashflow1+" "+amount+" RMB "+new Date().getTime()+" "+note;
        cbo.setHash(block.getData().split(" ")[0]);
        cbo.setHcid(block.getData().split(" ")[1]);
        cbo.setStatus(Integer.parseInt(block.getData().split(" ")[2]));
        cbo.setCashflow_1(block.getData().split(" ")[3]);
        cbo.setAmount(Double.parseDouble(block.getData().split(" ")[4]));
        cbo.setCurrency(block.getData().split(" ")[5]);
        cbo.setCreateTime(Long.parseLong(block.getData().split(" ")[6]));
        cbo.setCashflow_2(getResources().getString(R.string.hcid_cashflow_2));
        cbo.setBlockIndex(block.getIndex());
        cbo.setNote(block.getData().split(" ")[7]);
        //new CB_OrderDAO(context).insert(cbo);
    }

    public void setOnClick() {
        listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                CB_Trading cbt = listcbt.get(position);
                adapter.notifyDataSetChanged();
                if (swipeDetector.swipeDetected()) {
                    deleteCell(v, position);
                    cbtDAO.delete(cbt.getId());
                    myToolbar.setTitle(getResources().getString(R.string.title_block)+" "+cbtDAO.getCount());
                }
            }
        });
    }

    private void deleteCell(final View v, final int index) {
        Animation.AnimationListener al = new Animation.AnimationListener() {
            //@Override
            public void onAnimationEnd(Animation arg0) {
                listcbt.remove(index);
                count--;
                if (count < 2) {
                    fab.setVisibility(View.INVISIBLE);
                    if (count < 1) {
                        listview.setVisibility(View.GONE);
                    }
                }
                if (count == 0) {
                    RL_nothing.setVisibility(View.VISIBLE);
                }
                //tv.setText("(" + count + ")");
                ViewHolder vh = (ViewHolder) v.getTag();
                vh.needInflate = true;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        };
        collapse(v, al);
    }

    private void collapse(final View v, Animation.AnimationListener al) {
        final int initialHeight = v.getMeasuredHeight();
        final int top = v.getTop();
        //Toast.makeText(getApplicationContext(), "collapsetop:"+top , Toast.LENGTH_SHORT).show();
        final int ANIMATION_DURATION = 200;
        Animation anim = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {

                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (al != null) {
            anim.setAnimationListener(al);
        }
        anim.setDuration(ANIMATION_DURATION);
        v.startAnimation(anim);
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }



    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class CBTAdapter extends ArrayAdapter<CB_Trading> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public CBTAdapter(Context context, int textViewResourceId, List<CB_Trading> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            CB_Trading cbt  = (CB_Trading) getItem(position);

            if (convertView == null) {
                //Toast.makeText(CB_TradingList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(CB_TradingList.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(CB_TradingList.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();

            //String dt = b.getDatatype();
            //holder.datatype = dt;
            int icon = R.drawable.block;
            String fm = "";
            //Date date = new Date(time);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            fm = formatter.format(cbt.getCreateTime());
            //new SimpleDateFormat(dateFormat).format(new Date(p.getLastModify()));
            String title="Block #"+cbt.getBlockIndex()+" "+Utils.formatDoubleToString(cbt.getCB_Amount())+" "+Utils.formatDoubleToString(cbt.getCR()*100)+"%";
            holder.text_title.setText(title);
            //holder.text_message.setText(b.getId()+" / "+b.getTimestamp()+"\n"+b.getData());
            holder.text_message.setText(
                        cbt.getStatus()+" / "+cbt.getAmount()+" "+cbt.getCurrency()+
                        "\n"+cbt.getHash_seller()+
                        "\n"+cbt.getHash_buyer()
                   );

            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            //}
            return view;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

    private class Async_checkData extends AsyncTask<String, Void, Block> {
        @Override
        protected Block doInBackground(String... params) {
            return checkData();
            //return true;
        }

        @Override
        protected void onPostExecute(Block result) {
            /*if(result.getIndex()>0){
                Dialog_getBlock("Block.toString()",result.toString(),"");
            }*/
            renewlist();
        }

        @Override
        protected void onPreExecute() {
            //RL_nothing.setVisibility(View.VISIBLE);
            //tv_nothing.setText(getResources().getString(R.string.Async_checkdata_Onpre));
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private Block checkData() {
        BlockchainDAO blockchainDAO = new BlockchainDAO(context);
        Block block=new Block();
        cbtDAO.clear();
        for (Block b : blockchainDAO.getAll()) {
            if (b.getDatatype().equals("CB_Trading")) {
                insertCB_TradingDAO(b);
            }
        }
        for (Block b : new BlockDAO(context).getAll()) {
            if (b.getDatatype().equals("CB_Trading")) {
                block=b;
                insertCB_TradingDAO(b);
            }
        }
        return block;
    }

    private void Dialog_getBlock(String title,String message,String submessage){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = CB_TradingList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_blockchainlength, null);
        ImageView iv=(ImageView) view.findViewById(R.id.iv);
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(submessage);
        TextView tv_ok = (TextView) view.findViewById(R.id.tv_ok);
        tv_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        TextView tv_cancel = (TextView) view.findViewById(R.id.tv_cancel);
        tv_cancel.setVisibility(View.INVISIBLE);
        alertDialog.setView(view);
        alertDialog.show();
    }

    private void insertCB_TradingDAO(Block block){
        CB_Trading cbt=new CB_Trading();
        String data=block.getData();
        //data = "HyperConn " + cbo.getHash() + " 50 USD "+strCR+" 31" ;
        cbt.setHash_seller(data.split(" ")[0]);
        cbt.setHash_buyer(data.split(" ")[1]);
        cbt.setCashflow_1(new CB_OrderDAO(context).getByHash(cbt.getHash_buyer()).getCashflow_1());
        cbt.setCashflow_2(new CB_OrderDAO(context).getByHash(cbt.getHash_buyer()).getCashflow_2());
        cbt.setAmount(Double.parseDouble(data.split(" ")[2]));
        cbt.setCurrency(data.split(" ")[3]);
        cbt.setCR(Double.parseDouble(data.split(" ")[4]));
        if(data.startsWith("HyperConn")){
            cbt.setExchnge_fee(0d);
        }else{
            cbt.setExchnge_fee(Utils.multiply(cbt.getAmount(),0.15));
        }
        /*Double cb_amount=cbt.getAmount()/cbt.getCR();
        if(cbt.getCurrency().equals("RMB")){
            cb_amount=cb_amount/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
        }
        String strCB_amount=String.format( "%.2f", cb_amount );*/
        cbt.setStatus(Integer.parseInt(data.split(" ")[5]));
        cbt.setCB_Amount(Double.parseDouble(data.split(" ")[6]));
        cbt.setBlockIndex(block.getIndex());
        cbt.setCreateTime(block.getTimestamp());
        cbt.setHash(cbt.calculateHash(cbt));
        new CB_TradingDAO(context).insert(cbt);
    }

    private void renewlist(){
        listcbt.clear();
        for(CB_Trading cbt:cbtDAO.getAll()){
            listcbt.add(cbt);
        };
        Collections.reverse(listcbt);
        adapter.notifyDataSetChanged();
        if(cbtDAO.getCount()>0){
            listview.setVisibility(View.VISIBLE);
            RL_nothing.setVisibility(View.GONE);
            myToolbar.setTitle(getResources().getString(R.string.title_cbTradingList)+" "+cbtDAO.getCount());
        }else{
            listview.setVisibility(View.GONE);
            RL_nothing.setVisibility(View.VISIBLE);
            myToolbar.setTitle("");
        }
    }

}
