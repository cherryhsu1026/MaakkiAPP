package com.maakki.HyperConnectivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.widget.Toast;

public class NetBroadcastReceiver extends BroadcastReceiver {
    //网络状态监听接口
    public NetStatusMonitor netStatusMonitor;
    //public NetEvevt evevt = BaseActivity.evevt;
    Context context;
    @Override
    public void onReceive(Context context, Intent intent) {
        this.context=context;
        if (intent.getAction().equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
            INVOKE_BlockChain_Broadcasting("Network changed..");
            //Toast.makeText(context,"CONNECTIVITY_ACTION:"+intent.getAction(),Toast.LENGTH_LONG).show();
            //获取网络状态的类型
            boolean netStatus = NetUtil.getNetStatus(context);
            if (netStatusMonitor != null)
                // 接口传递网络状态的类型到注册广播的页面
                netStatusMonitor.onNetChange(netStatus);
        }
    }
    private void INVOKE_BlockChain_Broadcasting(String mess){
        Intent i = new Intent("INVOKE_BlockChain_Broadcasting");
        mess+="\n";
        i.putExtra("What", mess);
        context.sendBroadcast(i);
    }

    /**
     * 网络状态类型改变的监听接口
     */
    public interface NetStatusMonitor {
        void onNetChange(boolean netStatus);
    }

    /**
     * 设置网络状态监听接口
     */
    public void setStatusMonitor(NetStatusMonitor netStatusMonitor) {
        this.netStatusMonitor = netStatusMonitor;
    }

}
