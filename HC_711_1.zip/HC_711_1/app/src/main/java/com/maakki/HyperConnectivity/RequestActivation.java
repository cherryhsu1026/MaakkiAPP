package com.maakki.HyperConnectivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class RequestActivation {
    private long id,blockindex_lastupdate;
    private int weight,status;
    private String hash,note;
    private double amount;
    private String currency,applicant,cashflow_1,cashflow_2;
    private long createtime;

    public RequestActivation() { }

    public void setId(long id){
        this.id=id;
    }
    public long getId() {
        return id;
    }

    public void setApplicant(String applicant) {this.applicant=applicant;}
    public String getApplicant() {return applicant;}

    public void setAmount(double amount) {
        this.amount=amount;
    }
    public double getAmount() {
        return amount;
    }

    public void setCurrency(String currency) {
        this.currency=currency;
    }
    public String getCurrency() {
        return currency;
    }

    public void setCashflow_1(String cashflow_1) {this.cashflow_1=cashflow_1;}
    public String getCashflow_1() {return cashflow_1;}

    public void setCashflow_2(String cashflow_2) {this.cashflow_2=cashflow_2;}
    public String getCashflow_2() {return cashflow_2;}

    public void setBlockIndex_lastupdate( Long blockindex_lastupdate){this.blockindex_lastupdate=blockindex_lastupdate;}
    public Long getBlockIndex_lastupdate(){return blockindex_lastupdate;}

    public void setWeight(int weight) {this.weight=weight;}
    public int getWeight() {return weight;}

    // 0:withdraw by applicant  1:refund to cf1 2:refund to applicant(done)
    // 1?:rejected 2?:checking
    // 10:rejected by cf1 11: refund to applicant
    // 15:rejected by cf2 16: refund to cf1 17:refund to applicant
    // 20:waiting for Remittance replied by Applicant
    // 21:by cf1 22:by cf2
    // 26:waiting for activation
    // 30:succee(done)
    public void setStatus(int status) {this.status=status;}
    public int getStatus() {return status;}

    public String str() {
        return applicant + amount + currency + cashflow_1 ;
    }

    public void setNote(String note){this.note=note;}
    public String getNote(){return note;}

    public void setHash(String hash) {this.hash=hash;}
    public String getHash() {return hash;}

    public void setCreateTime(long createtime) {this.createtime=createtime;}
    public long getCreateTime() {return createtime;}

    public String calculateHash(RequestActivation ra) {
        if (ra != null) {
            MessageDigest digest = null;
            try {
                digest = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException e) {
                return null;
            }
            String txt = ra.str();
            final byte bytes[] = digest.digest(txt.getBytes());
            final StringBuilder builder = new StringBuilder();
            for (final byte b : bytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    builder.append('0');
                }
                builder.append(hex);
            }
            return builder.toString();
        }
        return null;
    }
}
