package com.maakki.HyperConnectivity;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;


public class CoreAlarm extends BroadcastReceiver {
    Context context;
    //NetworkChangeReceiver networkChangeReceiver;
    //网络状态监听接口

    public final int Timer_Check_INTERVAL = 1000 * 60 ; // 1.0mins
    //NetworkChangeReceiver networkChangeReceiver;
    @Override
    public void onReceive(Context context, Intent intent) {
        this.context = context;
        Intent intentservice = new Intent(context, CoreService.class);
        //networkChangeReceiver=new NetworkChangeReceiver();
        if (!isMyServiceRunning(context, CoreService.class)) {
            if (isConnected()) {
                intentservice.putExtra("Message", "startCoreservice");
                context.startService(intentservice);
            }
        } else {
            intentservice.putExtra("Message", "startThread");
            context.startService(intentservice);
        }

    }

    public void setAlarm_imm(Context context) {
        this.context=context;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, CoreAlarm.class);
        //i.putExtra("actType","check_coreservice_running");
        PendingIntent pi = PendingIntent.getBroadcast(context, 0, i, 0);
        //立即啟動，每？秒钟重设一次alarm
        if (am!= null) {
            am.cancel(pi);
            am.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), Timer_Check_INTERVAL, pi); // Millisec * Second * Minute
        }
    }

    public boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if(manager!=null){
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (service.service.getClassName().contains(serviceClass.getName())) {
                    return true;
                }
            }
        }

        return false;
    }
    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = null;
        if(cm!=null){
            networkInfo=cm.getActiveNetworkInfo();
        }
        if(networkInfo != null){
            return networkInfo.isConnected();
        }
        return false;
    }
}
