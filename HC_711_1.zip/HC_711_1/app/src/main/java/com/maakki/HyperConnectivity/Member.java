package com.maakki.HyperConnectivity;

import java.security.PublicKey;

public class Member {
    private String publickey,hcid,introducerid;
    private long id,block_index;

    public Member() {
        hcid="";
        introducerid="";
        publickey="";
    }

    public void setId( Long id){this.id=id;}
    public Long getId(){return id;}

    public void setHcid(String hcid){this.hcid=hcid;}
    public String getHcid(){return hcid;}

    public void setIntroducerid(String introducerid){this.introducerid=introducerid;}
    public String getIntroducerid(){return introducerid;}

    public String getPublicKey(){return publickey;}
    public void setPublicKey(String publickey){
        this.publickey=publickey;
    }

    //where is the record from
    public long getBlockIndex() {
        return block_index;
    }
    public void setBlockIndex(long block_index) {this.block_index = block_index;}
}

