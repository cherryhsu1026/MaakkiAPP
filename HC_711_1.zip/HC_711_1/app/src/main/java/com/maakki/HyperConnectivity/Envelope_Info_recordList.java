

package com.maakki.HyperConnectivity;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by ryan on 2017/7/17.
 */

public class Envelope_Info_recordList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon;
    Integer count;
    View view;
    FloatingActionButton fab;
    private static final int REQUEST_CODE_TAKE_PHOTO = 12;
    private static final int PHOTO_REQUEST_CUT = 15;// 結果

    private Bitmap icon_bitmap = null;
    private String realPath,filename;
    File tmpFile;
    private boolean isAscending = false;
    private Context context;
    private List<Envelope_Info_record> listEnvelope_Info_record;
    private Envelope_Info_recordDAO envelopeInfo_recordDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private BlockAdapter adapter;
    private BroadcastReceiver receiver;
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private String HCID;
    private Menu menu;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            menuItem.setVisible(false);
            //menu.getItem(2).setVisible(false);
            switch (menuItem.getItemId()) {
                case R.id.edit:
                    //Intent i = new Intent(Envelope_InfoRecordList.this, preCBList.class);
                    //startActivity(i);
                    //EditAdDialog();
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        //ShortcutBadger.with(getApplicationContext()).remove();
        listEnvelope_Info_record = new ArrayList<Envelope_Info_record>();
        envelopeInfo_recordDAO=new Envelope_Info_recordDAO(context);
        listEnvelope_Info_record = envelopeInfo_recordDAO.getAll();
        count = listEnvelope_Info_record.size();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        if(count > 0) {
            myToolbar.setTitle(getResources().getString(R.string.EIRList_toolbar)+" "+count);
        } else {
            myToolbar.setTitle("");
        }
        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no Envelope_Info Recorded..");
        //tv = (TextView) findViewById(R.id.tv);


        adapter = new BlockAdapter(this, R.layout.list_item, listEnvelope_Info_record);
        listview.setAdapter(adapter);
        if (count > 0) {
            //Collections.reverse(listEnvelope_Info_record);
            //listtop=new ArrayList<PrevNotification>();
            //tv.setText("(" + count.toString() + ")");
            if (count > 1) {
                fab.setVisibility(View.VISIBLE);
            }
            setOnClick();
            fab.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }

                    Collections.reverse(listEnvelope_Info_record);
                    adapter.notifyDataSetChanged();
                }
            });

        } else {
            //tv.setText("");
            RL_nothing.setVisibility(View.VISIBLE);
        }
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_Envelope_InfoRecordList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renewlist();
            }
        };
        registerReceiver(receiver, filter);

        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //envelopeInfo_recordDAO.deleteAll();
    }
    public void setOnClick() {
        listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Envelope_Info_record envelope_info_record = listEnvelope_Info_record.get(position);
                //adapter.notifyDataSetChanged();
                if (swipeDetector.swipeDetected()) {
                    deleteCell(v, position);
                    envelopeInfo_recordDAO.delete(envelope_info_record.getId());
                    myToolbar.setTitle(getResources().getString(R.string.EIList_toolbar)+" "+envelopeInfo_recordDAO.getCount());
                }else{

                }
            }
        });
    }
    private void deleteCell(final View v, final int index) {
        Animation.AnimationListener al = new Animation.AnimationListener() {
            //@Override
            public void onAnimationEnd(Animation arg0) {
                listEnvelope_Info_record.remove(index);
                count--;
                if (count < 2) {
                    fab.setVisibility(View.INVISIBLE);
                    if (count < 1) {
                        listview.setVisibility(View.GONE);
                    }
                }
                if (count == 0) {
                    RL_nothing.setVisibility(View.VISIBLE);
                }
                //tv.setText("(" + count + ")");
                ViewHolder vh = (ViewHolder) v.getTag();
                vh.needInflate = true;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        };
        collapse(v, al);
    }
    private void collapse(final View v, Animation.AnimationListener al) {
        final int initialHeight = v.getMeasuredHeight();
        final int top = v.getTop();
        //Toast.makeText(getApplicationContext(), "collapsetop:"+top , Toast.LENGTH_SHORT).show();
        final int ANIMATION_DURATION = 200;
        Animation anim = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {

                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (al != null) {
            anim.setAnimationListener(al);
        }
        anim.setDuration(ANIMATION_DURATION);
        v.startAnimation(anim);
    }
    @Override
    protected void onStop() {
        super.onStop();
        //finish();
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_eilist, menu);
        this.menu=menu;
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class BlockAdapter extends ArrayAdapter<Envelope_Info_record> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public BlockAdapter(Context context, int textViewResourceId, List<Envelope_Info_record> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            Envelope_Info_record envelope_info_record = (Envelope_Info_record) getItem(position);

            if (convertView == null) {
                //Toast.makeText(Envelope_InfoRecordList1.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(Envelope_InfoRecordList1.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(Envelope_InfoRecordList1.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();

            int icon = R.drawable.logo;
            String title = envelope_info_record.getAd_hash() + " " + envelope_info_record.getCBPerClick();
            holder.text_title.setText(title);
            String message = envelope_info_record.getId()+" / "+envelope_info_record.getIsConfirmed()+"\n"+envelope_info_record.getRecord_hash()+"\n"+envelope_info_record.getPublisher_id()+"\n"+envelope_info_record.getSubscriber_id();
            holder.text_message.setText(message);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            String fm = formatter.format(envelope_info_record.getCreateTime());
            holder.text_time.setText(fm);
            //holder.image_icon.setImageResource(icon);
            Bitmap bitmap = BitmapFactory.decodeFile(new Envelope_InfoDAO(context).getByHash(envelope_info_record.getAd_hash()).getImage_path());
            holder.image_icon.setImageBitmap(ServiceUtil.getRoundedCornerBitmap(bitmap));
            //}
            return view;
            //return convertView;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

    private String getCurrentDate() {
        Date d = new Date();
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        return dt1.format(d.getTime());
    }

    private void renewlist(){
        listEnvelope_Info_record.clear();
        for(Envelope_Info_record eir:new Envelope_Info_recordDAO(context).getAll()){
            listEnvelope_Info_record.add(eir);
        }
        if (listEnvelope_Info_record.size() > 0) {
            listview.setVisibility(View.VISIBLE);
            RL_nothing.setVisibility(View.GONE);
            myToolbar.setTitle(getResources().getString(R.string.EIList_toolbar) + " "+listEnvelope_Info_record.size());
            adapter.notifyDataSetChanged();
        }else{
            listview.setVisibility(View.GONE);
            RL_nothing.setVisibility(View.VISIBLE);
            myToolbar.setTitle("");
        }
    }
}

