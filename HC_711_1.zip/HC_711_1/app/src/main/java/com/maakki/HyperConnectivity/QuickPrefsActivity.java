package com.maakki.HyperConnectivity;

//Created by ryan on 2016/4/19.

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.preference.RingtonePreference;
import android.preference.SwitchPreference;
import android.provider.Settings;
import android.support.design.widget.AppBarLayout;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.AppCompatCheckedTextView;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class QuickPrefsActivity extends PreferenceActivity {
    ProgressDialog mProgressDialog;
    String fileName,errMsg;
    Context context;
    Preference newApk;
    MyPreference mpref;
    View view;
    Toolbar Tbar;
    LayoutInflater inflater;
    //NetworkChangeReceiver networkChangeReceiver;
    private Preference.OnPreferenceChangeListener sBindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object value) {
            String stringValue = value.toString();
           if (preference instanceof ListPreference) {
                // For list preferences, look up the correct display value in
                // the preference's 'entries' list.
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);
                // Set the summary to reflect the new value.
                preference.setSummary(
                        index >= 0
                                ? listPreference.getEntries()[index]
                                : null);

            } else {
                // For all other preferences, set the summary to the value's
                // simple string representation.
                preference.setSummary(stringValue);
            }
            return true;
        }
    };

    private static void setPreferenceSummary(Preference preference, String value) {
        preference.setSummary(value);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        //setLocale();
        /*mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Download new APK");
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        mProgressDialog.setCancelable(true);*/
        AppBarLayout bar;
        fileName="";
        inflater = QuickPrefsActivity.this.getLayoutInflater();
        //view = inflater.inflate(R.layout.preference_layout, null);
        view = inflater.inflate(R.layout.mypreference_layout, null);

        //networkChangeReceiver=new NetworkChangeReceiver();
        if(isConnected()){
            AsyncCallWS_getAPKInfo getAPKInfoTask=new AsyncCallWS_getAPKInfo();
            getAPKInfoTask.execute();
        }

        //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
            bar = (AppBarLayout) LayoutInflater.from(this).inflate(R.layout.toolbar_settings, root, false);
            root.addView(bar, 0);
        /*} else {
            ViewGroup root = (ViewGroup) findViewById(android.R.id.content);
            ListView content = (ListView) root.getChildAt(0);
            root.removeAllViews();
            bar = (AppBarLayout) LayoutInflater.from(this).inflate(R.layout.toolbar_settings, root, false);

            int height;
            TypedValue tv = new TypedValue();
            if (getTheme().resolveAttribute(R.attr.actionBarSize, tv, true)) {
                height = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
            } else {
                height = bar.getHeight();
            }

            content.setPadding(0, height, 0, 0);
            root.addView(content);
            root.addView(bar);
        }*/

        Tbar = (Toolbar) bar.getChildAt(0);
        Tbar.setTitle(R.string.action_settings);
        Tbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        setupSimplePreferencesScreen();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @SuppressWarnings("deprecation")
    private void setupSimplePreferencesScreen() {
        addPreferencesFromResource(R.xml.preferences);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        Preference setting_pref = (Preference) findPreference("permissions");
        setting_pref.setSummary(R.string.phone_permissions_summary);
        setting_pref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
                return true;
            }
        });
        Preference service_pref = (Preference) findPreference("service_term");
        service_pref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                //Intent i =new Intent(context,ServiceTerm_Activity.class);
                //startActivity(i);
                Intent i=new Intent(context,ServiceTerm_Activity.class);
                startActivity(i);
                finish();
                return true;
            }
        });
        Preference language_pref = (Preference) findPreference("language");
        language_pref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                String language=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key25,"");
                if(language.equals("sc")||language.equals("tc")){
                    language="en";
                }else{
                    if (Locale.getDefault().toString().equals("zh_CN")) {
                        language = "sc";
                    } else if (Locale.getDefault().toString().contains("zh_TW")){
                        language = "tc";
                    } else{
                        language = "sc";
                    }
                }
                String setlanguage=getResources().getString(R.string.set_language_message);
                language_pref.setSummary(setlanguage);
                SharedPreferencesHelper.putSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key25,language);
                //setLocale();
                finish();
                return true;
            }
        });
        //newApk = (Preference) findPreference("newApk");
        //mpref=new MyPreference(this);
        mpref= (MyPreference) findPreference("newApk");
        mpref.onBindView(view);
        //mpref.iv_icon=(ImageView) mpref.view.findViewById(R.id.Iv_icon);
        //ImageView imv=(ImageView) view
        mpref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                Intent i=new Intent(context,HyperConnActivity.class);
                Bundle bundle=new Bundle();
                bundle.putBoolean("isDownload", true);
                i.putExtras(bundle);
                startActivity(i);
                finish();
                return true;
            }
        });
    }

    private void bindPreferenceSummaryToValue(Preference preference) {
        // Set the listener to watch for value changes.
        preference.setOnPreferenceChangeListener(sBindPreferenceSummaryToValueListener);

        // Trigger the listener immediately with the preference's
        // current value.
        sBindPreferenceSummaryToValueListener.onPreferenceChange(preference,
                PreferenceManager
                        .getDefaultSharedPreferences(preference.getContext())
                        .getString(preference.getKey(), ""));
    }

    @Override
    public View onCreateView(String name, Context context, AttributeSet attrs) {
        // Allow super to try and create a view first
        final View result = super.onCreateView(name, context, attrs);
        if (result != null) {
            return result;
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            // If we're running pre-L, we need to 'inject' our tint aware Views in place of the
            // standard framework versions
            switch (name) {
                case "EditText":
                    return new AppCompatEditText(this, attrs);
                case "Spinner":
                    return new AppCompatSpinner(this, attrs);
                case "CheckBox":
                    return new AppCompatCheckBox(this, attrs);
                case "RadioButton":
                    return new AppCompatRadioButton(this, attrs);
                case "CheckedTextView":
                    return new AppCompatCheckedTextView(this, attrs);
            }
        }
        return null;
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private class AsyncCallWS_getAPKInfo extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            getAPKInfo();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
             if(!fileName.isEmpty()){
                 String filename_current=getResources().getString(R.string.app_ver)+".apk";
                 if(!filename_current.equals(fileName)){
                     mpref.needToDownloadImage();
                 }
             }
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private void getAPKInfo() {
        String METHOD_NAME = "getAPKInfo";
        String NAMESPACE = "http://152.101.178.115:8081/";
        String SOAP_ACTION = NAMESPACE + METHOD_NAME;
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        //String timeStamp = String.valueOf(new Date().getTime());
        String URL_WS = NAMESPACE + "webService.asmx";
        //String encryptStr = target_maakki_id.trim() + "MDF-M@@kki.cc" + timeStamp.trim();

        //String identifyStr = getHashCode(encryptStr).toUpperCase();
        //request.addProperty("fileName", filename);
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        //Set output SOAP object
        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        //Create HTTP call object
        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL_WS);

        SoapPrimitive soapPrimitive = null;
        try {
            androidHttpTransport.call(SOAP_ACTION, envelope);
            soapPrimitive = (SoapPrimitive) envelope.getResponse();
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
        }
        String tmp = soapPrimitive.toString();
        //一開始從網路接收通常為String型態,tmp為接收到的String,為避免串流內有其他資料只需抓取{}間的內容
        tmp = tmp.substring(tmp.indexOf("{"), tmp.lastIndexOf("}") + 1);
        JSONObject json_read;
        //將資料丟進JSONObject
        //接下來選擇型態使用get並填入key取值
        try {
            json_read = new JSONObject(tmp);
            fileName = json_read.getString("fileName");
        } catch (Exception e) {
            errMsg = e.getMessage();
        }
    }

    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = null;
        if(cm!=null){
            networkInfo=cm.getActiveNetworkInfo();
        }
        if(networkInfo != null){
            return networkInfo.isConnected();
        }
        return false;
    }

}
