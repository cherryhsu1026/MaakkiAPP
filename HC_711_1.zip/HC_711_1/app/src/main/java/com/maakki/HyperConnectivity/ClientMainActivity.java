package com.maakki.HyperConnectivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public class ClientMainActivity extends Activity {
    Block block;
    TextView textResponse;
    Button buttonConnect, buttonClear, buttonDisconnect;
    ServerSocket serverSocket;
    static final int SocketServerPORT = 8080;
    static final int port = 8080;
    String address,response;
    EditText welcomeMsg;
    Context context;
    List<Block> blockList;
    String handshake;
    Socket socket = null;
    int count=0;
    String DONE_STRING="Synchronization finished!";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientmain);
        address="";
        response="";
        context=this;
        blockList=new ArrayList<>();
        buttonConnect = (Button) findViewById(R.id.connect);
        buttonClear = (Button) findViewById(R.id.clear);
        buttonDisconnect = (Button) findViewById(R.id.disconnect);
        textResponse = (TextView) findViewById(R.id.textResponse);
        welcomeMsg = (EditText)findViewById(R.id.welcomemsg);
        if (getIntent().getExtras() != null) {
            Bundle bundle = this.getIntent().getExtras();
            address=bundle.getString("address");
        }
        buttonClear.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                textResponse.setText("");
            }
        });

        buttonDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(ClientMainActivity.this,BlockchainList.class);
                intent.putExtra("isConnect",false);
                startActivity(intent);
            }
        });
        handshake = "Block_Max_Index in my Blockchain is : " + new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
        HandshakeTask handshakeTask = new HandshakeTask(handshake);
        handshakeTask.execute();
    }

    View.OnClickListener buttonConnectOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View arg0) {
            if(blockList.size()>0){
                for(Block block:blockList){
                    BlockSendTask BlockSendTask = new BlockSendTask();
                    BlockSendTask.execute(block);
                }
                blockList.clear();
                buttonConnect.setBackgroundColor(getResources().getColor(R.color.greyscale3));
                buttonConnect.setEnabled(false);
            }else{
                Toast.makeText(ClientMainActivity.this, "No block is sended", Toast.LENGTH_SHORT).show();
            }
        }
    };

    public class BlockSendTask extends AsyncTask<Block, Void, Void> {
        @Override
        protected Void doInBackground(Block... arg0) {
            Block block=arg0[0];
            Socket socket = null;
            DataOutputStream dataOutputStream = null;
            DataInputStream dataInputStream = null;

            try {
                socket = new Socket(address, port);
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeUTF(block.toString());

                dataInputStream = new DataInputStream(socket.getInputStream());
                response = dataInputStream.readUTF() +response;

            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "UnknownHostException: " + e.toString()+"\n";
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "IOException: " + e.toString()+"\n";
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            //response+="\n"+DONE_STRING;
            textResponse.setText(response);
            super.onPostExecute(result);
        }

    }

    public class BlockReceiveTask extends AsyncTask<Long, Void, Void> {
        Long index;
        Block block;
        @Override
        protected Void doInBackground(Long... arg0) {
            index=arg0[0];
            Socket socket = null;
            DataOutputStream dataOutputStream = null;
            DataInputStream dataInputStream = null;
            String messageFromServer = "";
            String msgAsk="Block_index:"+index;
            try {
                socket = new Socket(address, port);
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeUTF(msgAsk);
                dataInputStream = new DataInputStream(socket.getInputStream());
                messageFromServer = dataInputStream.readUTF();
                if (messageFromServer.startsWith("Block #")) {
                    block = messageToBlock(messageFromServer);
                    count++;
                    response = "#" + count + " from " + socket.getInetAddress()
                            + " : " + socket.getPort() + "\n"
                            + "Block#" + block.getIndex() + " is received..\n" + response;
                }
            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "UnknownHostException: " + e.toString()+"\n";
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "IOException: " + e.toString()+"\n";
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            //response+="\n"+DONE_STRING;
            textResponse.setText(response);
            super.onPostExecute(result);
        }

    }

    public class HandshakeTask extends AsyncTask<Void, Void, Void> {
        String msgToServer;
        HandshakeTask(String  msgTo) {
            msgToServer = msgTo;
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            DataOutputStream dataOutputStream = null;
            DataInputStream dataInputStream = null;
            try {
                socket = new Socket(address, port);
                dataOutputStream = new DataOutputStream(
                        socket.getOutputStream());
                dataInputStream = new DataInputStream(socket.getInputStream());

                if(msgToServer != null){
                    dataOutputStream.writeUTF(msgToServer);
                }
                response = dataInputStream.readUTF();
                //response += handshake_response;

            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response = "UnknownHostException: " + e.toString() +"\n";
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response = "IOException: " + e.toString() +"\n";
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            //if connected with server
            if(response.startsWith("Block_Max_Index")){
                Long target_index=Long.parseLong(response.split(" : ")[1]);
                Long start_index=Long.parseLong(response.split(" : ")[1])+1;
                Long end_index=new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
                if(end_index > target_index){
                    buttonConnect.setOnClickListener(buttonConnectOnClickListener);
                    buttonConnect.setBackgroundColor(getResources().getColor(R.color.colorBlue));
                    blockList=new BlockchainDAO(context).getBlockList(start_index,end_index);
                    if(blockList.size()>1){
                        response+=". blockList from #"+start_index+" to #"+end_index+" ("+blockList.size()+") is ready to send. Go now?\n\n";
                    }else if(blockList.size()>0){
                        response+=". Block #"+end_index+" is ready to send. Go now?\n\n";
                    }
                }else if(end_index == target_index){
                    response+="\nthat is same as mine("+end_index+"), no need to synchronize.\n\n";
                }else if(end_index < target_index){
                    response+="\nthat is bigger than mine("+end_index+"), waiting for incoming Blocks.\n\n";
                    for(long index=end_index;index<target_index;index++ ){
                        //response+=index+"\n";
                        BlockReceiveTask blockReceiveTask=new BlockReceiveTask();
                        blockReceiveTask.execute(index);
                    }
                }
            }
            textResponse.setText(response);
            //Thread socketThread = new Thread(new SocketThread());
            //socketThread.start();
            super.onPostExecute(result);
        }

    }

    private class SocketThread extends Thread {
        Socket socket = null;
        int count = 0;
        Long target_index;
        Long start_index;
        Long end_index;
        //String msgReply = "";
        Boolean isServerBigger=false;
        @Override
        public void run() {
            Socket socket = null;
            DataInputStream dataInputStream = null;
            DataOutputStream dataOutputStream = null;
            try {
                serverSocket = new ServerSocket(SocketServerPORT);
                while (true) {
                    socket = serverSocket.accept();
                    dataInputStream = new DataInputStream(
                            socket.getInputStream());
                    dataOutputStream = new DataOutputStream(
                            socket.getOutputStream());

                    String messageFromClient = "";
                    String msgReply = "";

                    //If no message sent from client, this code will block the program
                    messageFromClient = dataInputStream.readUTF();
                    if (messageFromClient.startsWith("Block #")) {
                        block = messageToBlock(messageFromClient);
                        count++;
                        response += "#" + count + " from " + socket.getInetAddress()
                                + " : " + socket.getPort() + "\n"
                                + block.toShow() + "\n\n";

                        msgReply = "Block#" + block.getIndex() + " is sended..\n";
                    }
                    else if (messageFromClient.startsWith("Block_Max_Index")) {
                        msgReply = "Block_Max_Index in Blockchain of target is : " + new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
                        response = "Block_Max_Index in Blockchain of target is : " + Long.parseLong(messageFromClient.split(" : ")[1]);
                        target_index = Long.parseLong(messageFromClient.split(" : ")[1]);
                        start_index = target_index + 1;
                        end_index=new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
                        if(end_index > target_index){
                            isServerBigger=true;
                            blockList=new BlockchainDAO(context).getBlockList(start_index,end_index);
                            if(blockList.size()>1){
                                response+=". blockList from #"+start_index+" to #"+end_index+" ("+blockList.size()+") is ready to send. Go now?\n";
                            }else if(blockList.size()>0){
                                response+=". Block #"+end_index+" is ready to send. Go now?\n";
                            }
                        }else if(end_index == target_index){
                            response+="\nthat is same as mine("+end_index+"), no need to synchronize.\n";
                        }else if(end_index < target_index){
                            response+="\nthat is bigger than mine("+end_index+"), waiting for incoming blocks.\n";
                        }
                        //response=end_index+" / "+target_index +" / "+start_index +" / "+blockList.size();
                    }

                    dataOutputStream.writeUTF(msgReply);
                    ClientMainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(isServerBigger){
                                buttonConnect.setOnClickListener(buttonConnectOnClickListener);
                                buttonConnect.setBackgroundColor(getResources().getColor(R.color.colorBlue));
                            }
                            textResponse.setText(response);
                        }
                    });

                }

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                final String errMsg = e.toString();
                ClientMainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textResponse.setText(errMsg);
                    }
                });

            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }

    }


    /*private class SocketClientThread extends Thread {
        Socket socket = null;
        int count = 0;
        @Override
        public void run() {
            Socket socket = null;
            DataInputStream dataInputStream = null;
            DataOutputStream dataOutputStream = null;
            try {
                while (true) {
                    socket = new Socket(address, Integer.parseInt(port));
                    dataInputStream = new DataInputStream(
                            socket.getInputStream());
                    dataOutputStream = new DataOutputStream(
                            socket.getOutputStream());

                    String messageFromServer = "";
                    String msgReply = "";

                    //If no message sent from client, this code will block the program
                    messageFromServer = dataInputStream.readUTF();
                    if (messageFromServer.startsWith("Block #")) {
                        block = messageToBlock(messageFromServer);
                        count++;
                        response += "#" + count + " from " + socket.getInetAddress()
                                + " : " + socket.getPort() + "\n"
                                + block.toShow() + "\n\n";

                        msgReply = "Block#" + block.getIndex() + " is sended..\n";
                    }
                    dataOutputStream.writeUTF(msgReply);
                    ClientMainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textResponse.setText(response);
                        }
                    });

                }

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                final String errMsg = e.toString();
                ClientMainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textResponse.setText(errMsg);
                    }
                });

            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }

    }*/

    private Block messageToBlock(String message){
        block=new Block();
        String[] eachlineStr = message.split("\n");
        int index = Integer.parseInt(eachlineStr[0].split("#")[1].split(" ")[0]);
        String datatype = eachlineStr[0].split(" ")[2];
        int nonce = Integer.parseInt(eachlineStr[0].split(" ")[3]);
        long timestamp = Long.parseLong(eachlineStr[1].split(":")[1]);
        String maker = eachlineStr[2].split(":")[1];
        String Hash = eachlineStr[3].split(":")[1];
        //if(!new BlockDAO(context).isExisted(Hash)){}
        String previousHash = eachlineStr[4].split(":")[1];
        //String data = eachlineStr[5].split(":")[1];
        String data =  message.split("\ndata:")[1];
        block.setIndex(index);
        block.setMaker(maker);
        block.setTimestamp(timestamp);
        block.setData(data);
        block.setDatatype(datatype);
        block.setNonce(nonce);
        block.setHash(Hash);
        block.setPreviousHash(previousHash);
        addToBlockDAO(block);
        return block;
    }

    private void addToBlockDAO(Block b) {
        //BlockDAO bD = new BlockDAO(context);
        //Create a child thread
        /*Thread childThread = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    //ignore
                }*/

        if (!new BlockDAO(context).isExisted(b.getHash())) {
            new BlockDAO(context).insert(b);
        }
            /*}
        };
        // Start the thread.
        childThread.start();*/
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}
