package com.maakki.HyperConnectivity;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


// 資料功能類別
public class BlockDAO {
    // 表格名稱
    Context context;
    public static final String TABLE_NAME = "Block";
    // 編號表格欄位名稱，固定不變
    public static final String KEY_Id = "_id";
    public static final String maker_Column = "maker";
    public static final String KEY_INDEX = "_index";
    public static final String timestamp_Column = "timestamp";
    public static final String nonce_Column = "nonce";
    public static final String previousHash_Column = "previousHash";
    public static final String hash_Column = "hash";
    public static final String datatype_Column = "datatype";
    public static final String data_COLUMN = "data";
    public static final String CreateTime_COLUMN = "CreateTime";

    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_Id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    maker_Column + " TEXT NOT NULL, " +
                    KEY_INDEX + " REAL NOT NULL, " +
                    timestamp_Column + " REAL NOT NULL, " +
                    nonce_Column + " INTEGER NOT NULL, " +
                    previousHash_Column + " TEXT, " +
                    hash_Column + " TEXT NOT NULL, " +
                    datatype_Column + " TEXT NOT NULL, " +
                    data_COLUMN + " TEXT NOT NULL, " +
                    CreateTime_COLUMN + " REAL NOT NULL)";
    // 資料庫物件
    private SQLiteDatabase db;
    // 建構子，一般的應用都不需要修改
    public BlockDAO(Context context) {
        this.context=context;
        db = BlockchainDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public Block insert(Block block) {
        // 建立準備新增資料的ContentValues物件
        ContentValues cv = new ContentValues();
        long createtime=new Date().getTime();
        // 加入ContentValues物件包裝的新增資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(maker_Column, block.getMaker());
        cv.put(KEY_INDEX, block.getIndex());
        cv.put(timestamp_Column, block.getTimestamp());
        cv.put(nonce_Column, block.getNonce());
        if(block.getIndex()>0){
            cv.put(previousHash_Column, block.getPreviousHash());
        }
        cv.put(hash_Column, block.getHash());
        cv.put(datatype_Column, block.getDatatype());
        cv.put(data_COLUMN, block.getData());
        cv.put(CreateTime_COLUMN, createtime);
        // 新增一筆資料並取得編號
        // 第一個參數是表格名稱
        // 第二個參數是沒有指定欄位值的預設值
        // 第三個參數是包裝新增資料的ContentValues物件
        long id = db.insert(TABLE_NAME, null, cv);

        // 設定編號
        block.setId(id);
        block.setCreateTime(createtime);
        // 回傳結果
        return block;
    }

    // 修改參數指定的物件
    public boolean update(Block block) {
        // 建立準備修改資料的ContentValues物件
        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(maker_Column, block.getMaker());
        cv.put(KEY_INDEX, block.getIndex());
        cv.put(timestamp_Column, block.getTimestamp());
        cv.put(nonce_Column, block.getNonce());
        if(block.getIndex()>0){
            cv.put(previousHash_Column, block.getPreviousHash());
        }
        cv.put(hash_Column, block.getHash());
        cv.put(datatype_Column, block.getDatatype());
        cv.put(data_COLUMN, block.getData());
        cv.put(CreateTime_COLUMN, block.getCreateTime());


        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = KEY_Id + "=" + block.getId();

        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_Id + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    // 刪除指定Hash的資料
    public boolean deleteByHash(String hash) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = hash_Column + "='" + hash +"'";
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    public Long getLastTimeOfHCtoPCB(String hcid){
        Long result=0l;
        List<Block> resultlist=new ArrayList<>();
        //List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = datatype_Column+"='getHC'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, KEY_Id+" DESC", null);

        while (cursor.moveToNext()) {
            resultlist.add(getRecord(cursor));
        }
        for(Block block:resultlist){
            if(block.getData().split(" ")[0].equals(hcid)&
               block.getData().split(" ")[1].startsWith("-")){
                result=block.getTimestamp();
                break;
            }
        }
        cursor.close();
        return result;
    }

    // 刪除參數指定編號的資料
    public boolean deletebyIndex(long index) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_INDEX + "=" + index;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }
    public void clear() {
        for(Block block:getAll()){
            delete(block.getId());
        }
    }
    // 讀取所有記事資料
    public List<Block> getAll() {
        List<Block> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    // 讀取某个Index的所有区块
    public List<Block> getBlockListByIndex(long index) {
        List<Block> result = new ArrayList<>();
        String SELECTSTRING = KEY_INDEX + "=" + index;
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, KEY_Id+" DESC", null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }
        cursor.close();
        return result;
    }
    // 讀取所有記事資料
    public Block getByIndex(long index) {
        Block result = new Block();
        String SELECTSTRING = KEY_INDEX + "=" + index;

        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }
        cursor.close();
        return result;
    }
    public Block isRegistering(String hcid){
        List<Block> listBlock = new ArrayList<>();
        Block block=null;
        String SELECTSTRING = datatype_Column + "='Registration'";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        while (cursor.moveToNext()) {
            listBlock.add(getRecord(cursor));
        }
        cursor.close();
        for (Block b : listBlock) {
            if (b.getData().split(" ")[1].equals(hcid)) {
                block = b;
                break;
            }
        }
        return block;
    }

    public Boolean isExisted(String hash){
        Boolean result=false;
        String SELECTSTRING = hash_Column + "='"+hash+"'";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result = true;
        }
        cursor.close();
        return result;
    }

    public Block getPreviousblock(Block nb){
        Block result=null;
        List<Block> listblock=new ArrayList<>();
        String SELECTSTRING = hash_Column + "='" + nb.getPreviousHash()+"'";

        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, KEY_INDEX+" DESC", null);
        while(cursor.moveToNext()){
            listblock.add(getRecord(cursor));
        }
        cursor.close();
        // 如果有查詢結果
        for(Block block:listblock){
            //讀取包裝一筆資料的物件
            if(new Blockchain(4,context).isValidNewBlock(nb,block)){
                result = block;
            }else{
                delete(block.getId());
            }
        }
        return result;
    }
    public String getMakerofLastestBlock(){
        String result="";
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, KEY_INDEX+" DESC", null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            result = getRecord(cursor).getMaker();
        }
        cursor.close();
        return result;
    }

    public Block getBlock_MaxIndex(){
        Block result=new Block();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, KEY_INDEX+" DESC", null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }
        cursor.close();
        return result;
    }
    // 取得指定編號的資料物件
    public Block get(long id) {
        // 準備回傳結果用的物件
        Block block = null;
        // 使用編號為查詢條件
        String SELECTSTRING = KEY_Id + "=" + id;
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            block = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return block;
    }

    // 把Cursor目前的資料包裝為物件
    public Block getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        Block result = new Block();
        result.setId(cursor.getInt(0));
        result.setMaker(cursor.getString(1));
        result.setIndex(cursor.getLong(2));
        result.setTimestamp(cursor.getLong(3));
        result.setNonce(cursor.getInt(4));
        //if(cursor.getLong(2)>0){
            //result.setPreviousHash(cursor.getString(5));
        //}else{
            result.setPreviousHash(cursor.getString(5));
        //}
        result.setHash(cursor.getString(6));
        result.setDatatype(cursor.getString(7));
        result.setData(cursor.getString(8));
        result.setCreateTime(cursor.getLong(9));

        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }

}