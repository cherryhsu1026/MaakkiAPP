package com.maakki.HyperConnectivity;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

/*import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;*/

import org.json.JSONArray;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

import microsoft.aspnet.signalr.client.SignalRFuture;
import microsoft.aspnet.signalr.client.hubs.HubConnection;
import microsoft.aspnet.signalr.client.hubs.HubProxy;
import microsoft.aspnet.signalr.client.hubs.SubscriptionHandler2;
import microsoft.aspnet.signalr.client.hubs.SubscriptionHandler4;
import microsoft.aspnet.signalr.client.transport.ServerSentEventsTransport;

/**
 * Created by ryan on 2016/2/26.
 * onCreate -> onStartCommand -> onDestroy() 如果是Activity call的，則必須呼叫stopService 才會停止
 */
public class CoreService extends Service {
    //region 各變數設定
    private final int IntervalTime_getPCBfromHC = 24*60*60*1000;
    private int BlockThread_IntervalTime =5000 ;// 5.0 secs
    private int SCORE_COUNT_BLOCKS=0;
    private int interval_count=24;
    private int SCORE_NEED_TO_GETCB = 100 * 60 * 1000; // 100 mins
    private int IntervalTime_CHECKDATA = 30 * 60 * 1000; // 0.5 hour
    private int Block_SurvivalTime = 20 * 60 * 1000;//20 mins
    private final int intervalMessageTime = 3000;
    /*private final String HUB_URL = "http://www.maakki.com/";
    private final String HUB_NAME = "maakkiHub";
    private final String HUB_URL1 = "http://152.101.178.115:8081/";
    private final String HUB_NAME1= "blockHub";*/
    private final String HUB_EVENT_receiveMessage = "receiveMessage";
    private final String HUB_EVENT_chatpublic = "chat_public";
    private final String HUB_Hidden_Signal_Send = "Hidden_Signal_Send";
    private final String HUB_chat_public_Send = "chat_public";
    private Double CR;
    private Envelope_Info envelope_info,ei_click;
    private Envelope_Info_record eir_click;
    private boolean
            Bypass=true,
            isCheckBlockchainFinished=true,
            isFinished_checkData=true,
            isSyncBlockchainFinished=true,
            isRegistered=false,
            hasConflict=false,
            isConnect=false,
            Allow_Inquiry_Ad=true;
    private SignalRFuture<Void> mSignalRFuture,mSignalRFuture1;
    private HubProxy mHub,mHub1;
    private long Lasttime_milliseconds=0l, index_end, Lasttime_runDaemonThread=0l;
    //private String mMaakkiID = "";
    //private String connMaakkiID = "";
    private String mMemID = "";
    private String mName = "";
    private String mPicfile = "";
    //private String app_name = "";

    private Context context;
    Blockchain blockchain;
    BlockchainDAO blockchainDAO;
    Block block,AskMaker_StartBlock;
    BlockDAO blockDAO;
    List<String> list_Reponse_Maker;
    List<Block> list_divergence,list_skip_divergence;
    String currency,HCID,
            content_pcb="-- : --",
            CONTENT_TITLE;
    Double secs_to_sync=0d;
    Long BlockThread_StartTime,BlockchainThread_StartTime,BlockThread_CallTime,BlockchainThread_CallTime;

    BlockThread blockThread=null;
    List<BlockMessage> listBlockmessage;
    long index_conflict=0;
    Block block_conflict;
    //preConnectivityBenifit pcb;
    preConnectivityBenifitDAO pcbDAO;
    ConnectivityBenifitDAO cbDAO;
    MemberDAO memberDAO;
    private WindowManager.LayoutParams wmParams;
    private WindowManager mWindowManager;
    private View mWindowView1,mWindowView2,mWindowView3;
    ImageView iv_icon,iv_envelope2,iv_envelope3,iv_ad;
    private String CBAmt;
    private Double pcb_amount=0d;
    private SharedPreferences sharedPrefs;
    //private Boolean isSound,isVibrate;
    Animation myAnim;
    NetworkChangeReceiver networkChangeReceiver;
    TextView tv_CB2,tv_pcb2,tv_cb2,tv_CB3,tv_pcb3,tv_cb3,tv_subject,tv_content;
    RelativeLayout rl_envelope_info;
    //private AdView mAdView;
    //endregion
    //region 設定語系
    public void setLocale() {
        Locale locale;
        //Toast.makeText(context,"Locale.getDefault():"+Locale.getDefault().toString(),Toast.LENGTH_LONG).show();
        String languageToLoad = "";
        if (SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key25, "").isEmpty()) {
            if (Locale.getDefault().toString().contains("zh_CN")||Locale.getDefault().toString().contains("sc")) {
                languageToLoad = "sc";
            } else if (Locale.getDefault().toString().contains("zh_TW")) {
                languageToLoad = "tc";
            } else {
                languageToLoad = "en";
            }
            SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key25, languageToLoad);
        } else {
            languageToLoad = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key25, "");
        }

        locale = new Locale(languageToLoad);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
//endregion

    //region 設置網路狀態接收器（接收網路各種狀態訊號--wifi)
    private void registerNetworkChangeBroadReceiver() {
        // Create an IntentFilter instance.
        IntentFilter intentFilter = new IntentFilter();

        // Add network connectivity change action.
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        intentFilter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.SUPPLICANT_CONNECTION_CHANGE_ACTION);
        intentFilter.addAction(WifiManager.SUPPLICANT_STATE_CHANGED_ACTION);

        // Set broadcast receiver priority.
        intentFilter.setPriority(100);
        // Create a network change broadcast receiver.
        networkChangeReceiver = new NetworkChangeReceiver();

        // Register the broadcast receiver with the intent filter object.
        registerReceiver(networkChangeReceiver, intentFilter);
    }
    //endregion

    @Override
    public void onCreate() {
        context = this;
        setLocale();
        sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        HCID   =SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key100,"");
        pcbDAO=new preConnectivityBenifitDAO(context);
        cbDAO=new ConnectivityBenifitDAO(context);
        CR=new CB_TradingDAO(context).getCR();
        AskMaker_StartBlock=new Block();
        blockchain = new Blockchain(4,context);
        blockchainDAO=new BlockchainDAO(context);
        blockDAO=new BlockDAO(context);
        check_blockchain_debute();  //檢查BlockChain 是否正確
        listBlockmessage = new ArrayList<>();
        list_Reponse_Maker=new ArrayList<>();
        list_divergence=new ArrayList<>();
        list_skip_divergence=new ArrayList<>();
        //載入動畫
        myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        // Use bounce interpolator with amplitude 0.2 and frequency 20
        MyBounceInterpolator interpolator = new MyBounceInterpolator(0.2, 20);
        myAnim.setInterpolator(interpolator);
        initWindowParams(); //設定懸浮視窗的各參數（出現的位置大小)
        initView();         //建立動態產生layout (懸浮layout)
        initClick();        //動態layout上所產生的元件之click事件設置

        BlockThread_StartTime =new Date().getTime();
        BlockchainThread_StartTime=new Date().getTime();
        mMemID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        memberDAO=new MemberDAO(context);
        if(!HCID.isEmpty()){
            if(memberDAO.isRegistered(HCID)){isRegistered=true;}
        }
        registerNetworkChangeBroadReceiver(); //設置網路狀態接收器
        //SDK
        /*MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });*/
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //super.onStartCommand(intent, flags, startId);
        //return START_STICKY;
        String data = intent.getStringExtra("Message");
        if (data.equals("startCoreservice")) {
            INVOKE_ALL("INVOKE_BlockChain_Broadcasting", context.getResources().getString(R.string.content_message_service_running)+"\n");
            setHubConnect();    //設置 SignalR
            isConnect=true;
            CoreAlarm ca = new CoreAlarm();
            ca.setAlarm_imm(context);
            Log.e("cherry", "startCoreservice");
        } else if (data.equals("startThread")) {
            startThread();
        } else if (data.equals("SyncBlockchain_Start")) {
            Async_getBlock getBlockTask = new Async_getBlock();
            getBlockTask.execute();
        } else if (data.equals("resetBlockchain")) {
            blockchain = new Blockchain(4);
        } else if (data.equals("check_applyBlock")) {
            //for Registration
            check_applyBlock();
        } else if (data.equals("connected")) {
            if(!isConnect){
                setHubConnect();
                //INVOKE_BlockChain_Broadcasting("isConnect=true;");
            }
            isConnect=true;
        } else if (data.equals("disconnected")) {
            if(isConnect){
                clearHub();
                //INVOKE_BlockChain_Broadcasting("isConnect=false;");
            }
            isConnect=false;
        } else if(data.startsWith("makeBlock_Calibration:")){
            makeBlock_Calibration(data.split(":")[1]+":"+data.split(":")[2]);
        } else if(!data.isEmpty()){
            addListBlockThread_Request(data);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    private void startThread() {
        isConnect();
        Bypass=new Date().getTime() > BlockThread_StartTime;
        callContent_Title(content_pcb);
        if (Bypass & isCheckBlockchainFinished & isFinished_checkData & isSyncBlockchainFinished) {
            Async_applyBlock check_getCB_applyBlockTask=new Async_applyBlock();
            check_getCB_applyBlockTask.execute();
        }
    }
    private void callContent_Title(String content_pcb){
        CONTENT_TITLE=Utils.getCurrentTime()+" / ";
        if(!Bypass){
            CONTENT_TITLE+=context.getResources().getString(R.string.procedure_packing)+" / ";
        }
        if(!isCheckBlockchainFinished){
            CONTENT_TITLE+=context.getResources().getString(R.string.procedure_validation)+" / ";
        }
        if(!isFinished_checkData){
            CONTENT_TITLE+=context.getResources().getString(R.string.procedure_synchronization)+" / ";
        }else{
            CONTENT_TITLE+=Utils.formatDoubleToString(secs_to_sync)+" secs / ";
        }
        if(!isSyncBlockchainFinished){
            CONTENT_TITLE+=context.getResources().getString(R.string.procedure_download)+" / ";
        }
        CONTENT_TITLE+=content_pcb;
        INVOKE_CONTENT_TITLE(CONTENT_TITLE);
    }
    private void unpackBlock(Block block) {
        if (block.getDatatype().equals("CB_Trading")) {
            block.insertCB_TradingDAO(context,block);
        } else if (block.getDatatype().equals("CB_Order")) {
            block.insertCB_OrderDAO(context,block);
        } else if (block.getDatatype().equals("getHC")) {
            //block.insertHCDAO(context,block);
        } else if (block.getDatatype().equals("Activation")) {
            insertRADAO(block);
        } else if (block.getDatatype().equals("Registration")) {
            //unpack_Registration(block);
        } else if (block.getDatatype().equals("RG_1")) {
            /*Member member = new Member();
            member.setIntroducerid(block.getData().split(" ")[0]);
            member.setBlockIndex(block.getIndex());
            member.setHcid(block.getData().split(" ")[1]);
            member.setPublicKey(block.getData().split(" ")[2]);
            new MemberDAO(context).insert(member);*/
        } else if (block.getDatatype().equals("getPCB")) {
            preConnectivityBenifit pcb = new preConnectivityBenifit();
            pcb.setHcid(block.getData().split(" ")[0]);
            pcb.setAmount(Double.parseDouble(block.getData().split(" ")[1]));
            pcb.setNote(block.getData().split(" ")[2]);
            pcb.setBlockIndex(block.getIndex());
            pcb.setCreateTime(block.getTimestamp());
            new preConnectivityBenifitDAO(context).insert(pcb);
            Intent i = new Intent("INVOKE_preCBList");
            sendBroadcast(i);
            //
        } else if (block.getDatatype().equals("getCB")) {
            //insert_CBDAO(block);
        }
    }

    private  void insertRADAO(Block block){
        RequestActivation ra=new RequestActivation();
        //data=hash+" "+HCID+" 20 "+cashflow1+" "+amount+" RMB "+new Date().getTime();
        ra.setHash(block.getData().split(" ")[0]);
        ra.setApplicant(block.getData().split(" ")[1]);
        ra.setStatus(Integer.parseInt(block.getData().split(" ")[2]));
        ra.setCashflow_1(block.getData().split(" ")[3]);
        ra.setAmount(Double.parseDouble(block.getData().split(" ")[4]));
        ra.setCurrency(block.getData().split(" ")[5]);
        ra.setCreateTime(Long.parseLong(block.getData().split(" ")[6]));
        ra.setCashflow_2(getResources().getString(R.string.hcid_cashflow_2));
        ra.setBlockIndex_lastupdate(block.getIndex());
        ra.setWeight(new MemberDAO(context).getWeight(block.getData().split(" ")[1]));
        ra.setNote(block.getData().split(" ")[7]);
        new RequestActivationDAO(context).insert(ra);
    }

    private void insert_CBDAO(Block block){
        if(block.getData().split(" ")[3].equals("activity")) {
            preConnectivityBenifit pcb = new preConnectivityBenifit();
            pcb.setHcid(block.getData().split(" ")[1]);
            pcb.setAmount(-Double.parseDouble(block.getData().split(" ")[2]));
            pcb.setNote(block.getData().split(" ")[3]);
            pcb.setBlockIndex(block.getIndex());
            pcb.setCreateTime(new Date().getTime());
            new preConnectivityBenifitDAO(context).insert(pcb);
            Intent i1 = new Intent("INVOKE_preCBList");
            sendBroadcast(i1);
        }
        ConnectivityBenifit cb = new ConnectivityBenifit();
        cb.setSender(block.getData().split(" ")[0]);
        cb.setReceiver(block.getData().split(" ")[1]);
        //INVOKE_BlockChain_Broadcasting("cb.setAmount: "+block.getData().split(" ")[2]);
        cb.setAmount(Double.parseDouble(block.getData().split(" ")[2].replaceAll(",","")));
        cb.setNote(block.getData().split(" ")[3]);
        cb.setBlockIndex(block.getIndex());
        cb.setCreateTime(block.getTimestamp());
        new ConnectivityBenifitDAO(context).insert(cb);
        Intent i2 = new Intent("INVOKE_CBList");
        sendBroadcast(i2);
    }

    private void clearHub(){
        if (mSignalRFuture != null) {
            mSignalRFuture.cancel();
        }
        if (mSignalRFuture1 != null) {
            mSignalRFuture1.cancel();
        }
    }
    private void setHubConnect() {
        clearHub();
        // 接收信息
        HubConnection connection = new HubConnection("http://www.maakki.com/");
        mHub = connection.createHubProxy("maakkiHub");
        mSignalRFuture = connection.start(new ServerSentEventsTransport(connection.getLogger()));
        //開啟連線
        try {
            mSignalRFuture.get();
        } catch (Exception e) {
            //
        }
        HubConnection connection1 = new HubConnection(staticVar.Server_url);
        mHub1 = connection1.createHubProxy("blockHub");
        mSignalRFuture1 = connection1.start(new ServerSentEventsTransport(connection1.getLogger()));
        //開啟連線
        try {
            mSignalRFuture1.get();
        } catch (Exception e) {
        }
        setHubConnect_mHub();   //連線Connected(註冊channel) 及 設置Client receive method
    }

    //region 連線Connected(註冊channel) 及 設置Client receive method
    private void setHubConnect_mHub(){
        String HUB_Method_Connection = "userConnected";
        //if(isConnect) {
            try {
                mHub.invoke(HUB_Method_Connection, HCID).get();
            } catch (Exception e) {
            }
        try {
            mHub1.invoke(HUB_Method_Connection, HCID).get();
            //Log.e("cherry", "HCID:" + HCID);
            //Log.e("cherry","mHub1 connected and add to Group success");
        } catch (Exception e) {
            //Log.e("cherry","mHub1 connected error:"+e.toString());
        }
        String HUB_EVENT_Receive = "chatReceive";
        mHub1.on(HUB_EVENT_receiveMessage, new SubscriptionHandler2<String, String>() {
            //@Override
            public void run(String message, String msgType) {
                Lasttime_milliseconds=new Date().getTime();
                //setConnect(true);
                //INVOKE_BlockChain_Broadcasting("mt:"+msgType+"\nmsg:"+message);
                if (msgType.equals("releaseAPK")) {
                    //INVOKE_BlockChain_Broadcasting("Please download the latest ver. of APK.\n"+"HyperConn.apk");
                    Invoke_NewAPKArrived(message);
                }
            }
        }, String.class, String.class);

        mHub.on(HUB_EVENT_chatpublic, new SubscriptionHandler4<String, String, String, String>() {
            //@Override
            public void run(String memberid, String name, String picFile, String message) {
                Lasttime_milliseconds=new Date().getTime();
                //setConnect(true);
                if (!memberid.equals(HCID)) {
                    if(name.equals("renewAD_Status")){
                        INVOKE_ALL("INVOKE_BlockChain_Broadcasting","renewAD_Status_Requested: "+picFile+"\n");
                        if(new Envelope_InfoDAO(context).getByHash(picFile).getPublisher_id().equals(memberid)){
                            Envelope_Info ei=new Envelope_InfoDAO(context).getByHash(picFile);
                            ei.setStatus(22);
                            new Envelope_InfoDAO(context).update(ei);
                            INVOKE_ALL("INVOKE_Envelope_InfoRecordList", "");
                        }
                    }
                    else if(name.equals("Apply_Maker_Request_Block")){
                        if(picFile.split(":")[1].split(" ")[0].toUpperCase().equals(HCID.substring(0,6))){
                            INVOKE_ALL("INVOKE_BlockChain_Broadcasting",memberid+" ask to register via my introduction.");
                            String submessage=picFile.split(":")[0]+":"+HCID+" "+picFile.split(" ")[1]+" "+picFile.split(" ")[2];
                            String sender=memberid;
                            //if not registered, make a block of registration
                            if(!new MemberDAO(context).isRegistered(picFile.split(" ")[1])){
                                new BlockThread(submessage,false,callback).start();
                                //INVOKE_BlockChain_Broadcasting("blockmessage: "+submessage);
                            }
                            if(isConnect) {
                                ArrayList<String> L = new ArrayList<String>();
                                L.add(sender);
                                String mType = "Reply_Applicant_Request_Block";
                                sender = HCID;
                                String hash = message.split(" ")[1];
                                //INVOKE_BlockChain_Broadcasting("Reply_Applicant:"+sender+" / "+L.toString()+" / "+message);
                                try {
                                    mHub.invoke(HUB_Hidden_Signal_Send, L, sender, mType, hash, "").get();
                                } catch (Exception e) {}
                            }
                        }
                    }
                    //I heard someone is Inquiring about Ad
                    else if (name.startsWith("Inquiry_Ad_")) {
                        int i=Integer.parseInt(name.split("_")[2]);
                        ArrayList<String> adslist=new ArrayList<String>();
                        if(!picFile.isEmpty()){
                            String string= picFile.substring(picFile.indexOf("[")+1, picFile.lastIndexOf("]"));
                            adslist=new ArrayList<String>(Arrays.asList(string.split(",")));
                        }
                        //INVOKE_BlockChain_Broadcasting("Got the Inquiry_"+i+" of Ad. from: "+memberid+" / "+adslist.size()+" / "+new Envelope_InfoDAO(context).getMyAd(HCID).size());
                        for (Envelope_Info envelope_info : new Envelope_InfoDAO(context).getMyAd(HCID)) {
                            //calculate if cb_amount balance > cbperclick
                            boolean needToSend = true;
                            if (adslist.size() > 0) {
                                for (String s : adslist) {
                                    //String comp = s.split(":")[0].trim().equals(HCID) + " : " + s.split(":")[1].trim().equals(envelope_info.getHash());
                                    //INVOKE_BlockChain_Broadcasting("Comp_Result:\n"+comp);
                                    if (s.split(":")[0].trim().equals(HCID) & s.split(":")[1].trim().equals(envelope_info.getHash())) {
                                        needToSend = false;
                                        break;
                                    }
                                }
                            }
                                //INVOKE_BlockChain_Broadcasting("needToSend:\n"+needToSend);
                                if (needToSend) {
                                    if (i == 1) {
                                        sendMyAd(false, envelope_info, memberid);
                                        //INVOKE_BlockChain_Broadcasting("sendMyAd:\n"+memberid+"\n"+envelope_info.getHash());
                                        //send just one new Ad each time
                                        break;
                                    }
                                } else {
                                    if (i == 1) {
                                        sendMyAd(true, envelope_info, memberid);
                                    } else if (i == 2) {
                                        boolean isSmallerOrEqual=envelope_info.getCB_Amount()-new Envelope_Info_recordDAO(context).getCB_AmountByAdHash(envelope_info.getHash()) <= envelope_info.getCBPerClick();
                                            String mess="calculate cb_amount: "+envelope_info.getCB_Amount()+" / "
                                                    +new Envelope_Info_recordDAO(context).getCB_AmountByAdHash(envelope_info.getHash())+" / "
                                                    +envelope_info.getCBPerClick()+" / "+isSmallerOrEqual;
                                            //INVOKE_BlockChain_Broadcasting(mess);
                                            if(isSmallerOrEqual){
                                                envelope_info.setStatus(22);
                                                new Envelope_InfoDAO(context).update(envelope_info);
                                                renewAD_Status(envelope_info);
                                                //INVOKE_ALL("INVOKE_Envelope_InfoRecordList", "");
                                                if(envelope_info.getCB_Amount()-new Envelope_Info_recordDAO(context).getCB_AmountByAdHash(envelope_info.getHash()) < envelope_info.getCBPerClick()) {
                                                    INVOKE_BlockChain_Broadcasting("Calculate Result: smaller");
                                                    break;
                                                }
                                            }
                                        //}
                                        replyAdHash_CBPerClick(envelope_info, memberid);
                                    }
                                }
                            //}
                        }
                    }
                    //Blosk delivered from other
                    else if (message.contains("BlockChain_Broadcasting:")) {
                        //new BlockThread(message,true,callback).start();
                        //listBlockmessage.add(new BlockMessage(message,true));
                        InsertBlockDAO(message);
                    }
                }
            }
        }, String.class, String.class, String.class, String.class);

        final String HUB_Hidden_Signal_Receive = "Hidden_Signal_Receive";
        mHub.on(HUB_Hidden_Signal_Receive, new SubscriptionHandler4<String, String, String, String>() {
            public void run(String sender, String mType, String message,String submessage) {
                Lasttime_milliseconds=new Date().getTime();
                //setConnect(true);
                //String blockmessage=submessage;
                if (mType.equals("replyAdHash_CBPerClick")) {
                    Envelope_Info_record eir=new Envelope_Info_record();
                    eir.setAd_hash(message.split(":")[0]);
                    eir.setRecord_hash(message.split(":")[1]);
                    eir.setPublisher_id(message.split(":")[2]);
                    eir.setSubscriber_id(message.split(":")[3]);
                    eir.setCBPerClick(Double.parseDouble(message.split(":")[4]));
                    eir.setIsConfirmed(Boolean.parseBoolean(message.split(":")[5]));
                    eir.setCreateTime(eir.getCreateTime());
                    new Envelope_Info_recordDAO(context).insert(eir);
                    INVOKE_ALL("INVOKE_Envelope_InfoRecordList", "");
                }
                else if(mType.equals("feedbackADpublisher_addCount")){
                    new Envelope_InfoDAO(context).addCount(message.split(":")[0]);
                    INVOKE_ALL("INVOKE_Envelope_InfoList","");
                    new Envelope_Info_recordDAO(context).setConfirmed(message.split(":")[1]);
                    INVOKE_ALL("INVOKE_Envelope_InfoRecordList","");
                }
                else if (mType.equals("sendMyAd")) {
                    //INVOKE_BlockChain_Broadcasting("Receiving Ad. from:\n"+submessage);
                    envelope_info= new Envelope_Info();
                    String[] a = submessage.split(":");
                    //INVOKE_BlockChain_Broadcasting("Receiving_AD.a[].size(): "+a.length);
                    envelope_info.setHash(a[0]);
                    envelope_info.setStatus(Integer.parseInt(a[1]));
                    envelope_info.setInfo_type(Integer.parseInt(a[2]));
                    envelope_info.setPublisher_id(a[3]);
                    envelope_info.setLanguage(a[4]);
                    envelope_info.setSubject(a[5].replace("_",":"));
                    envelope_info.setContent(a[6].replace("_",":"));
                    envelope_info.setLink(a[7]);
                    //INVOKE_BlockChain_Broadcasting("Receiving_AD.a[7]: "+a[7]);

                    envelope_info.setCB_Amount(Double.parseDouble(a[9]));
                    //INVOKE_BlockChain_Broadcasting("Receiving_AD.a[9]: "+a[9]);

                    envelope_info.setCBPerClick(Double.parseDouble(a[10]));
                    envelope_info.setCount(Integer.parseInt(a[11]));
                    //INVOKE_BlockChain_Broadcasting("Receiving_AD.a[11]: "+a[11]);

                    envelope_info.setNote(a[12]);
                    //INVOKE_BlockChain_Broadcasting("Receiving_AD.a[12]: "+a[12]);
                    //INVOKE_BlockChain_Broadcasting("Receiving_AD.a[13]: "+a[13]);

                    if(a[13].equals("_")){
                        new Envelope_InfoDAO(context).updateCount(envelope_info);
                        //INVOKE_ALL("INVOKE_Envelope_InfoList","");
                    }else {
                        envelope_info.setImageStr(a[13]);
                        //Bitmap bm = RealPathUtil.decodeBase64AndSetImage(a[13]);
                        saveImage(envelope_info);
                    }
                }
                else if(mType.equals("Apply_Maker_Request_Block")){
                    String datatype=submessage.split(":")[0];
                    String data=submessage.split(":")[1];
                    //String applicant=data.split(" ")[0];
                    //String note=data.split(" ")[2];
                    //data = HCID + " 0 fromHC";
                    if(datatype.equals("getHC")){
                        Async_HCtoPCB_procedure hCtoPCBTask=new Async_HCtoPCB_procedure();
                        hCtoPCBTask.execute(submessage);
                    }else if(datatype.equals("Registration")||datatype.equals("RG_1")){
                        Member member=new Member();
                        String _data = submessage.split(":")[1];
                        member.setIntroducerid(_data.split("")[0]);
                        member.setHcid(_data.split("")[1]);
                        member.setPublicKey(_data.split("")[2]);
                        //if not registered, make a block of registration
                        if(new MemberDAO(context).isAbleToInsert(member)) {
                            new BlockThread(submessage, false, callback).start();
                            //INVOKE_BlockChain_Broadcasting("blockmessage: "+submessage);
                        }
                    }
                    //notify applicant to delete applyBlock in applicant's phone
                    if(isConnect) {
                        ArrayList<String> L = new ArrayList<>();
                        L.add(sender);
                        mType = "Reply_Applicant_Request_Block";
                        //sender = HCID ;
                        String hash = message.split(" ")[1];
                        //INVOKE_BlockChain_Broadcasting("Reply_Applicant:"+sender+" / "+L.toString()+" / "+message);
                        try {
                            mHub.invoke(HUB_Hidden_Signal_Send, L, HCID, mType, hash, "").get();
                        } catch (Exception e) {}
                    }
                }
                else if(mType.equals("Reply_Applicant_Request_Block")){
                    //INVOKE_BlockChain_Broadcasting("message:"+message);
                    new applyBlockDAO(context).deleteByHash(message);
                }
                else if(mType.equals("ResponsetoSendBlockfromIndex")){
                    // Create a child thread.
                    Thread childThread = new Thread() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                //ignore
                            }
                            //listBlockmessage.add(new BlockMessage(message,true));
                            //check if already existed in BlockDAO by Hash
                            //new BlockThread(submessage,true,callback).start();
                            //listBlockmessage.add(new BlockMessage(submessage,true));
                            InsertBlockDAO(submessage);
                        }
                    };
                    // Start the thread.
                    childThread.start();
                }
                else if (mType.equals("AskMakerSendBlockfromIndex")&!sender.isEmpty()) {
                    index_end = 99;
                    long index_start= Long.parseLong(message.split(":")[0]);
                    if(blockchainDAO.getCount()>0){
                        if (message.split(":")[1].equals("9999")||Long.parseLong(message.split(":")[1])>blockchainDAO.getCount()-1
                        ) {
                            index_end = blockchainDAO.getCount() - 1;
                        } else {
                            index_end = Long.parseLong(message.split(":")[1]);
                        }
                        if(index_end>=index_start){
                            String mess = context.getResources().getString(R.string.content_message_respond)+" " + sender + " ";
                            long count=index_end-index_start+1;
                            if (index_start==index_end) {
                                mess += context.getResources().getString(R.string.content_message_send_block) + message.split(":")[0] +" "+context.getResources().getString(R.string.content_message_to_get)+" 1 "+context.getResources().getString(R.string.content_message_conectivity_score);
                            } else {
                                mess += context.getResources().getString(R.string.content_message_send_from) + message.split(":")[0] + " "+context.getResources().getString(R.string.content_message_to_no) + index_end+" "+context.getResources().getString(R.string.content_message_to_get)+" "+count+" "+context.getResources().getString(R.string.content_message_conectivity_scores);
                            }
                            INVOKE_BlockChain_Broadcasting(mess);
                            for (long l = Long.parseLong(message.split(":")[0]);
                                 l < index_end + 1; l++) {
                                Block b = blockchainDAO.getByIndex(l);
                                if (b != null) {
                                    if (blockchain.isValidBlock(b)) {
                                        ResponsetoSendBlockfromIndex(l, sender, blockchainDAO.getByIndex(l));
                                    } else {
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }, String.class, String.class, String.class, String.class);

        /*mHub.on(HUB_EVENT_Receive, new SubscriptionHandler4<String, String, String, String>() {
            public void run(String memberid, String name, String picFile, String message) {
                Lasttime_milliseconds=new Date().getTime();
                if (message.contains("MeSsFrOmAlaRm")) {
                    //Lasttime_milliseconds = new Date().getTime();
                    //setLastMessageTime();
                    //INVOKE_BlockChain_Broadcasting("INVOKE_to_HyperConn:MeSsFrOmAlaRm");
                }
            }
        }, String.class, String.class, String.class, String.class);*/
    }
    //endregion

    private String getBase64String(String realpath) {
        // give your image file url in mCurrentPhotoPath
        Bitmap bitmap = BitmapFactory.decodeFile(realpath);

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        // In case you want to compress your image, here it's at 40%
        bitmap.compress(Bitmap.CompressFormat.JPEG, 40, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();

        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void saveImage(Envelope_Info envelope_info) {
        Bitmap bm = RealPathUtil.decodeBase64AndSetImage(envelope_info.getImageStr());
        SaveImageTask saveImageTask = new SaveImageTask(context, filePath -> onSaveComplete(envelope_info,filePath));
        saveImageTask.execute(bm);
    }

    private void onSaveComplete(Envelope_Info envelope_info,File filePath) {
        if (filePath == null) {
            //Log.w(TAG, "onSaveComplete: file dir error");
            return;
        }
        String realPath = filePath.getPath();
        envelope_info.setImage_path(realPath);
        new Envelope_InfoDAO(context).insert(envelope_info);
        //INVOKE_BlockChain_Broadcasting("Envelope_InfoDAO.realPath :"+realPath);
        INVOKE_ALL("INVOKE_Envelope_InfoList","");
        //save realpath
        //SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key3, realPath);
    }
    private void replyAdHash_CBPerClick(Envelope_Info envelope_info,String hcid){
        String mType = "replyAdHash_CBPerClick";
        Envelope_Info_record eir=new Envelope_Info_record();
        eir.setAd_hash(envelope_info.getHash());
        eir.setPublisher_id(HCID);
        eir.setSubscriber_id(hcid);
        eir.setRecord_hash(eir.calculateHash(eir));
        new Envelope_Info_recordDAO(context).insert(eir);
        INVOKE_ALL("INVOKE_Envelope_InfoList", "");
        INVOKE_ALL("INVOKE_Envelope_InfoRecordList", "");
        //INVOKE_BlockChain_Broadcasting("Reply Inquiry_2 of Ad. to:\n"+hcid+"\n"+envelope_info.getHash());
        if(isConnect){
            ArrayList<String> L=new ArrayList();
            L.add(hcid);
            String message=eir.toString();
            try {
                mHub.invoke(HUB_Hidden_Signal_Send, L, HCID, mType, message, "").get();
            } catch (InterruptedException e) {
                //e.printStackTrace();
            } catch (ExecutionException e) {
                //e.printStackTrace();
            }
        }
    }

    private void sendMyAd(Boolean isUpdate,Envelope_Info envelope_info, String hcid) {
        String ImageStr="";
        String mess=envelope_info.getHash() +
                ":" + envelope_info.getStatus() +
                ":" + envelope_info.getInfo_type() +
                ":" + envelope_info.getPublisher_id() +
                ":" + envelope_info.getLanguage() +
                ":" + envelope_info.getSubject().replace(":","_") +
                ":" + envelope_info.getContent().replace(":","_") +
                ":" + envelope_info.getLink() +
                ":" + envelope_info.getImage_path() +
                ":" + envelope_info.getCB_Amount() +
                ":" + envelope_info.getCBPerClick() +
                ":" + envelope_info.getCount() +
                ":" + envelope_info.getNote();
        if(!isUpdate){
            ImageStr=getBase64String(envelope_info.getImage_path());
        }else{
            ImageStr="_";
        }
        if(isConnect){
            mess +=":" + ImageStr;
            String mType = "sendMyAd";
            String sender = HCID;
            INVOKE_BlockChain_Broadcasting("Sending Ad.to:\n"+hcid + "\nisNew(?) "+!isUpdate);
            ArrayList<String> L=new ArrayList();
            L.add(hcid);
            try {
                mHub.invoke(HUB_Hidden_Signal_Send, L, sender, mType, "", mess).get();
            } catch (InterruptedException e) {
                //e.printStackTrace();
            } catch (ExecutionException e) {
                //e.printStackTrace();
            }
        }

    }

    private void InsertBlockDAO(String blockmessage){
        Block block=new Block();
        String[] eachlineStr = blockmessage.split("\n");
        int index = Integer.parseInt(eachlineStr[0].split("#")[1].split(" ")[0]);
        String datatype = eachlineStr[0].split(" ")[2];
        int nonce = Integer.parseInt(eachlineStr[0].split(" ")[3]);
        long timestamp = Long.parseLong(eachlineStr[1].split(":")[1]);
        String maker = eachlineStr[2].split(":")[1];
        String Hash = eachlineStr[3].split(":")[1];
        String data =  blockmessage.split("\ndata:")[1];
        block.setIndex(index);
        block.setMaker(maker);
        block.setTimestamp(timestamp);
        block.setData(data);
        block.setDatatype(datatype);
        block.setNonce(nonce);
        block.setHash(Hash);
        String previousHash = eachlineStr[4].split(":")[1];
        if (index > 0) {
            block.setPreviousHash(previousHash);
        } else {
            block.setPreviousHash(null);
        }
        addToBlockDAO(block);
        INVOKE_BlockChain_Broadcasting(block.toShow());
        SCORE_COUNT_BLOCKS++;
    }

    public double add(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.add(b2).doubleValue();
    }

    private class Async_applyBlock extends AsyncTask<String, Void, Integer> {
        //String type;
        @Override
        protected Integer doInBackground(String... params) {
            //check_applyBlock();
            return check_applyBlock();
        }

        @Override
        protected void onPostExecute(Integer result) {
            INVOKE_BlockChain_Broadcasting("applyBlock.size(): "+result);
            Async_check_HCtoPCB check_HCtoPCBTask=new Async_check_HCtoPCB();
            check_HCtoPCBTask.execute(HCID);
        }

        @Override
        protected void onPreExecute() {
            isCheckBlockchainFinished=false;

        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    //本人註冊時委託別人幫忙打包, HC to PCB時會用
    private int check_applyBlock(){
        List<applyBlock> listab=new applyBlockDAO(context).getAll();
        //INVOKE_BlockChain_Broadcasting("listab.size(): "+ listab.size());
        for(applyBlock ab:listab){
            String message=ab.getApplicant()+" "+ab.getHash();
            String submessage=ab.getDatatype()+":"+ab.getData();
            boolean isAbbreviated=false;
            if(ab.getDatatype().equals("Registration")||ab.getDatatype().equals("RG_1")){
                if(ab.getData().split(" ")[0].length()<7){
                    isAbbreviated=true;
                }
            }
            //INVOKE_BlockChain_Broadcasting("callsignalRtoBlockmaker: "+ ab.getHash());
            signalRtoBlockmaker(isAbbreviated,message,submessage);
        }
        return listab.size();
    }
    //註冊時用 isAbb=true 代表介紹人的HCID是縮寫
    private void signalRtoBlockmaker(Boolean isAbb,String message,String submessage) {
        //INVOKE_BlockChain_Broadcasting("signalRtoBlockmaker: "+ isConnect());
        if (isAbb) {            //如果是縮寫，就發訊息 問誰是...
            if (isConnect) {
                try {
                    String name = "Apply_Maker_Request_Block";
                    mHub.invoke(HUB_chat_public_Send, mMemID, name, submessage, message).get();
                } catch (Exception e) {}
            }
        } else {
            String maker = new BlockchainDAO(context).getByIndex(0).getMaker();
            //INVOKE_BlockChain_Broadcasting("signalRtoBlockmaker2: "+maker);

            if (Utils.isBlank(maker) || !isConnect) {
                return;
            }
            String mType = "Apply_Maker_Request_Block";
            String sender = HCID;
            final int BufferTime_getPCBfromHC = 30*60*1000; //Do not proceess twice within this BufferTime
            long Last_HCtoPCB_Time = SharedPreferencesHelper.getSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key26, 0l);
            long intervalTime = new Date().getTime() - Last_HCtoPCB_Time;
            if (submessage.split(":")[0].equals("RG_1")) {
                maker = submessage.split(":")[1].split(" ")[0];
            } else {
                INVOKE_BlockChain_Broadcasting("signalRtoBlockmaker3: "+intervalTime+" / "+BufferTime_getPCBfromHC);
                if (intervalTime < BufferTime_getPCBfromHC) {
                    return;
                }
            }
            if (isConnect) {
                ArrayList<String> L = new ArrayList<String>();
                L.add(maker);
                try {
                    INVOKE_BlockChain_Broadcasting("HUB_Hidden_Signal_Send: "+Utils.formatDoubleToString(Double.parseDouble(String.valueOf(intervalTime/1000)))+" secs ago");
                    mHub.invoke(HUB_Hidden_Signal_Send, L, sender, mType, message, submessage).get();
                    SharedPreferencesHelper.putSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key26, new Date().getTime());
                } catch (Exception e) {
                }
            }
        }
    }
    // Step 4.Clear probably redundant Blocks in blockDAO

    private class Async_clearRedundantBlocks extends AsyncTask<String, Void, Void> {
        //String type;
        @Override
        protected Void doInBackground(String... params) {
            for (Block b : blockDAO.getAll()) {
                long id=b.getId();
                boolean needrepack=false;
                //Only Those Blocks created within 24 hours could be repacked
                // if block is older than 2hours and valid,repack it keep alive and wait to be chained
                if ((new Date().getTime() - b.getCreateTime() > Block_SurvivalTime)) {
                    if ((new Date().getTime() - b.getTimestamp() < 24 * 60 * 60 * 1000)) {
                        if (b.getIndex() > 0 &
                                !blockchainDAO.isExisted(b.getHash()) &
                                blockchain.isValidBlock(b)) {
                            if (!b.getMaker().equals(HCID)) {
                                //As a maker of Block#0 ,Although not the maker of registration ,help to repack block "Registration" not registered yet
                                if (b.getDatatype().equals("Registration")||b.getDatatype().equals("RG_1")) {
                                    if (blockchainDAO.isRegistering(b.getData().split(" ")[1]) == null &
                                            blockchainDAO.getByIndex(0).getMaker().equals(HCID)) {
                                        needrepack = true;
                                    }
                                }
                                //I'm maker
                            } else {
                                if (b.getDatatype().equals("Registration")||b.getDatatype().equals("RG_1")) {
                                    if (blockchainDAO.isRegistering(b.getData().split(" ")[1]) == null) {
                                        needrepack = true;
                                    }
                                } else {
                                    needrepack = true;
                                }
                            }
                        }
                    }
                    if (needrepack) {
                        repackBlock(b);
                    }
                    blockDAO.delete(id);
                    //INVOKE_BlockChain_Broadcasting(context.getResources().getString(R.string.content_message_delete_block) + " clear.id: " + b.getId());
                    try {
                        Thread.sleep(100);
                    } catch (Exception e) {
                        //
                    }
                }
                /*}else{
                    blockDAO.delete(id);
                    INVOKE_BlockChain_Broadcasting(context.getResources().getString(R.string.content_message_delete_block)+" clear.id: " + b.getId());
                    try{Thread.sleep(100);}catch(Exception e){}
                }*/

            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            request_checkData();
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    private class Async_check_HCtoPCB extends AsyncTask<String, Void, Void> {
        //String type;
        @Override
        protected Void doInBackground(String... params) {
            check_HCtoPCB(params[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            new BlockchainCheckThread(callback).start();
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    //檢查HC to PCB; 時間是否已到了可以HC 轉 PCB的時間
    private void check_HCtoPCB(String hcid){
        double amount=new HyperConnectivityDAO(context).getAmount_HCtoPCB(hcid)/3;
        if(amount>0.02){
            long intervaTime=new Date().getTime()-new HyperConnectivityDAO(context).getLastTimeToPcbByHcid(hcid);
            long intervaTime0=new Date().getTime()-new BlockchainDAO(context).getLastTimeOfHCtoPCB(hcid);
            long intervaTime1=new Date().getTime()-new BlockDAO(context).getLastTimeOfHCtoPCB(hcid);
            long intervaTime2=new Date().getTime()-new applyBlockDAO(context).getLastTimeOfPcb();
            if(
                    intervaTime > IntervalTime_getPCBfromHC &
                            intervaTime0 > IntervalTime_getPCBfromHC &
                            intervaTime1 > IntervalTime_getPCBfromHC &
                            intervaTime2 > IntervalTime_getPCBfromHC
            ){
                String datatype="getHC";
                String note="toPCB";
                String data=HCID+" -"+Utils.formatDoubleToString(amount)+" "+note;
                INVOKE_ALL("INVOKE_BlockChain_Broadcasting","applyBlock HCtoPCB: "+data.split(" ")[1]+"\n");
                applyBlock(datatype, data);
            }
        }
    }

    private class Async_HCtoPCB_procedure extends AsyncTask<String, Void, Double> {
        String blockmessage;
        String data;
        String applicant;
        @Override
        protected Double doInBackground(String... params) {
            this.blockmessage=params[0];
            return HCtoPCB_procedure(blockmessage);
        }
        @Override
        protected void onPostExecute(Double amount) {
            //Double amount = result;
            data=blockmessage.split(":")[1];
            applicant=data.split(" ")[0];
            INVOKE_ALL("INVOKE_BlockChain_Broadcasting","Apply_Maker_Request_Block: "+applicant+" / "+Utils.formatDoubleToString(amount)+"\n");
            if(amount>0){
                new BlockThread(blockmessage, false, callback).start();
                //listBlockmessage.add(new BlockMessage(blockmessage,false));
                try {Thread.sleep(3000);} catch (Exception e) {}
                //another block to add PCB
                String datatype = "getPCB";
                String note = "fromHC";
                blockmessage = datatype + ":" +
                        applicant + " " +
                        Utils.formatDoubleToString(amount * 3) + " " +
                        note;
                new BlockThread(blockmessage, false, callback).start();
                listBlockmessage.add(new BlockMessage(blockmessage,false));
            }
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private Double HCtoPCB_procedure(String blockmessage) {
        //String result="";
        String data=blockmessage.split(":")[1];
        String applicant=data.split(" ")[0];
        double amount = new HyperConnectivityDAO(context).getAmount_HCtoPCB(applicant) / 3;
        if (amount > 0.02) {
            long intervaTime = new Date().getTime() - new HyperConnectivityDAO(context).getLastTimeToPcbByHcid(applicant);
            long intervaTime0 = new Date().getTime() - new BlockchainDAO(context).getLastTimeOfHCtoPCB(applicant);
            long intervaTime1 = new Date().getTime() - new BlockDAO(context).getLastTimeOfHCtoPCB(applicant);
            if (intervaTime < IntervalTime_getPCBfromHC ||
                    intervaTime0 < IntervalTime_getPCBfromHC ||
                    intervaTime1 < IntervalTime_getPCBfromHC ){
                amount=0d;
            }
        }
        return amount;
    }

    private class BlockchainCheckThread extends Thread {
        Callback c;

        public BlockchainCheckThread(Callback c) {
            this.c = c;
        }

        @Override
        public void run() {
            //while (true) {}
            Check_Blockchain_procedure();
            this.c.callback_BlockchainCheckThread();
        }
    }

    private void check_blockchain_debute (){
        String mess=
                context.getResources().getString(R.string.content_message_countblocks)+": "+blockchain.count()+
                " , "+context.getResources().getString(R.string.content_message_isblockchainvalidated)+" : ";
        if(blockchain.isBlockChainValid()){
            mess += context.getResources().getString(R.string.content_message_true);
        }else{
            mess += context.getResources().getString(R.string.content_message_false) +
                    "\n\n"+ blockchain.reasonBlockChainNotValid()+"\n";
        }
        mess+="\n\n"+context.getResources().getString(R.string.app_name)+": "+context.getResources().getString(R.string.app_ver);
        INVOKE_BlockChain_Broadcasting(mess);
        if(!blockchain.isBlockChainValid()){
            Blockchain newBlockchain=new Blockchain();
            for(Block b:blockchain.blocks){
                mess="Block# "+ b.getIndex();
                if(b.getIndex()==0){
                    if(newBlockchain.isFirstBlockValid(b)){
                       newBlockchain.addExistedBlock(b);
                        //mess+=" true";
                    }
                }else {
                    if(newBlockchain.isValidNewBlock(b,newBlockchain.latestBlock())){
                        newBlockchain.addExistedBlock(b);
                        //mess+=" true";
                    }else{
                        addToBlockDAO(b);
                        blockchainDAO.deletebyIndex(b.getIndex());
                        //mess+=" false";
                    }
                }
            }
            mess="new blockchain is born as count: "+ newBlockchain.count();
            INVOKE_BlockChain_Broadcasting(mess);
            blockchain=newBlockchain;
        }else{
            mess=context.getResources().getString(R.string.content_message_ready);
            INVOKE_BlockChain_Broadcasting(mess);
        }
    }

    //打包新區塊之後，廣播訊息通知
    public void BlockchainBroadCast(Block block) {
        //Check validation of Blockchain later
        if (blockchain.isBlockChainValid() && isConnect){
            //if(isConnect()) {
                try {
                    String message = "BlockChain_Broadcasting:" + block.toString();
                    mHub.invoke(HUB_chat_public_Send, mMemID, mName, mPicfile, message).get();
                } catch (Exception e) {
                    //e.printStackTrace();
                }
            //}
        }
    }



    /*private void INVOKE_registrationDialog(){
        Intent i = new Intent("INVOKE_registrationDialog");
        sendBroadcast(i);
    }*/

    private void INVOKE_showDialog_HyperConnActivity(String title,String message,String submessage){
        Intent i = new Intent("INVOKE_registration_result_Dialog");
        i.putExtra("title", title);
        i.putExtra("message", message);
        i.putExtra("submessage", submessage);
        sendBroadcast(i);
    }

    private void Invoke_NewAPKArrived(String message){
        Intent i = new Intent("INVOKE_NewAPKArrived");
        i.putExtra("What", message);
        sendBroadcast(i);
    }

    private void INVOKE_BlockChain_Broadcasting(String mess){
        Intent i = new Intent("INVOKE_BlockChain_Broadcasting");
        mess+="\n";
        i.putExtra("What", mess);
        sendBroadcast(i);
    }

    private void INVOKE_ALL(String invoke,String mess){
        Intent i = new Intent(invoke);
        i.putExtra("What", mess);
        sendBroadcast(i);
    }
    private void INVOKE_CONTENT_TITLE(String mess){
        String invoke="INVOKE_to_HyperConn_content_title";
        Intent i = new Intent(invoke);
        i.putExtra("content_title", mess);
        sendBroadcast(i);
    }
    private void Invoke_BlockchainList(){
        Intent i = new Intent("Invoke_BlockchainList");
        i.putExtra("What", "");
        sendBroadcast(i);
    }

    private void addToBlockDAO(Block b) {
        //BlockDAO bD = new BlockDAO(context);
        //Create a child thread
        Thread childThread = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    //ignore
                }

                if (!blockDAO.isExisted(b.getHash())) {
                    blockDAO.insert(b);
                }
            }
        };
        // Start the thread.
        childThread.start();
        //bD.close();
    }

    private String addToBlockchainDAO(Blockchain blockchain,Block block){
        String mess="";
        if(blockchainDAO.getCount()==0){
            if (blockchain.isFirstBlockValid(block)){
                blockchainDAO.insert(block);
            }else{
                mess="Block #"+block.getIndex()+" is not the first one and fails to be inserted into BlockchainDAO.";
                return mess;
            }
        }else{
            if(blockchain.isValidNewBlock(block,blockchainDAO.getBlock_MaxId())){
                blockchainDAO.insert(block);

            }else{
                mess="Block #"+block.getIndex()+" / "+block.getId()+" "+context.getResources().getString(R.string.content_message_block_validated_fail);
                return mess;
            }
        }
        mess="Block #"+block.getIndex()+" / "+block.getId()+" "+context.getResources().getString(R.string.content_message_block_validated_succeed);
        //blockchain.setBlockList(blockchainDAO.getAll());
        //blockchain.addExistedBlock(block);
        this.blockchain =blockchain;
        return mess;
    }

    public void AskMakerSendBlockfromIndex(long start_index, long end_index, String cMemid) {
        String mess = "";
        if (mMemID.equals(cMemid)) {
            mess="Since I am the maker of the block has Max.index, just be waiting..";
            INVOKE_BlockChain_Broadcasting(mess);
            return;
        }
        long count=end_index-start_index+1;
        if (start_index == end_index) {
            mess = context.getResources().getString(R.string.content_message_ask)+" " + cMemid + " " +context.getResources().getString(R.string.content_message_send_block) + start_index+" "+context.getResources().getString(R.string.content_message_to_get)+" 1 "+context.getResources().getString(R.string.content_message_conectivity_score);
        } else {
            mess = context.getResources().getString(R.string.content_message_ask)+" " + cMemid + " "+context.getResources().getString(R.string.content_message_send_from)  + start_index + " " +context.getResources().getString(R.string.content_message_to_no) + end_index+" "+context.getResources().getString(R.string.content_message_to_get)+" "+count+" "+context.getResources().getString(R.string.content_message_conectivity_scores);
        }
        INVOKE_BlockChain_Broadcasting(mess);
        if(isConnect) {
            ArrayList<String> L = new ArrayList();
            L.add(cMemid);
            String mType = "AskMakerSendBlockfromIndex";
            String message = start_index + ":" + end_index;
            String subMessage = "";
            String sender = mMemID;

            try {
                mHub.invoke(HUB_Hidden_Signal_Send, L, sender, mType, message, subMessage).get();
            } catch (InterruptedException e) {
                //e.printStackTrace();
            } catch (ExecutionException e) {
                //e.printStackTrace();
            }
        }
    }

    public void ResponsetoSendBlockfromIndex(long index,String cMemid,Block block) {
        //INVOKE_BlockChain_Broadcasting("Respond "+cMemid+" to send Blocks #"+index);
        if(isConnect) {
            ArrayList<String> L = new ArrayList();
            L.add(cMemid);
            String mType = "ResponsetoSendBlockfromIndex";
            String message = String.valueOf(index);
            String subMessage = block.toString();
            String sender = mMemID;
            try {
                mHub.invoke(HUB_Hidden_Signal_Send, L, sender, mType, message, subMessage).get();
            } catch (InterruptedException e) {
                //e.printStackTrace();
            } catch (ExecutionException e) {
                //e.printStackTrace();
            }
            SCORE_COUNT_BLOCKS++;
        }
    }

    private String getCurrentTime() {
        Date d = new Date();
        SimpleDateFormat dt1 = new SimpleDateFormat("HH:mm");
        return dt1.format(d.getTime());
    }

    private class BlockMessage{
        public String blockmessage;
        public boolean isBlockString;
        public BlockMessage(String blockmessage,Boolean isBlockString){
            this.blockmessage=blockmessage;
            this.isBlockString=isBlockString;
        }
    }

    private class BlockThread extends Thread{
        //List<BlockThread> rank;
        Callback c;
        boolean isBlockString,need_to_process;
        String message;
        public BlockThread(String message,Boolean isBlockString,Callback c) {
            this.c=c;
            this.isBlockString=isBlockString;
            this.message=message;
            BlockThread_CallTime = new Date().getTime();
            need_to_process=true;
            //if(need_to_process){
                if (BlockThread_CallTime - BlockThread_StartTime > BlockThread_IntervalTime) {
                    BlockThread_StartTime = BlockThread_CallTime;
                } else {
                    BlockThread_StartTime += BlockThread_IntervalTime;
                }
            //}
        }
        @Override
        public void run() {
            //while (true) {
                long intervaltime = BlockThread_CallTime - BlockThread_StartTime;
                if (intervaltime < BlockThread_IntervalTime) {
                    try {
                        Thread.sleep(BlockThread_IntervalTime - intervaltime);
                    } catch (Exception e) {
                    }
                }
                Block block = new Block();
                if (isBlockString) {
                    //INVOKE_BlockChain_Broadcasting(message);
                    //if(!new BlockDAO(context).isExisted(message.split("\n")[3].split(":")[1])){}
                    String[] eachlineStr = message.split("\n");
                    int index = Integer.parseInt(eachlineStr[0].split("#")[1].split(" ")[0]);
                    String datatype = eachlineStr[0].split(" ")[2];
                    int nonce = Integer.parseInt(eachlineStr[0].split(" ")[3]);
                    long timestamp = Long.parseLong(eachlineStr[1].split(":")[1]);
                    String maker = eachlineStr[2].split(":")[1];
                    String Hash = eachlineStr[3].split(":")[1];
                    String previousHash = eachlineStr[4].split(":")[1];
                    //String data = eachlineStr[5].split(":")[1];
                    String data =  message.split("\ndata:")[1];
                    block.setIndex(index);
                    block.setMaker(maker);
                    block.setTimestamp(timestamp);
                    block.setData(data);
                    block.setDatatype(datatype);
                    block.setNonce(nonce);
                    block.setHash(Hash);
                    if (index > 0) {
                        block.setPreviousHash(previousHash);
                        //if the index of incoming block is bigger than blockchain.count()
                        if (index >= blockchain.count()) {
                            if (blockchain.isValidNewBlock(block, blockchain.latestBlock())) {
                                blockchain.addExistedBlock(block);
                            }
                        }
                        //it's a allnew blockchain
                    } else {
                        if (blockchain.count() == 0 & blockchain.isFirstBlockValid()) {
                            blockchain = new Blockchain(4, block);
                        }
                    }
                    if (blockchain.isValidBlock(block)) {
                        if(new BlockDAO(context).isExisted(block.getHash())||new BlockchainDAO(context).isExisted(block.getHash())){
                            need_to_process=false;
                        }
                        addToBlockDAO(block);
                        //blockDAO.insert(block);
                        INVOKE_BlockChain_Broadcasting(block.toShow());
                    }
                    //}
                //generate a new Block
                } else {
                    SCORE_COUNT_BLOCKS++;
                    BlockThread_StartTime += BlockThread_IntervalTime*2;
                    String datatype = message.split(":")[0];
                    String data = message.split(":")[1];
                    block = blockchain.addBlock(blockchain.newBlock(mMemID, datatype, data));
                    if (block.getIndex() == 1) {
                        if(new BlockDAO(context).isExisted(block.getHash())||new BlockchainDAO(context).isExisted(block.getHash())){
                            need_to_process=false;
                        }
                        addToBlockDAO(blockchain.getFirstBlock());
                        BlockchainBroadCast(blockchain.getFirstBlock());
                        INVOKE_BlockChain_Broadcasting(blockchain.getFirstBlock().toShow());
                        this.c.callback_BlockThread(blockchain.getFirstBlock(),need_to_process);
                        //try{Thread.sleep(3000);}catch (Exception e){}
                    }
                    if(new BlockDAO(context).isExisted(block.getHash())||new BlockchainDAO(context).isExisted(block.getHash())){
                        need_to_process=false;
                    }
                    addToBlockDAO(block);
                    INVOKE_BlockChain_Broadcasting(block.toShow());
                    BlockchainBroadCast(block);
                }
                this.c.callback_BlockThread(block,need_to_process);
            }
        //}
    }

    private Boolean check_registering(String HCID){
        boolean isRegistered=false;
        long interval=new Date().getTime()-SharedPreferencesHelper.getSharedPreferencesLong(context,SharedPreferencesHelper.SharedPreferencesKeys.key107,0l);
        if(interval<1000*60*10){
            isRegistered=true;
        }
        Block block=null;
        if(new BlockDAO(context).isRegistering(HCID)!=null){
            block=new BlockDAO(context).isRegistering(HCID);
        }else if(new BlockchainDAO(context).isRegistering(HCID)!=null){
            block=new BlockchainDAO(context).isRegistering(HCID);
        }
        if(block!=null){
            /*Member member=new Member();
            member.setIntroducerid(block.getData().split(" ")[0]);
            member.setBlockIndex(block.getIndex());
            member.setHcid(block.getData().split(" ")[1]);
            member.setPublicKey(block.getData().split(" ")[2]);
            if(new MemberDAO(context).insert(member)==0){*/
                isRegistered=true;
            //}
        }
        return isRegistered;
    }

    private void removeBothBlockchain(){
        blockchain=new Blockchain(4,context);
        for(Block b:blockchainDAO.getAll()){
            long id=b.getId();
            addToBlockDAO(b);
            blockchainDAO.delete(id);
        }
    }

    private void Check_Blockchain_procedure() {
        //BlockchainThread_CallTime = new Date().getTime();
        //long intervaltime = BlockchainThread_CallTime - BlockThread_StartTime;
        //check if BlockThread done the work
        //INVOKE_BlockChain_Broadcasting("Check_Blockchain_procedure");
        if (!isRegistered) {
            //INVOKE_BlockChain_Broadcasting("Check_Blockchain_procedure: "+!isRegistered);
            if (!check_registering(HCID)) {
                //INVOKE_BlockChain_Broadcasting("Check_Blockchain_procedure: "+!check_registering(HCID));
                //INVOKE_registrationDialog();
                Intent i = new Intent("INVOKE_registrationDialog");
                sendBroadcast(i);
            }
        }
        //INVOKE_registrationDialog();
        //if (new Date().getTime() > BlockThread_StartTime ) {
            if (!hasConflict) {
                // Step 2.
                //checkBlockchain from #0 to block_maxindex in BlockDAO
                // Ask maker of block_maxindex send the block from #index_notExistedcheckBlockchain();
                blockchainDAO=new BlockchainDAO(context);
                long max_index=blockchainDAO.getBlock_MaxIndex().getIndex() +1;
                if(blockchainDAO.getCount()>0){
                    if(blockchainDAO.getCount()!= (int)max_index){
                        INVOKE_BlockChain_Broadcasting("blockchainDAO.getCount(): "+ blockchainDAO.getCount() +" != blockchain.count() : " + blockchain.count() + " , move Blocks of blockchainDAO to blockDAO.");
                        removeBothBlockchain();
                    }
                    if (blockchainDAO.getCount() > blockchain.count()) {
                        blockchain.setBlockList(blockchainDAO.getAll());
                        /*if (!blockchain.isBlockChainValid()) {
                            INVOKE_BlockChain_Broadcasting("!blockchain.isBlockChainValid() :\n\n" +blockchain.reasonBlockChainNotValid() +"\n\nmove Blocks of blockchainDAO to blockDAO.");
                            removeBothBlockchain();
                        }else{
                            INVOKE_BlockChain_Broadcasting("blockchainDAO.getCount() > blockchain.count() : blockchainDAO.isBlockChainValid()");
                        }*/
                    }

                }
                checkBlockchain();
            } else {
                //Step 3. if there is first block existed in BlockDAO ,try to make another Blockchain
                backwardBlockchainThread();
            }
        //}
        // Step 4.Clear probably redundant Blocks in blockD

    }

    private void checkBlockchain() {
        //isCheckBlockchainFinished=false;
        long index_notExisted=-1;
        index_conflict=0;
        //String mess ="\nblockchainDAO.getCount() : "+blockchainDAO.getCount();
        //mess +="\ncount of Block : "+blockDAO.getCount();
        Block block_maxindex = blockDAO.getBlock_MaxIndex();
        long maxindex_block = block_maxindex.getIndex();
        Block block_maxindex_blockchain = blockchainDAO.getBlock_MaxIndex();
        long maxindex_blockchain = block_maxindex_blockchain.getIndex();
        //目前收到最大编号的区块
        //if bigger than已经存在资料库的区块链中最大编号的区块
        if (maxindex_block>maxindex_blockchain) {
            long start_index_check_blockchain =0;
            if(maxindex_blockchain>0){
                start_index_check_blockchain=maxindex_blockchain+1;
            }
            String mess;
            if(start_index_check_blockchain==maxindex_block){
                mess=context.getResources().getString(R.string.content_message_start_checking_block)+" #"+start_index_check_blockchain;
            }else{
                mess=context.getResources().getString(R.string.content_message_start_checking_block)+" "+context.getResources().getString(R.string.content_message_from_no)+
                        start_index_check_blockchain+" "+context.getResources().getString(R.string.content_message_to_no)+maxindex_block;
            }
            INVOKE_BlockChain_Broadcasting(mess);
            // Step 2.1.
            // Try to find next index of block in blockDAO to block_maxindex_blockchain,
            // and add it to blockchainDAO if be validated
            for(long l = start_index_check_blockchain; l <= block_maxindex.getIndex() ; l++) {

                if (blockDAO.getBlockListByIndex(l).size()>0) {

                    // check the first Block
                    boolean goNext=false;
                    //Block block=new Block();
                    //reverse the Arraylist to get new block first
                    for (Block block : blockDAO.getBlockListByIndex(l)) {
                            long id=block.getId();
                            if (l == 0) {
                                if (blockchain.isFirstBlockValid(block)) {
                                    addToBlockchainDAO(blockchain, block);
                                    INVOKE_BlockChain_Broadcasting("FirstBlock is validated and added to BlockchainDAO successfully!");
                                    Invoke_BlockchainList();
                                    //skip the loop
                                    goNext = true;
                                }
                                //delete this Block after being checked
                                //INVOKE_BlockChain_Broadcasting("id of the deleted FirstBlock :"+block.getId());
                                blockDAO.delete(id);
                                break;
                            }
                            // check following Blocks indexed after #0
                            else {
                                //validated it,insert Block to Blockchain
                                if (blockchain.CheckValidNewBlock(block, blockchainDAO.getBlock_MaxIndex())==0) {
                                    addToBlockchainDAO(blockchain, block);
                                    INVOKE_BlockChain_Broadcasting(context.getResources().getString(R.string.content_message_block)+" #" + l +" "+context.getResources().getString(R.string.content_message_block_validated_succeed));
                                    Invoke_BlockchainList();
                                    blockDAO.delete(id);
                                    goNext = true;
                                    break;
                                } else if (blockchain.CheckValidNewBlock(block, blockchainDAO.getBlock_MaxIndex())==3) {
                                    blockDAO.delete(id);
                                    INVOKE_BlockChain_Broadcasting(context.getResources().getString(R.string.content_message_block)+" #" + l + " / " + id + " " +context.getResources().getString(R.string.content_message_block_notvalidated_deleted));// +"\n"
                                }else{
                                    INVOKE_BlockChain_Broadcasting(context.getResources().getString(R.string.content_message_block)+ " #" + l + " / " + id + " " +context.getResources().getString(R.string.content_message_block_notvalidated));// +"\n"
                                }
                            }
                    }
                    if(!goNext){
                        index_conflict=l-1;
                        block_conflict=blockchainDAO.getBlock_MaxIndex();
                        //list_hash_Conflict.add(blockchainDAO.getBlock_MaxIndex().getHash());
                        hasConflict=true;
                        INVOKE_BlockChain_Broadcasting("index_conflict : "+index_conflict);
                        backwardBlockchainThread();
                        break;
                    }
                }
                //if block doesn't exist
                else {
                    index_notExisted = l;
                    hasConflict=false;
                    int inquiryCountBlocks;
                    if(new BlockDAO(context).getBlock_MaxIndex().getIndex()-index_notExisted>500){
                        inquiryCountBlocks=500;
                    }else if(new BlockDAO(context).getBlock_MaxIndex().getIndex()-index_notExisted>200){
                        inquiryCountBlocks=200;
                    }else if(new BlockDAO(context).getBlock_MaxIndex().getIndex()-index_notExisted>100){
                        inquiryCountBlocks=100;
                    }else {
                        inquiryCountBlocks = interval_count;
                    }
                long end_index=index_notExisted + inquiryCountBlocks;
                    if(end_index>block_maxindex.getIndex()){
                        end_index=block_maxindex.getIndex();
                    }
                    AskMakerSendBlockfromIndex(index_notExisted, end_index, block_maxindex.getMaker());
                    INVOKE_BlockChain_Broadcasting("index_notExisted : " + index_notExisted);
                    //stop checking
                    l = block_maxindex.getIndex() + 1;
                }
            }

        }else{
            hasConflict=false;
        }
        //isCheckBlockchainFinished=true;
    }

    private void backwardBlockchainThread() {
        //new Thread(new Runnable() {
        //public void run() {
        //isCheckBlockchainFinished = false;
        boolean isSucceed = false;
        //Step 1.initiate a new blockchain and add topblock
        Block topblock = new BlockDAO(context).getBlock_MaxIndex();
        String boss_maker_id =topblock.getMaker();
        //if topblock is too far away
        if (topblock.getIndex() - blockchainDAO.getCount() > interval_count) {
            long end_index = blockchainDAO.getCount() + interval_count;
            long start_index = blockchainDAO.getCount();
            /*if (start_index < 0) {
                start_index = 0;
            }*/
            boolean find_new_topblock = false;
            //INVOKE_ALL("INVOKE_BlockChain_Broadcasting", "BlockDAO(context).getBlockListByIndex("+end_index+").size(): "+new BlockDAO(context).getBlockListByIndex(end_index).size()+" \n");
            //for (Block b : new BlockDAO(context).getBlockListByIndex(end_index)) {
                if (new BlockDAO(context).getBlockListByIndex(end_index).size()>0) {
                    topblock = new BlockDAO(context).getBlockListByIndex(end_index).get(0);
                    find_new_topblock = true;
                }
            //}
            if (!find_new_topblock) {
                INVOKE_ALL("INVOKE_BlockChain_Broadcasting", "topblock.getIndex() is too big for backwardBlockchainThread, get near "+interval_count+" blocks first !\n");
                //isCheckBlockchainFinished = true;
                AskMakerSendBlockfromIndex(start_index, end_index, boss_maker_id);
                return;
            }
        }
        BlockchainDAO bcD = new BlockchainDAO(context);
        Blockchain backblockchain = new Blockchain();
        backblockchain.addExistedBlock(topblock);
        Block addedBlock = topblock;
        //Step 2.loop for searching previous block to addedblock
        INVOKE_ALL("INVOKE_BlockChain_Broadcasting", "topblock index :" + topblock.getIndex() + "\n");
        //try search previous block in BlockchainDAO, if it has , done!
        //Boolean isBreak = false;                //int count=0;
        for (int i = 1; i <= topblock.getIndex(); i++) {
            //while(!isBreak){
            if (bcD.getPreviousblock(addedBlock) != null || addedBlock.getIndex() == 0) {
                isSucceed = true;
                //INVOKE_ALL("INVOKE_BlockChain_Broadcasting", "bcD.getPreviousblock(addedBlock)!=null, backblockchain succeeds.\n");
                break;
            } else {
                addedBlock = new BlockDAO(context).getPreviousblock(addedBlock);
                //58,57,56,55,54
                if (addedBlock != null) {
                    backblockchain.addExistedBlock(addedBlock);
                    //if(addedBlock.getIndex()>3752&addedBlock.getIndex()<3757){
                        //INVOKE_BlockChain_Broadcasting("addExistedBlock(): Block#" + addedBlock.getIndex());
                        //+addedBlock.getHash()+"\n"+Block.calculateHash(addedBlock)+"\n"+blockchain.reasonNotValidNewBlock(addedBlock,null)
                    //}
                    if (addedBlock.getIndex() == 0) {
                        isSucceed = true;
                        INVOKE_ALL("INVOKE_BlockChain_Broadcasting", "addedBlock.getIndex() == 0, backblockchain succeeds.\n");
                        break;
                    }
                    //addedBlock=new BlockDAO(context).getPreviousblock(addedBlock);
                }
                else {
                    //if no block in both BlockDAO or BlockchainDAO just ASK,addedBlock=null
                    INVOKE_ALL("INVOKE_BlockChain_Broadcasting", "backblockchain.count() : " + backblockchain.count() + "\n");
                    long end_index = backblockchain.latestBlock().getIndex() - 1;
                    long start_index = end_index - interval_count;
                    if (start_index < 0) {
                        start_index = 0;
                    }
                    INVOKE_BlockChain_Broadcasting("Block#" + end_index + " is not in either BlockDAO or BlockchainDAO.");
                    AskMakerSendBlockfromIndex(start_index, end_index, boss_maker_id);
                    //isBreak = true;
                    break;
                }
            }
        }
        if (isSucceed) {
            hasConflict = false;
            /*INVOKE_BlockChain_Broadcasting("backblockchain.count(" + backblockchain.count() +
                    ") + blockchainDAO.count(" + blockchainDAO.getCount() +
                    ") = topBlock.getIndex(" + topblock.getIndex() + ") ?");*/

            INVOKE_BlockChain_Broadcasting("backblockchain built up successfully");

            for (Block b : bcD.getAll()) {
                long id=b.getId();
                if (b.getIndex() >= backblockchain.latestBlock().getIndex()) {
                    if (!blockDAO.isExisted(b.getHash())) {
                        blockDAO.insert(b);
                    }
                    bcD.delete(id);
                }
            }
            Collections.reverse(backblockchain.blocks);
            for (Block b : backblockchain.blocks) {
                blockDAO.deleteByHash(b.getHash());
                bcD.insert(b);
                //190909 addthis
                //blockchain.addBlock(b);
            }
            Invoke_BlockchainList();
        }
    }

    private void repackBlock(Block b){
        String message = b.getDatatype() + ":" + b.getData();
        new BlockThread(message, false, callback).start();
        listBlockmessage.add(new BlockMessage(message,false));
        INVOKE_BlockChain_Broadcasting(b.toShow() + "\nis repacked");
    }

    interface Callback {
        void callback_BlockThread(Block block,Boolean need_to_process);
        void callback_BlockchainCheckThread();
    }

    public Callback callback = new Callback() {
        @Override
        public void callback_BlockThread(Block block,Boolean need_to_process) {
            //INVOKE_BlockChain_Broadcasting("Block# #"+block.getIndex()+" need_to_process:"+need_to_process);
            if(need_to_process){
                unpackBlock(block);
            }
        }
        @Override
        public void callback_BlockchainCheckThread(){
            Async_clearRedundantBlocks clearRedundantBlocksTask=new Async_clearRedundantBlocks();
            clearRedundantBlocksTask.execute();
        }
    };

    private void request_checkData() {
        long Last_checkData_Time = SharedPreferencesHelper.getSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key27, 0L);
        long intervalTime_checkData = new Date().getTime() - Last_checkData_Time;
        secs_to_sync=Double.parseDouble(String.valueOf((IntervalTime_CHECKDATA-intervalTime_checkData)/1000));

        boolean Bypass=intervalTime_checkData  > IntervalTime_CHECKDATA;
        /*INVOKE_ALL("INVOKE_BlockChain_Broadcasting","DAO Synchronization: "+
                Utils.formatDoubleToString(Double.parseDouble(String.valueOf(intervalTime_checkData))/1000)+
                " / "+Utils.formatDoubleToString(Double.parseDouble(String.valueOf(IntervalTime_CHECKDATA/1000)))+" / "+Bypass+"\n");*/
        if (Bypass) {
            Async_checkData checkDataTask=new Async_checkData();
            checkDataTask.execute();
        }else{
            Async_request_getCB request_getCBTask=new Async_request_getCB();
            request_getCBTask.execute();
        }
    }

    private class Async_checkData extends AsyncTask<String, Void, Void> {
        //String type;
        @Override
        protected Void doInBackground(String... params) {
            checkData();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            isFinished_checkData=true;
            //INVOKE_ALL("INVOKE_BlockChain_Broadcasting","DAO Synchronization Completed.\n");
            SharedPreferencesHelper.putSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key27, new Date().getTime());
            Intent i = new Intent("INVOKE_HyperConnActivity_RenewTvValue");
            sendBroadcast(i);
            Async_request_getCB request_getCBTask=new Async_request_getCB();
            request_getCBTask.execute();
        }

        @Override
        protected void onPreExecute() {
            isFinished_checkData=false;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    private void checkData() {
        preConnectivityBenifitDAO pcbDAO = new preConnectivityBenifitDAO(context);
        ConnectivityBenifitDAO cbDAO = new ConnectivityBenifitDAO(context);
        MemberDAO memerDAO = new MemberDAO(context);
        List<preConnectivityBenifit> pcblist= new ArrayList<>();
        List<ConnectivityBenifit> cblist =new ArrayList<>();
        List<Member> memberlist=new ArrayList<>();
        //pcbDAO.clear();
        //cbDAO.clear();
        new HyperConnectivityDAO(context).clear();
        //new HyperConnectivityDAO(context).deleteAll();
        for (Block block : blockchainDAO.getAll()) {
            if (block.getDatatype().equals("CB_Trading")) {
                block.insertCB_TradingDAO(context,block);
            }
            else if (block.getDatatype().equals("CB_Order")) {
                block.insertCB_OrderDAO(context,block);
            }
            else if (block.getDatatype().equals("getPCB")) {
                preConnectivityBenifit pcb = new preConnectivityBenifit();
                pcb.setHcid(block.getData().split(" ")[0]);
                pcb.setAmount(Double.parseDouble(block.getData().split(" ")[1]));
                //for " fromHC"
                if (!block.getData().split(" ")[2].isEmpty()) {
                    pcb.setNote(block.getData().split(" ")[2]);
                } else {
                    pcb.setNote(block.getData().split("  ")[1]);
                }
                pcb.setBlockIndex(block.getIndex());
                pcb.setCreateTime(block.getTimestamp());
                pcblist.add(pcb);
                //pcbDAO.insert(pcb);
            }
            else if (block.getDatatype().equals("getCB")) {
                if(block.getData().split(" ")[3].equals("activity")){
                    preConnectivityBenifit pcb = new preConnectivityBenifit();
                    pcb.setHcid(block.getData().split(" ")[1]);
                    pcb.setAmount(-Double.parseDouble(block.getData().split(" ")[2]));
                    pcb.setNote(block.getData().split(" ")[3]);
                    pcb.setBlockIndex(block.getIndex());
                    pcb.setCreateTime(block.getTimestamp());
                    pcblist.add(pcb);
                }
                ConnectivityBenifit cb = new ConnectivityBenifit();
                cb.setSender(block.getData().split(" ")[0]);
                cb.setReceiver(block.getData().split(" ")[1]);
                cb.setAmount(Double.parseDouble(block.getData().split(" ")[2].replaceAll(",","")));
                cb.setNote(block.getData().split(" ")[3]);
                cb.setBlockIndex(block.getIndex());
                cb.setCreateTime(block.getTimestamp());
                cblist.add(cb);
                //cbDAO.insert(cb);
            }
            else if (block.getDatatype().equals("Registration")) {
                //unpack_Registration(block);
                Member member = new Member();
                member.setIntroducerid(block.getData().split(" ")[0]);
                member.setBlockIndex(block.getIndex());
                member.setHcid(block.getData().split(" ")[1]);
                member.setPublicKey(block.getData().split(" ")[2]);
                memberlist.add(member);
                //INVOKE_BlockChain_Broadcasting("Block# #"+block.getIndex()+" result:"+result);
                if (new MemberDAO(context).insert(member) == 0) {
                    INVOKE_ALL("INVOKE_MemberList", "");
                    //Administrator to give PCB
                    if (blockchainDAO.getByIndex(0).getMaker().equals(HCID)) {
                        String strBlock = member.getHcid() + " 25 registration";
                        String message = "getPCB:" + strBlock;
                        new BlockThread(message, false, callback).start();
                        //listBlockmessage.add(new BlockMessage(message,false));
                        try {
                            Thread.sleep(3000);
                        } catch (Exception e) {
                            //
                        }
                        strBlock = member.getIntroducerid() + " 5 introduction " + member.getHcid();
                        message = "getPCB:" + strBlock;
                        new BlockThread(message, false, callback).start();
                        //listBlockmessage.add(new BlockMessage(message,false));
                    }
                    if (member.getHcid().equals(HCID)) {
                        //INVOKE_showDialog_HyperConnActivity("Congratulations!", "Registration Succeeds !", "Have fun..");
                        isRegistered = true;
                        AskMakerSendBlockfromIndex(0, 500, member.getIntroducerid());
                    } /*else if (member.getIntroducerid().equals(HCID)) {
                        //INVOKE_showDialog_HyperConnActivity("Congratulations!", "You've introduced new member join HyperConn!", "Gain some PCB..");
                    }*/
                }
            }
            else if (block.getDatatype().equals("getHC")) {
                block.insertHCDAO(context,block);
            }
            else if (block.getDatatype().equals("RG_1")) {
                Member member = new Member();
                member.setIntroducerid(block.getData().split(" ")[0]);
                member.setBlockIndex(block.getIndex());
                member.setHcid(block.getData().split(" ")[1]);
                member.setPublicKey(block.getData().split(" ")[2]);
                //check if able to be added to memberlist;
                boolean isNewHcid=true;
                boolean isIntroducerCorrect=false;
                for(Member member1:memberlist){
                    if(member.getHcid().equals(member1.getHcid())){
                        isNewHcid=false;
                    }
                    if(member1.getIntroducerid().equals(member1.getHcid())){
                        isIntroducerCorrect=true;
                    }
                }
                if(isNewHcid && isIntroducerCorrect){
                    memberlist.add(member);
                //}
                //int result = new MemberDAO(context).insert(member);
                //INVOKE_BlockChain_Broadcasting("Block# #"+block.getIndex()+" result:"+result);
                //if (new MemberDAO(context).insert(member) == 0) {
                    INVOKE_ALL("INVOKE_MemberList", "");
                    preConnectivityBenifit pcb = new preConnectivityBenifit();
                    pcb.setHcid(member.getHcid());
                    pcb.setAmount(25d);
                    pcb.setNote("registration");
                    pcb.setBlockIndex(block.getIndex());
                    pcb.setCreateTime(block.getTimestamp());
                    pcblist.add(pcb);
                    //add HC that is converted by CR from 0.5 USD to introducer
                    double hc = 0.5 / new CB_TradingDAO(context).getCR();
                    block.setDatatype("getHC");
                    String data = member.getIntroducerid() + " " + Utils.formatDoubleToString(hc) + " intro_reg";
                    block.setData(data);
                    block.insertHCDAO(context, block);
                    //}
                    if (member.getHcid().equals(HCID)) {
                        //INVOKE_showDialog_HyperConnActivity("Congratulations!", "Registration Succeeds !", "Have fun..");
                        isRegistered = true;
                        AskMakerSendBlockfromIndex(0, 500, member.getIntroducerid());
                    } else if (member.getIntroducerid().equals(HCID)) {
                        //INVOKE_showDialog_HyperConnActivity("Congratulations!", "You've introduced new member join HyperConn!", "Gain some PCB..");
                    }
                }
            }
            else if (block.getDatatype().equals("Activation")) {
                insertRADAO(block);
            }
            else if (block.getDatatype().equals("getAD")){
                //unpack_getAD(block);
                //block.getData()="getAD:"+ ei_click.getPublisher_id() + " " + ei_click.getHash() + " " + ei_click.getCBPerClick() + " " +CBAmt;
                String data=block.getData();
                String publisher_id=data.split(" ")[0];
                String ad_hash=data.split(" ")[1];
                double cbperclick=Double.parseDouble(data.split(" ")[2]);
                double cb_amount=Double.parseDouble(data.split(" ")[3]);
                String cb_receiver=block.getMaker();
                String cb_sender="HyperConn";
                //
                preConnectivityBenifit pcb = new preConnectivityBenifit();
                pcb.setHcid(cb_receiver);
                pcb.setAmount(-cb_amount);
                pcb.setNote("activity");
                pcb.setBlockIndex(block.getIndex());
                pcb.setCreateTime(block.getTimestamp());
                pcblist.add(pcb);
                //
                ConnectivityBenifit cb = new ConnectivityBenifit();
                cb.setSender(cb_sender);
                cb.setReceiver(cb_receiver);
                cb.setAmount(cb_amount);
                cb.setNote("activity");
                cb.setBlockIndex(block.getIndex());
                cb.setCreateTime(block.getTimestamp());
                cblist.add(cb);
                //
                HyperConnectivity hc = new HyperConnectivity();
                hc.setHcid(cb_receiver);
                hc.setAmount(cbperclick*0.85);
                hc.setNote("getAD");
                hc.setBlockIndex(block.getIndex());
                hc.setCreateTime(block.getTimestamp());
                new HyperConnectivityDAO(context).insert(hc);
            }
        }
        pcbDAO.replace(pcblist);
        cbDAO.replace(cblist);
        memerDAO.replace(memberlist);
    }

    private int unpack_Registration(Block block) {
        //INVOKE_ALL("INVOKE_BlockChain_Broadcasting","unpack_Registration\n\n"+blockDAO.getByIndex(2817).toString()+"\n");
        String string="";
        //int result=9;
        //List<Member> memberlist=new ArrayList<>();
        Member member = new Member();
        member.setIntroducerid(block.getData().split(" ")[0]);
        member.setBlockIndex(block.getIndex());
        member.setHcid(block.getData().split(" ")[1]);
        member.setPublicKey(block.getData().split(" ")[2]);
        int result = new MemberDAO(context).insert(member);
        //INVOKE_BlockChain_Broadcasting("Block# #"+block.getIndex()+" result:"+result);
        if (result == 0) {
            INVOKE_ALL("INVOKE_MemberList", "");
            //Administrator to give PCB
            if (blockchainDAO.getByIndex(0).getMaker().equals(HCID)) {
                String strBlock = member.getHcid() + " 25 registration";
                String message = "getPCB:" + strBlock;
                new BlockThread(message, false, callback).start();
                //listBlockmessage.add(new BlockMessage(message,false));
                try {
                    Thread.sleep(3000);
                } catch (Exception e) {
                }
                strBlock = member.getIntroducerid() + " 5 introduction " + member.getHcid();
                message = "getPCB:" + strBlock;
                new BlockThread(message, false, callback).start();
                //listBlockmessage.add(new BlockMessage(message,false));
            }
            if (member.getHcid().equals(HCID)) {
                //INVOKE_showDialog_HyperConnActivity("Congratulations!", "Registration Succeeds !", "Have fun..");
                isRegistered = true;
                AskMakerSendBlockfromIndex(0, 500, member.getIntroducerid());
            } else if (member.getIntroducerid().equals(HCID)) {
                //INVOKE_showDialog_HyperConnActivity("Congratulations!", "You've introduced new member join HyperConn!", "Gain some PCB..");
            }
        }
        return result;
    }

    private class Async_request_getCB extends AsyncTask<String, Void, String> {
        //String type;
        @Override
        protected String doInBackground(String... params) {
            //request_getCB();
            return request_getCB();
        }

        @Override
        protected void onPostExecute(String result) {
            content_pcb=result;
            //INVOKE_BlockChain_Broadcasting("Async_request_getCB finished!");
            if(Double.parseDouble(result.split("%")[0].split(" ")[4])>=100){
                startWindowService();
                //int count=new Envelope_Info_recordDAO(context).getCount();
                if(new Envelope_Info_recordDAO(context).getAd_NotConfirmed(HCID)==null){
                    Inquiry_Ad(2);
                }else{
                    //INVOKE_BlockChain_Broadcasting("Envelope_InfoRecord: "+new Envelope_Info_recordDAO(context).getAd_NotConfirmed(HCID).toString());
                }
                Allow_Inquiry_Ad=true;
            }else if(Allow_Inquiry_Ad){
                Inquiry_Ad(1);
            }
            isCheckBlockchainFinished=true;
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    private void Inquiry_Ad(int i){
        ArrayList adslist=new Envelope_InfoDAO(context).getAdsOnLine(HCID);
        String mess="";
        if(adslist.size()>0){
            mess=adslist.toString();
        }
        //INVOKE_BlockChain_Broadcasting("Broadcasting Inquiry_"+i+" for Ad: "+mess);
        if(isConnect) {
            Allow_Inquiry_Ad=false;
            try {
                String name = "Inquiry_Ad_"+i;
                mHub.invoke(HUB_chat_public_Send, HCID, name, mess, "").get();
            } catch (Exception e) {
                //e.printStackTrace();
            }
        }
    }

    private void renewAD_Status(Envelope_Info ei){
        String name="renewAD_Status";
        String mess=ei.getHash();
        //INVOKE_BlockChain_Broadcasting("renewAD_Status: "+mess);
        if(isConnect) {
            try {
                mHub.invoke(HUB_chat_public_Send, HCID, name, mess, "").get();
            } catch (Exception e) {
                //e.printStackTrace();
            }
        }
    }

    private String request_getCB() {
        //String result="";
        long Last_getCB_Time = SharedPreferencesHelper.getSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key24, 0l);
        long intervalTime_getCB = new Date().getTime() - Last_getCB_Time;
        pcb_amount=pcbDAO.getBalanceByHCID(HCID);
        /*INVOKE_ALL("INVOKE_BlockChain_Broadcasting","SCORE_NEED_TO_GETCB: "+
                SCORE_COUNT_BLOCKS+" / "+
                Utils.formatDoubleToString(Double.parseDouble(String.valueOf(intervalTime_getCB))/1000)+
                " / "+Utils.formatDoubleToString(Double.parseDouble(String.valueOf(SCORE_NEED_TO_GETCB/1000)))+
                " / "+Utils.formatDoubleToString(pcb_amount)+"\n");*/
        long percentage=(intervalTime_getCB+SCORE_COUNT_BLOCKS*1000)*100/SCORE_NEED_TO_GETCB;
        if(percentage>100){
            percentage=100l;
        }
        String strPerc=SCORE_COUNT_BLOCKS+" / "+Utils.formatDoubleToString(Double.parseDouble(String.valueOf(intervalTime_getCB))/1000);
        return strPerc+ " / " + percentage +"% : "+Utils.formatDoubleToString(pcb_amount);
    }

    private void addListBlockThread_Request(String message){
        CR=new CB_TradingDAO(context).getCR();
        new BlockThread(message, false, callback).start();
        //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
        if(message.split(":")[0].equals("CB_Trading")){
            String data = message.split(":")[1];
            //data = "HyperConn " + cbo.getHash() + " 360 RMB "+strCR+" 31 "+strCB_amount ;
            String strCB_amount=data.split(" ")[6];
            String order_hash=data.split(" ")[1];
            CB_Order cbo=new CB_OrderDAO(context).getByHash(order_hash);
            //INVOKE_BlockChain_Broadcasting("new CB_OrderDAO(context).getBalance(order_hash): "+new CB_OrderDAO(context).getBalance(order_hash));
            if(new CB_OrderDAO(context).getBalance(order_hash)==0D){
                String datatype1 = "CB_Order";
                String note="done";
                String data1 = cbo.getIsbuy() + " " + cbo.getHash() + " " + cbo.getHcid() + " 30 " + cbo.getCashflow_1() + " " + cbo.getAmount() + " " + cbo.getCreateTime() + " " + cbo.getCurrency() + " " + note;
                block = new Block();
                block.setDatatype(datatype1);
                block.setData(data1);
                block.insertCB_OrderDAO(context,block);
                message=datatype1+":"+data1;
                try {Thread.sleep(500);} catch (InterruptedException e) {}
                new BlockThread(message,false,callback).start();
                listBlockmessage.add(new BlockMessage(message,false));
                //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
            }
            if(data.split(" ")[0].equals("HyperConn")){
                String applicant=cbo.getHcid();
                String note="CB_release";
                String datatype2="getCB";
                String data2="HyperConn" + " " + applicant + " " + strCB_amount + " " + note;
                block = new Block();
                block.setDatatype(datatype2);
                block.setData(data2);
                //insert_CBDAO(block);
                message=datatype2+":"+data2;
                try {Thread.sleep(500);} catch (InterruptedException e) {}
                new BlockThread(message,false,callback).start();
                listBlockmessage.add(new BlockMessage(message,false));
                //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
            }
        }
        //if cbo.setIsBuy(false),means it's a sell CB
        else if(message.split(":")[0].equals("CB_Order")){
            String data = message.split(":")[1];
            //data = cbo.getIsbuy() + " " + cbo.getHash() + " " + cbo.getHcid() + " 26 " +  "n/a " + cbo.getCB_Amount() + " " + cbo.getCreateTime() + " " + cbo.getCurrency() + " " + note;
            if(!Boolean.parseBoolean(data.split(" ")[0])){
                //meand that it's for selling
                String applicant=data.split(" ")[2];
                String amount=data.split(" ")[5];
                String note="sellCB";
                String datatype="getCB";
                data=applicant + " " +"HyperConn"+" "+amount+" "+note;
                message=datatype+":"+data;
                try {Thread.sleep(500);} catch (InterruptedException e) {}
                new BlockThread(message,false,callback).start();
                //listBlockmessage.add(new BlockMessage(message,false));
                //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
            }
        }
        else if(message.split(":")[0].equals("Activation")){
            String data = message.split(":")[1];
            //data = ra.getHash() + " " + ra.getApplicant() + " 30 " + ra.getCashflow_1() + " " + ra.getAmount() + " RMB " + ra.getCreateTime() + " " + note;
            if(data.split(" ")[2].equals("30")){
                String applicant=data.split(" ")[1];
                String datatype="getHC";
                String amount=Utils.formatDoubleToString(Double.parseDouble(getResources().getString(R.string.activation_fee))/CR);
                String note="self_activation";
                data=applicant+" "+amount+" "+note;
                message=datatype+":"+data;
                try {Thread.sleep(500);} catch (InterruptedException e) {}
                new BlockThread(message,false,callback).start();
                //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
                //hcid,amount,note,
                if(new MemberDAO(context).get(applicant)!=null){
                    amount=Utils.formatDoubleToString(Double.parseDouble(getResources().getString(R.string.activation_fee))*0.05/CR);
                    note="intro_activation";
                    data=new MemberDAO(context).get(applicant).getIntroducerid()+" "+amount+" "+note;
                    message=datatype+":"+data;
                    try {Thread.sleep(500);} catch (InterruptedException e) {}
                    new BlockThread(message,false,callback).start();
                    //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
                }
            }
        }
        else if(message.split(":")[0].equals("getHC")){
            String data = message.split(":")[1];
            //data= HCID +" "+amount+" fromCB";
            if(data.split(" ")[2].equals("fromCB")){
                String applicant=data.split(" ")[0];
                double hc_amount=Double.parseDouble(data.split(" ")[1]);
                double cb_amount=-(hc_amount/0.85);
                //applicant -1000 CB
                String strCB_amount=String.format( "%.2f", cb_amount );
                String note="toHC";
                String datatype="getCB";
                data="HyperConn" + " " +applicant+" "+strCB_amount+" "+note;
                Block block=new Block();
                block.setDatatype(datatype);
                block.setData(data);
                block.setTimestamp(new Date().getTime());
                insert_CBDAO(block);
                message=datatype+":"+data;
                try {Thread.sleep(500);} catch (InterruptedException e) {
                    //
                }
                new BlockThread(message,false,callback).start();
                //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
                //introducer +42.5.0 HC
                if(new MemberDAO(context).getIntroducerHCID(applicant)!=null){
                    String introducer = new MemberDAO(context).getIntroducerHCID(applicant);
                    String strhcAmount_intro = Utils.formatDoubleToString(hc_amount * 0.05);
                    note = "intro_fromCB";
                    datatype = "getHC";
                    data = introducer + " "+strhcAmount_intro+" " + note;
                    message = datatype + ":" + data;
                    try {Thread.sleep(500);} catch (InterruptedException e) {
                        //
                    }
                    new BlockThread(message, false, callback).start();
                    //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
                }
            }
        }
    }

    private void makeBlock_Calibration(String message){
        new BlockThread(message, false, callback).start();
        //INVOKE_BlockChain_Broadcasting("blockmessage: "+message);
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        mSignalRFuture.cancel();
        mSignalRFuture1.cancel();
        super.onDestroy();
        if (mWindowView1  != null) {
            //移除悬浮窗口
            //Log.i(TAG, "removeView");
            mWindowManager.removeView(mWindowView1);
        }
        //if(mWindowView1.getWindowToken() != null){
        if (mWindowView2  != null) {
            //移除悬浮窗口
            //Log.i(TAG, "removeView");
            mWindowManager.removeView(mWindowView2);
        }
        if (mWindowView3  != null) {
            //移除悬浮窗口
            //Log.i(TAG, "removeView");
            mWindowManager.removeView(mWindowView3);
        }
        if (networkChangeReceiver != null) {
            //注销广播
            unregisterReceiver(networkChangeReceiver);
        }
    }

    private void applyBlock(String datatype,String data){
        applyBlock ab=new applyBlock();
        ab.setApplicant(HCID);
        //ab.setCreateTime(new Date().getTime());
        ab.setData(data);
        ab.setDatatype(datatype);
        ab.setHash(ab.calculateHash(ab));
        new applyBlockDAO(context).insert(ab);
    }

    public boolean isConnect() {
        if(isConnected()){
            if(!isConnect){
                setHubConnect();
            }
        }else{
            if(isConnect){
                clearHub();
            }
        }
        isConnect = isConnected();
        setConnect(isConnect);
        return isConnect;
    }

    private void setConnect(Boolean isconnect){
        Intent i = new Intent("INVOKE_to_HyperConn");
        if(isconnect){
            isConnect=true;
            i.putExtra("connect_status", "connected");
        }else{
            isConnect=false;
            i.putExtra("connect_status", "disconnected");
        }
        sendBroadcast(i);
    }

    private void initWindowParams() {
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        //mWindowManager = (WindowManager) getApplication().getSystemService(getApplication().WINDOW_SERVICE);
        wmParams = new WindowManager.LayoutParams();
        // 更多type：https://developer.android.com/reference/android/view/WindowManager.LayoutParams.html#TYPE_PHONE
        if (Build.VERSION.SDK_INT < 26) {
            wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        //wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        wmParams.format = PixelFormat.TRANSLUCENT;
        // 更多falgs:https://developer.android.com/reference/android/view/WindowManager.LayoutParams.html#FLAG_NOT_FOCUSABLE
        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
    }

    private void initView() {
        //switch (view){
        //case 1:
        mWindowView1 = LayoutInflater.from(getApplication()).inflate(R.layout.layout_window, null);
        iv_icon = (ImageView) mWindowView1.findViewById(R.id.iv_icon);
        iv_icon.startAnimation(myAnim);
        //break;
        //case 2:
        mWindowView2 = LayoutInflater.from(getApplication()).inflate(R.layout.cb_envelope_form, null);
        iv_envelope2=(ImageView) mWindowView2.findViewById(R.id.iv_envelope);
        tv_CB2 = (TextView) mWindowView2.findViewById(R.id.tv_CB);
        tv_pcb2 = (TextView) mWindowView2.findViewById(R.id.tv_pcb);
        tv_cb2 = (TextView) mWindowView2.findViewById(R.id.tv_cb);

        TextView tv_greeting = (TextView) mWindowView2.findViewById(R.id.tv_greeting);
        tv_greeting.setText("Get CB!");
        iv_envelope2.startAnimation(myAnim);

        mWindowView3 = LayoutInflater.from(getApplication()).inflate(R.layout.envelope_info_type1, null);
        rl_envelope_info=(RelativeLayout) mWindowView3.findViewById(R.id.rl_envelope_info);
        iv_ad=(ImageView) mWindowView3.findViewById(R.id.iv_ad);
        tv_subject=(TextView) mWindowView3.findViewById(R.id.tv_subject);
        tv_content=(TextView) mWindowView3.findViewById(R.id.tv_content);

        //iv_envelope3=(ImageView) mWindowView3.findViewById(R.id.iv_envelope);
        tv_CB3 =  mWindowView3.findViewById(R.id.tv_CB);
        tv_pcb3 = mWindowView3.findViewById(R.id.tv_pcb);
        tv_cb3 = mWindowView3.findViewById(R.id.tv_cb);
        iv_ad.startAnimation(myAnim);
        //mAdView = mWindowView3.findViewById(R.id.adView);
        //AdRequest adRequest = new AdRequest.Builder().build();
        //mAdView.loadAd(adRequest);
    }

    private String getCB_amount(){
        double sum=pcb_amount;
        double cb=new ConnectivityBenifitDAO(context).getBalanceByHCID(HCID);
        double cb_rate= Double.parseDouble(getResources().getString(R.string.CB_Rate));
        if(Utils.multiply(sum,cb_rate)>0.02){
            return Utils.formatDoubleToString(sum)+":"
                    +Utils.formatDoubleToString(Utils.multiply(sum,cb_rate))+":"
                    +Utils.formatDoubleToString(cb);
        }else{
            return Utils.formatDoubleToString(sum)+":0.01"+":"
                    +Utils.formatDoubleToString(cb);
        }
    }

    private void initClick() {
        iv_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    SharedPreferencesHelper.putSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key24, new Date().getTime());
                    SCORE_COUNT_BLOCKS=0;
                    mWindowManager.removeView(mWindowView1);
                    wmParams.gravity = Gravity.CENTER;
                    wmParams.x=0;
                    wmParams.y=0;
                    if(new Envelope_Info_recordDAO(context).getAd_NotConfirmed(HCID)!=null){
                        addWindowView2Window(3);
                    }else{
                        addWindowView2Window(2);
                    }

            }
        });
        iv_envelope2.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                String blockmessage="getCB:HyperConn" + " " + HCID + " " + CBAmt + " activity";
                addListBlockThread_Request(blockmessage);
                mWindowManager.removeView(mWindowView2);
                content_pcb="0 / 0.0 / 0% : "+Utils.formatDoubleToString(pcb_amount);
                callContent_Title(content_pcb);
            }
        });
        rl_envelope_info.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String blockmessage="getCB:HyperConn" + " " + HCID + " " + CBAmt + " activity";
                String blockmessage="getAD:"+ ei_click.getPublisher_id() + " " + ei_click.getHash() + " " + ei_click.getCBPerClick() + " " +CBAmt;
                addListBlockThread_Request(blockmessage);
                mWindowManager.removeView(mWindowView3);
                content_pcb="0 / 0.0 / 0% : "+Utils.formatDoubleToString(pcb_amount);
                callContent_Title(content_pcb);
                //new Envelope_InfoDAO(context).addCount(ei_click.getHash());
                INVOKE_ALL("INVOKE_Envelope_InfoList","");
                setEnvelope_info_record_confirmed(eir_click);
            }
        });
    }

    private void setEnvelope_info_record_confirmed(Envelope_Info_record eir) {
        //INVOKE_BlockChain_Broadcasting("envelope_Info_record id:\n"+eir.getId()+" / "+eir.getIsConfirmed());
        String mType = "feedbackADpublisher_addCount";
        String sender = HCID;
        eir.setIsConfirmed(true);
        //INVOKE_BlockChain_Broadcasting("envelope_Info_record id:\n"+eir.getId()+" / "+eir.getIsConfirmed()+" / "+ new Envelope_Info_recordDAO(context).setConfirmed(eir).getIsConfirmed());
        new Envelope_Info_recordDAO(context).setConfirmed(eir.getRecord_hash());
        /*Boolean isupdate=new Envelope_Info_recordDAO(context).update(eir);
        if(new Envelope_Info_recordDAO(context).getByRecord_Hash(eir.getRecord_hash().trim())!=null){
            isupdate=true;
        }*/
        INVOKE_ALL("INVOKE_Envelope_InfoRecordList", "");
        //INVOKE_BlockChain_Broadcasting("Sending Ad. to:\n"+hcid+"\n"+envelope_info.getHash()+"\nisUpdate:"+isUpdate);
        //INVOKE_BlockChain_Broadcasting("Sending Ad. to:\n"+eir.getId()+" / "+eir.getRecord_hash()+" / "+isupdate.toString());
        if(isConnect){
            ArrayList<String> L=new ArrayList();
            L.add(eir.getPublisher_id());
            String message=eir.getAd_hash()+":"+eir.getRecord_hash();
            try {
                mHub.invoke(HUB_Hidden_Signal_Send, L, sender, mType, message , "").get();
            } catch (InterruptedException e) {
                //e.printStackTrace();
            } catch (ExecutionException e) {
                //e.printStackTrace();
            }
        }
    }

    private void startWindowService(){
        if(sharedPrefs.getBoolean("enable_sound", false)){
            ringtone();
        }
        if(sharedPrefs.getBoolean("enable_vibrate", false)){
            vibrate();
        }
        wmParams.gravity = Gravity.LEFT | Gravity.TOP;
        wmParams.x = 25;
        wmParams.y = 25;
        addWindowView2Window(1);
    }

    private void addWindowView2Window(int view_no) {
        switch (view_no) {
            case 1:
                try {
                    mWindowManager.addView(mWindowView1, wmParams);
                } catch (Exception e) {
                }

                break;
            case 2:
                CBAmt = getCB_amount().split(":")[1];
                String strCB2=CBAmt + " " + "CB";
                tv_CB2.setText(strCB2);
                final String pcb =getCB_amount().split(":")[0];
                final String cb =getCB_amount().split(":")[2];
                tv_pcb2.setText(pcb);
                tv_cb2.setText(cb);
                try {
                    mWindowManager.addView(mWindowView2, wmParams);
                } catch (Exception e) {
                    //
                }
                break;
            case 3:
                CBAmt = getCB_amount().split(":")[1];
                eir_click=new Envelope_Info_recordDAO(context).getAd_NotConfirmed(HCID);
                ei_click=new Envelope_InfoDAO(context).getByHash(eir_click.getAd_hash());
                String strPCB3=CBAmt +" CB / "+Utils.formatDoubleToString(Utils.multiply(eir_click.getCBPerClick(),0.85))+" HC";
                tv_pcb3.setText(strPCB3);
                tv_subject.setText(ei_click.getSubject());
                tv_content.setText(ei_click.getContent());
                Bitmap bitmap = BitmapFactory.decodeFile(ei_click.getImage_path());
                iv_ad.setImageBitmap(ServiceUtil.getRoundedCornerBitmap(bitmap));
                try {
                    mWindowManager.addView(mWindowView3, wmParams);
                } catch (Exception e) {
                }
                //
                break;
        }
    }

    private class Async_getBlock extends AsyncTask<Long, Void, Integer> {
        @Override
        protected Integer doInBackground(Long... params) {
            return getBlock();
        }

        @Override
        protected void onPostExecute(Integer result) {
            isSyncBlockchainFinished=true;
            INVOKE_BlockChain_Broadcasting("Blockchain Download completed.");
        }

        @Override
        protected void onPreExecute() {
            isSyncBlockchainFinished=false;
            INVOKE_BlockChain_Broadcasting("Blockchain Download starts.");
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private int getBlock() {
        //Block block=new Block();
        int block_count=0;
        String METHOD_NAME = "getBlock";
        String NAMESPACE = "http://152.101.178.115:8081/";
        String SOAP_ACTION = NAMESPACE + METHOD_NAME;
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        //String string="";
         //try {
             String string= HCID + ";" + SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key102, "");

        //}catch (Exception e){}
        request.addProperty("HCID",string);
        RSAEncryptionJava8 RC=new RSAEncryptionJava8();
        String text=HCID;



        String strDS= RC.getDigitalSignature(text,HCID).replaceAll("\\r","c##13").replaceAll("\\n","c##10");
        request.addProperty("digitalSignature",strDS );
        request.addProperty("block_index",String.valueOf(new BlockchainDAO(context).getCount()));
        //request.addProperty("block_index",String.valueOf(index));
        String URL_WS = NAMESPACE + "webService.asmx";
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        //Set output SOAP object
        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        //Create HTTP call object
        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL_WS);

        SoapPrimitive soapPrimitive = null;
        try {
            androidHttpTransport.call(SOAP_ACTION, envelope);
            soapPrimitive = (SoapPrimitive) envelope.getResponse();
        } catch (Exception e) {
            //errMsg+=e.getMessage()+"\n";
        }
        try {
            String tmp = soapPrimitive!=null? "": String.valueOf(soapPrimitive);
            //一開始從網路接收通常為String型態,tmp為接收到的String,為避免串流內有其他資料只需抓取{}間的內容
            tmp = tmp.substring(tmp.indexOf("["), tmp.lastIndexOf("]") + 1);
            //將資料丟進JSONObject
            //接下來選擇型態使用get並填入key取值
            JSONArray jsonArray = new JSONArray(tmp);
            for (int i = 0; i < jsonArray.length(); i++) {
                Block b = new Block();
                JSONObject blockObj = jsonArray.getJSONObject(i);
                b.setIndex(blockObj.getLong("block_index"));
                b.setMaker(blockObj.getString("maker_id"));
                b.setTimestamp(blockObj.getLong("timestamp"));
                b.setNonce(blockObj.getInt("nonce"));
                b.setPreviousHash(blockObj.getString("prevous_hash"));
                b.setHash(blockObj.getString("hash"));
                b.setDatatype(blockObj.getString("data_type"));
                b.setData(blockObj.getString("data").replaceAll("c##13",""+(char)(13)).replaceAll("c##10",""+(char)(10)));

                if (!new BlockDAO(context).isExisted(b.getHash())) {
                    new BlockDAO(context).insert(b);
                    block_count++;
                }
                /*if(block_count>1000*n){
                    Invoke_BlockList();
                    n++;
                }*/
            }
        } catch (Exception e) {
            //errMsg+=e.getMessage()+"\n";
        }
        return block_count;
    }

    public void ringtone(){
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
            r.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  void vibrate(){
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if(vibrator!=null){
            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
                }catch (Exception e){
                    //
                }
            } else {
                try {
                    vibrator.vibrate(200);
                }catch (Exception e){
                    //
                }
            }
        }
    }

    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm != null ? cm.getActiveNetworkInfo() : null;
        //should check null because in airplane mode it will be null
        return (networkInfo != null && networkInfo.isConnected());
    }
}
