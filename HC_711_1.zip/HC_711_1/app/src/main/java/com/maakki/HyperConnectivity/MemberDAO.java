package com.maakki.HyperConnectivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// 資料功能類別
public class MemberDAO {
    // 表格名稱
    public static final String TABLE_NAME = "Member";

    // 編號表格欄位名稱，固定不變
    public static final String KEY_ID = "_id";
    Context context;

    // 其它表格欄位名稱
    public static final String HCid_Column = "HCid";
    public static final String Introducerid_COLUMN = "Introducerid";
    public static final String BlockIndex_COLUMN = "block_index";
    public static final String PublicKey_COLUMN = "PublicKey";


    // 提醒日期時間
    public static final String ALARMDATETIME_COLUMN = "alarmdatetime";

    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    HCid_Column + " TEXT NOT NULL, " +
                    Introducerid_COLUMN + " TEXT NOT NULL, " +
                    BlockIndex_COLUMN +" INTEGER NOT NULL, " +
                    PublicKey_COLUMN +" TEXT NOT NULL) ";

    // 資料庫物件
    private SQLiteDatabase db;

    // 建構子，一般的應用都不需要修改
    public MemberDAO(Context context) {
        this.context=context;
        db = HyperConnDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    public void replace(List<Member> memberlist) {
        clear();
        //String string="";
        //int result;
        for(Member member:memberlist){
            insert(member);
/*            result=insert(member);
            if(result>0){
                string += result+"\n";
            }*/
        }
        //return string;
    }

    private boolean isIntroducerCorrect(Member member){
        List<Member> memberlist=getAll();
        for(Member m:memberlist){
            if(  m.getHcid().equals(member.getIntroducerid())
                    // Block.index of introducer should be smaller than Block.index of member
               & m.getBlockIndex() < member.getBlockIndex()){
                return true;
            }
        }
        return false;
    }
    public boolean isRegistered(String hcid){
        //List<Member> memberlist=getAll();
        for(Member m:getAll()){
            if(m.getHcid().equals(hcid)){
                return true;
            }
        }
        return false;
    }
    public boolean isSameHCID(Member member){
        List<Member> memberlist=getAll();
        for(Member m:memberlist){
            if(m.getHcid().equals(member.getHcid())){
                return true;
            }
        }
        return false;
    }
    public int insert(Member member) {
        // 建立準備新增資料的ContentValues物件
        String first_block_data="MDwwDQYJKoZIhvcNAQEBBQADKwAwKAIhAMnnljmwmPXdMRzwx/CVUrTDLKCpsS4gep6nABNpRpdrAgMBAAE=";
        /*if (isSameHCID(member)) {
            update(member);
            //double registering
            return 2;
        }*/
        if(!member.getIntroducerid().equals("HyperConn")||
                !member.getHcid().equals("1A26AEBAF026CA9936C86B2987EF92E5")||
                !member.getPublicKey().equals(first_block_data))
        {
            /*BlockchainDAO bcDAO=new BlockchainDAO(context);
            BlockDAO bDAO=new BlockDAO(context);
            if (!member.getHcid().equals(bcDAO.getByIndex(0).getMaker())&
                    !member.getHcid().equals(bDAO.getByIndex(0).getMaker())) {
                if (!isIntroducerCorrect(member)) {
                    //invalid introducer
                    return 1;
                }
            }*/
            if (!isIntroducerCorrect(member)) {
                //invalid introducer
                return 1;
            }
        }
        if(!update(member)){
            ContentValues cv = new ContentValues();
            // 加入ContentValues物件包裝的新增資料
            // 第一個參數是欄位名稱， 第二個參數是欄位的資料
            cv.put(HCid_Column, member.getHcid());
            cv.put(Introducerid_COLUMN, member.getIntroducerid());
            cv.put(BlockIndex_COLUMN, member.getBlockIndex());
            cv.put(PublicKey_COLUMN, member.getPublicKey());
            long id = db.insert(TABLE_NAME, null, cv);
            // 設定編號
            member.setId(id);
            return 0;
        }
        return 2;
    }

    // 新增參數指定的物件
    //0:failed 1:succeed 2:update
    public boolean isAbleToInsert(Member member) {
        // 建立準備新增資料的ContentValues物件
        String first_block_data="MDwwDQYJKoZIhvcNAQEBBQADKwAwKAIhAMnnljmwmPXdMRzwx/CVUrTDLKCpsS4gep6nABNpRpdrAgMBAAE=";

        if(!member.getIntroducerid().equals("HyperConn")||
                !member.getHcid().equals("1A26AEBAF026CA9936C86B2987EF92E5")||
                !member.getPublicKey().equals(first_block_data))
        {
            if (!isIntroducerCorrect(member)) {
                //invalid introducer
                return false;
            }
        }
        if(!update(member)){
            ContentValues cv = new ContentValues();
            // 加入ContentValues物件包裝的新增資料
            // 第一個參數是欄位名稱， 第二個參數是欄位的資料
            cv.put(HCid_Column, member.getHcid());
            cv.put(Introducerid_COLUMN, member.getIntroducerid());
            cv.put(BlockIndex_COLUMN, member.getBlockIndex());
            cv.put(PublicKey_COLUMN, member.getPublicKey());
            long id = db.insert(TABLE_NAME, null, cv);
            // 設定編號
            member.setId(id);
            return true;
        }
        return false;
    }

    // 修改參數指定的物件
    public boolean update(Member member) {
        // 建立準備修改資料的ContentValues物件
        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(HCid_Column, member.getHcid());
        //Introducer is not editable
        //cv.put(Introducerid_COLUMN, member.getIntroducerid());
        cv.put(BlockIndex_COLUMN, member.getBlockIndex());
        cv.put(PublicKey_COLUMN, member.getPublicKey());

        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = HCid_Column + "='" + member.getHcid()+"'";

        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_ID + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    // 刪除指定区块给予的資料
    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }
    public void clear() {
        for(Member mem:getAll()){
            delete(mem.getId());
        }
    }
    // 讀取所有联络人資料
    public List<Member> getAll() {
        List<Member> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }
    public int getWeight(String hcid){
        int result=0;
        for(Member m:getAll()){
            if(m.getIntroducerid().equals(hcid)){
                if(new RequestActivationDAO(context).isActivated(m.getHcid())){
                    result+=10;
                }else{
                    result+=1;
                }
            }
        }
        return result;
    }

    // 取得指定編號的資料物件
    public Member get(String hcid) {
        // 準備回傳結果用的物件
        Member member = null;
        // 使用編號為查詢條件
        String querystring = HCid_Column + "='" + hcid+"'";
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            member = getRecord(result);
        }
        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return member;
    }

    // 取得指定編號的資料物件
    public String getIntroducerHCID(String hcid) {
        // 準備回傳結果用的物件
        String result = "";
        // 使用編號為查詢條件
        String querystring = HCid_Column + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            result = getRecord(cursor).getIntroducerid();
        }
        // 關閉Cursor物件
        cursor.close();
        // 回傳結果
        return result;
    }

    public List<Member> getExtensionList(String hcid){
        List<Member>  result=new ArrayList<>();
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }
        cursor.close();
        return result;
    }

    public int getExtensioncount(String hcid){
        int result=0;
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            result+=1;
        }
        cursor.close();
        return result;
    }

    public int getExtensioncountIn24hr(String hcid){
        int result=0;
        long interval= 24*60*60*1000;
        long time= new Date().getTime();
        long intervalTime=time-interval;
        List<Member>  list = new ArrayList<>();
        String querystring = Introducerid_COLUMN + "='" + hcid +"'";
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);
        // 如果有查詢結果
        while (cursor.moveToNext()) {
            list.add(getRecord(cursor));
        }
        cursor.close();
        for(Member m:list){
            if (new BlockchainDAO(context).getByIndex(m.getBlockIndex()).getTimestamp()>intervalTime){
                result++;
            }
        }
        return result;
    }

    /*public Double getCalculatedPCB_registration_introduction(String hcid){
        Double result=0d;
        result=25d+getExtensioncount(hcid)*5;
        return result;
    }*/

    public Double getintro_PCB(String hcid){
        Double result=0d;
        result+=getExtensioncount(hcid)*5;
        return result;
    }

    public Double getHCQ_sum (String hcid) {
        Double result=0d;
        //String result="";
        List<Member> introlist = new ArrayList<>();
        // 準備回傳結果用的物件
        //Member member = null;
        // 使用編號為查詢條件
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            introlist.add(getRecord(cursor));
        }
        // 關閉Cursor物件
        cursor.close();
        for(Member m:introlist){
            result+= new HyperConnectivityDAO(context).getHCSum_fromAll(m.getHcid())/2;
        }
        // 回傳結果
        return result;
    }

    public String getStrHCQ_sum (String hcid) {
        String result="";
        //String result="";
        List<Member> introlist = new ArrayList<>();
        // 準備回傳結果用的物件
        //Member member = null;
        // 使用編號為查詢條件
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            introlist.add(getRecord(cursor));
        }
        // 關閉Cursor物件
        cursor.close();
        for(Member m:introlist){
            result+= m.getHcid()+" / "+new HyperConnectivityDAO(context).getStrHCSum_fromAll(m.getHcid())+"\n";
        }
        // 回傳結果
        return result;
    }

    public Double getHCQ_balance (String hcid) {
        //Double result=0d;
        //String result="";
        /*List<Member> introlist = new ArrayList<>();
        // 準備回傳結果用的物件
        Member member = null;
        // 使用編號為查詢條件
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            introlist.add(getRecord(cursor));
        }
        // 關閉Cursor物件
        cursor.close();
        for(Member m:introlist){
            result+= ((new RequestActivationDAO(context).getActivationFeeUSD(m.getHcid()) +
                    new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(m.getHcid()))*0.5)/new CB_TradingDAO(context).getCR();
        }*/
        // 回傳結果
        Double result=getHCQ_sum(hcid)-new HyperConnectivityDAO(context).getHCSumfromCB(hcid);
        return result;
    }

    public Double getCBQ_sum (String hcid) {
        Double result=0d;
        //Double result=100d;
        //String result="";
        List<Member> introlist = new ArrayList<>();
        // 準備回傳結果用的物件
        Member member = null;
        // 使用編號為查詢條件
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            introlist.add(getRecord(cursor));
        }
        // 關閉Cursor物件
        cursor.close();
        result += 6*introlist.size();
        for(Member m:introlist){
            result+= (new RequestActivationDAO(context).getActivationFeeUSD(m.getHcid()) +
                    new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(m.getHcid()))*0.5;
        }
        // 回傳結果
        //return 50d;
        return result;
    }

    public Double getCBQ_balance (String hcid) {
        Double result=0d;
        //String result="";
        List<Member> introlist = new ArrayList<>();
        // 準備回傳結果用的物件
        Member member = null;
        // 使用編號為查詢條件
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            introlist.add(getRecord(cursor));
        }
        // 關閉Cursor物件
        cursor.close();
        for(Member m:introlist){
            result+= (new RequestActivationDAO(context).getActivationFeeUSD(m.getHcid()) +
                    new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(m.getHcid()))*0.5;
        }
        // 回傳結果
        //return 50d;
        return result-new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(hcid);
    }

    /*public String strGetCBQ_balance (String hcid) {
        String result="";
        //String result="";
        List<Member> introlist = new ArrayList<>();
        // 準備回傳結果用的物件
        Member member = null;
        // 使用編號為查詢條件
        String querystring = Introducerid_COLUMN + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            introlist.add(getRecord(cursor));
        }
        // 關閉Cursor物件
        cursor.close();
        for(Member m:introlist){
            result+= (new RequestActivationDAO(context).getActivationFeeUSD(m.getHcid()) +
                    new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(m.getHcid()))*0.5
            ;
        }
        // 回傳結果
        //return result+" / "+new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(hcid);
        return result+" / "+new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(hcid);

    }*/
    // 把Cursor目前的資料包裝為物件
    public Member getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        Member result = new Member();
        result.setId(cursor.getLong(0));
        result.setHcid(cursor.getString(1));
        result.setIntroducerid(cursor.getString(2));
        result.setBlockIndex(cursor.getInt(3));
        result.setPublicKey(cursor.getString(4));
        //提醒日期時間
        //result.setAlarmDatetime(cursor.getLong(9));

        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        // 關閉 Cursor物件
        cursor.close();
        return result;
    }

}