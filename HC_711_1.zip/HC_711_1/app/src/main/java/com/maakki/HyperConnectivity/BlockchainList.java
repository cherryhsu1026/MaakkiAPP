package com.maakki.HyperConnectivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import org.json.JSONArray;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by ryan on 2017/7/17.
 */

public class BlockchainList extends AppCompatActivity {
    //private final String NAMESPACE = "http://www.maakki.com/";
    //private final String URL = "http://www.maakki.com/WebService.asmx";
    RelativeLayout RL_nothing;
    ListView listview,listview_wifi;
    Toolbar myToolbar;
    TextView title, tv_message, time,tv_nothing;
    ImageView icon;
    Integer count;
    FloatingActionButton fab;
    //private Long notification_id = 0l, notification_millisecs = 0l;
    private boolean isWifiP2pEnabled = false, isAscending = false;
    //private String content = "";
    private Context context;
    private List<Block> listBlockchain, newlist;
    //private List<WifiP2pDevice> listpeers;
    //private BlockDAO blockDAO;
    private BlockchainDAO bcDAO;
    //private Block block;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private BlockchainAdapter adapter;
    private WiFiPeerListAdapter wAdapter;
    private BroadcastReceiver receiver,receiver1;
    String HCID;
    WifiManager mWifiMgr;
    WifiP2pManager mWifiP2pMgr;
    WifiP2pManager.Channel mChannel;
    BroadcastReceiver mReceiver;
    IntentFilter mIntentFilter;
    MenuItem menuitem;
    List<WifiP2pDevice> listpeers=new ArrayList<>();
    //ServerClass serverClass;
    //ClientClass clientClass;
    //SendReceive sendReceive;
    WifiP2pInfo info;
    public Boolean isConnect=true;
    JSONArray jsonarray;
    private String BlockchainSync_title;
    private String BlockchainSync_message1;
    private String BlockchainSync_submessage1;
    private String BlockchainSync_message2;
    private String BlockchainSync_submessage2;
    private String errMsg="";
    /*public Boolean isConnect(){
        return isConnect;
    }*/

    WifiP2pManager.ConnectionInfoListener infoListener = new WifiP2pManager.ConnectionInfoListener() {
        @Override
        public void onConnectionInfoAvailable(final WifiP2pInfo minfo) {
            //Log.i("xyz", "InfoAvailable is on");
            info = minfo;
            final InetAddress groupOwnerAddress=minfo.groupOwnerAddress;
            if (info.groupFormed && info.isGroupOwner) {

                Intent intent=new Intent(BlockchainList.this,ServerMainActivity.class);
                startActivity(intent);

            } else if (info.groupFormed) {
                Intent intent=new Intent(BlockchainList.this,ClientMainActivity.class);
                intent.putExtra("address",String.valueOf(groupOwnerAddress).substring(1));
                startActivity(intent);
            }
        }
    };

    WifiP2pManager.PeerListListener peerListListener = new WifiP2pManager.PeerListListener() {
        @Override
        public void onPeersAvailable(WifiP2pDeviceList peersList) {
            if (isConnect) {
                listpeers.clear();
                listpeers.addAll(peersList.getDeviceList());
                if (listpeers.size() > 0) {
                    listview.setVisibility(View.GONE);
                    listview_wifi.setVisibility(View.VISIBLE);
                    myToolbar.setTitle("Peers " + listpeers.size());
                    fab.setVisibility(View.GONE);
                    wAdapter.notifyDataSetChanged();

                } else {

                    show_Dialog("WiFi Connection", "No device found!", "Is WiFi of target device on?");
                }
            }
        }
    };

    private void CreateConnect(String address, final String name) {
        WifiP2pDevice device;
        WifiP2pConfig config = new WifiP2pConfig();
        //Log.i("xyz", address);

        config.deviceAddress = address;
        /*mac地址*/

        config.wps.setup = WpsInfo.PBC;
        //Log.i("address", "MAC IS " + address);
        if (address.equals("9a:ff:d0:23:85:97")) {
            config.groupOwnerIntent = 0;
            //Log.i("address", "lingyige shisun");
        }
        if (address.equals("36:80:b3:e8:69:a6")) {
            config.groupOwnerIntent = 15;
            //Log.i("address", "lingyigeshiwo");

        }

        mWifiP2pMgr.connect(mChannel, config, new WifiP2pManager.ActionListener() {

            @Override
            public void onSuccess() {
                //Intent intent=new Intent(BlockchainList.this,ClientMainActivity.class);
                //startActivity(intent);
                //show_Dialog1
                //show_Dialog("Connect success","Connect "+name+"\n"+address+"\n successfully!","transfer data?");
            }

            @Override
            public void onFailure(int reason) {
                show_Dialog("Connect failure","Can not connect "+name,"maybe later");
            }
        });
    }

    private void Disconnect() {
        mWifiP2pMgr.stopPeerDiscovery(mChannel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onFailure(int reason) {
            }
        });
        mWifiP2pMgr.removeGroup(mChannel, new WifiP2pManager.ActionListener() {

            @Override
            public void onFailure(int reasonCode) {
            }

            @Override
            public void onSuccess() {
            }

        });
        mWifiP2pMgr.cancelConnect(mChannel, new WifiP2pManager.ActionListener() {

            @Override
            public void onSuccess() {
                /*Toast.makeText(BlockchainList.this, "Aborting connection",
                        Toast.LENGTH_SHORT).show();*/
            }

            @Override
            public void onFailure(int reasonCode) {
                /*Toast.makeText(BlockchainList.this,
                        "Connect abort request failed. Reason Code: " + reasonCode,
                        Toast.LENGTH_SHORT).show();*/
            }
        });
    }

    private void setOnClick() {
        //listview_wifi.setOnTouchListener(swipeDetector);
        listview_wifi.setOnItemClickListener((AdapterView<?> parent, View v,
                                    int position, long id)-> {
                //if(!swipeDetector.swipeDetected()){
                //show_Dialog("Connecting "+listpeers.get(position).deviceName,"try to connect "+listpeers.get(position).deviceAddress,"10 secs..");
                CreateConnect(listpeers.get(position).deviceAddress,
                            listpeers.get(position).deviceName);

        });
        /*if(new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)) {

            //listview.setOnTouchListener(swipeDetector);
            listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View v,
                                        int position, long id) {
                    Block b = listBlockchain.get(position);
                    check_block(b);
                    //if (swipeDetector.swipeDetected()) {
                        //deleteCell(v, position);
                        //bcDAO.delete(b.getId());
                        //myToolbar.setTitle(getResources().getString(R.string.title_blockchain) + " " + bcDAO.getCount());
                    //} else {
                        //show_Dialog("Block.toShow()",b.toShow(),"");
                        //Block block=new BlockchainDAO(context).getPreviousblock(b);
                        //makeBlock(b.getDatatype(),b.getData());
                    //}
                }
            });
        }*/
    }

    private void check_block(Block block){
        if (block.getDatatype().equals("RG_1")) {
            Member member = new Member();
            member.setIntroducerid(block.getData().split(" ")[0]);
            member.setBlockIndex(block.getIndex());
            member.setHcid(block.getData().split(" ")[1]);
            member.setPublicKey(block.getData().split(" ")[2]);
            //memberlist.add(member);
            //int result = new MemberDAO(context).insert(member);
            //INVOKE_BlockChain_Broadcasting("Block# #"+block.getIndex()+" result:"+result);
            //if (new MemberDAO(context).insert(member) == 0) {
                //INVOKE_ALL("INVOKE_MemberList", "");
                preConnectivityBenifit pcb = new preConnectivityBenifit();
                pcb.setHcid(member.getHcid());
                pcb.setAmount(25d);
                pcb.setNote("registration");
                pcb.setBlockIndex(block.getIndex());
                pcb.setCreateTime(block.getTimestamp());
                //pcblist.add(pcb);
                //add HC that is converted by CR from 0.5 USD to introducer
                double hc = 0.5 / new CB_TradingDAO(context).getCR();
                block.setDatatype("getHC");
                String data = member.getIntroducerid() + " " + Utils.formatDoubleToString(hc) + " intro_reg";
                block.setData(data);
                block.insertHCDAO(context, block);
                //}
            //}
        }
    }
    //WifiP2pManager.ConnectionInfoListener infoListener;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            switch (menuItem.getItemId()) {
                case R.id.blocklist:
                    Intent intent =new Intent(BlockchainList.this,BlockList.class);
                    startActivity(intent);
                    break;
                case R.id.upload_blockchain:
                    AsyncCallWS_uploadBlockchain1 uploadBlockchainTask1=new AsyncCallWS_uploadBlockchain1();
                    uploadBlockchainTask1.execute();
                    break;
                case R.id.wifiDirect:
                    if (!isWifiP2pEnabled) {
                        return true;
                    }
                    mWifiP2pMgr.discoverPeers(mChannel, new WifiP2pManager.ActionListener() {
                        @Override
                        public void onSuccess() {
                            show_Dialog(BlockchainSync_title,BlockchainSync_message1,BlockchainSync_submessage1);
                        }
                        @Override
                        public void onFailure(int reasonCode) {
                            show_Dialog(BlockchainSync_title,BlockchainSync_message2,BlockchainSync_submessage2);
                        }
                    });
                    break;
                case R.id.delete:
                    AlertDialog alertDialog = new AlertDialog.Builder(BlockchainList.this).create();
                    alertDialog.setTitle("将要删除区块链");
                    alertDialog.setMessage("您确定要删除区块链所有信息吗？");
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "确定",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    listview.setVisibility(View.INVISIBLE);
                                    fab.setVisibility(View.INVISIBLE);
                                    RL_nothing.setVisibility(View.VISIBLE);
                                    bcDAO.clear();
                                    listBlockchain.clear();
                                    Intent intentservice = new Intent(context, CoreService.class);
                                    intentservice.putExtra("Message", "resetBlockchain");
                                    context.startService(intentservice);
                                    myToolbar.setTitle("");
                                    adapter.notifyDataSetChanged();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "略过",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                break;
            }
            return true;
        }
    };

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        jsonarray=new JSONArray();
        BlockchainSync_title=getResources().getString(R.string.BlockchainSync_title);
        BlockchainSync_message1=getResources().getString(R.string.BlockchainSync_message1);
        BlockchainSync_submessage1=getResources().getString(R.string.BlockchainSync_submessage1);
        BlockchainSync_message2=getResources().getString(R.string.BlockchainSync_message2);
        BlockchainSync_submessage2=getResources().getString(R.string.BlockchainSync_submessage2);

        mWifiMgr = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        //mWifiMgr.setWifiEnabled(false);
        mWifiP2pMgr = (WifiP2pManager) getApplicationContext().getSystemService(WIFI_P2P_SERVICE);
        if(mWifiP2pMgr!=null){
            mChannel = mWifiP2pMgr.initialize(this, getMainLooper(), null);
        }

        mReceiver = new WifiDirectBroadcastReceiver(mWifiP2pMgr, mChannel, this,
                peerListListener,infoListener);

        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);

        HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        //HCID = Utils.setMyHCID(context);
        //ShortcutBadger.with(getApplicationContext()).remove();
        listBlockchain = new ArrayList<>();
        //blockDAO = new BlockDAO(this);
        bcDAO=new BlockchainDAO(this);
        //block = new Block();
        /*if (getIntent().getExtras() != null) {
            Bundle bundle = this.getIntent().getExtras();
        }*/

        myToolbar = findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener((View v)-> {
                finish();

        });
        if(bcDAO.getCount()>0){
            myToolbar.setTitle(getResources().getString(R.string.title_blockchain)+" "+bcDAO.getCount());
        }else{
            myToolbar.setTitle("");
        }
        fab =  findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = findViewById(R.id.title);
        tv_message = findViewById(R.id.message);
        time = findViewById(R.id.time);
        icon = findViewById(R.id.icon);
        listview = findViewById(R.id.listview);
        listview_wifi= findViewById(R.id.listview_wifi);
        RL_nothing= findViewById(R.id.RL_nothing);
        tv_nothing = findViewById(R.id.tv_nothing);
        tv_nothing.setText("no blockchain created..");
        //tv = (TextView) findViewById(R.id.tv);
        count = bcDAO.getCount();
        listBlockchain = bcDAO.getAll();
        adapter = new BlockchainAdapter(this, R.layout.list_item, listBlockchain);
        listview.setAdapter(adapter);
        listpeers=new ArrayList<>();
        wAdapter = new WiFiPeerListAdapter(this, R.layout.list_item, listpeers);
        listview_wifi.setAdapter(wAdapter);
        //setOnClick();
        if (count > 0) {
            Collections.reverse(listBlockchain);
            //listtop=new ArrayList<PrevNotification>();
            //tv.setText("(" + count.toString() + ")");
            if (count > 100) {
                fab.setVisibility(View.VISIBLE);
            }
            fab.setOnClickListener((View v)-> {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }
                    Collections.reverse(listBlockchain);
                    adapter.notifyDataSetChanged();

            });

        } else {
            RL_nothing.setVisibility(View.VISIBLE);
        }
        //
        IntentFilter filter = new IntentFilter();
        filter.addAction("Invoke_BlockchainList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                bcDAO = new BlockchainDAO(context);
                newlist = new ArrayList<>();
                newlist = bcDAO.getAll();
                Block b = newlist.get(newlist.size() - 1);
                if (isAscending) {
                    listBlockchain.add(b);
                } else {
                    listBlockchain.add(0, b);
                }
                count=bcDAO.getCount();
                adapter.notifyDataSetChanged();
                if (count > 0) {
                    if (count == 1) {
                        listview.setVisibility(View.VISIBLE);
                    }
                    if (count > 10) {
                        fab.setVisibility(View.VISIBLE);
                    }
                    //tv.setText("(" + count + ")");
                    RL_nothing.setVisibility(View.GONE);
                }
                myToolbar.setTitle(getResources().getString(R.string.title_blockchain)+" "+bcDAO.getCount());
            }
        };
        registerReceiver(receiver, filter);

        RL_nothing.setOnClickListener((View v)-> {
                finish();
        });
        if (getIntent().getExtras() != null) {
            Bundle bundle = this.getIntent().getExtras();
            isConnect=bundle.getBoolean("isConnect",true);
            if(!isConnect){
                Disconnect();
            }
        }

        setOnClick();

        if(isConnected()){
            AsyncCallWS_getBlockLength getBlockLengthTask=new AsyncCallWS_getBlockLength();
            getBlockLengthTask.execute();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_blockchainlist, menu);
        menuitem=menu.getItem(0);
        if (mWifiMgr.isWifiEnabled() & isConnect) {
            menuitem.setVisible(true);
        } else {
            //if(isConnect){
                //mWifiMgr.setWifiEnabled(true);
                //menuitem.setVisible(true);
            //}else{
                menuitem.setVisible(false);
            //}
        }
        if(new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)){
            if(isConnected()){
                menu.getItem(1).setVisible(true);
            }
        }
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class BlockchainAdapter extends ArrayAdapter<Block> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        private BlockchainAdapter(Context context, int textViewResourceId, List<Block> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            Block b = getItem(position);

            if (convertView == null) {
                //Toast.makeText(BlockchainList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(BlockchainList.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(BlockchainList.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();
            int icon = R.drawable.blockchain;
            if(b != null){
                switch (b.getDatatype()) {
                    case "getCB":
                        icon = R.drawable.cb;
                        break;
                    case "getHC":
                        icon=R.drawable.ic_launcher;
                        break;
                    case "getPCB":
                        icon=R.drawable.pcb;
                        break;
                    case "Registration":
                        icon=R.drawable.noname;
                        break;
                    default:
                }
            }
            //long time = b.getCreateTime();
            String fm = "";
            //Date date = new Date(time);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            fm = formatter.format(b.getTimestamp());
            //new SimpleDateFormat(dateFormat).format(new Date(p.getLastModify()));
            String title="Block #"+b.getIndex()+" "+b.getDatatype()+" "+b.getNonce();
            holder.text_title.setText(title);
            String strMess=b.getId()+"\n"+b.getMaker()+"\n"+b.getData();
            if(b.getDatatype().equals("Registration")){
                strMess=b.getId()+"\n"+b.getMaker()+"\n"+b.getData().split(" ")[0]+"\n"+b.getData().split(" ")[1];
            }else if(b.getDatatype().equals("Activation")){
                strMess=b.getId()+"\n"+b.getMaker()+"\n"+b.getData().split(" ")[1]+"\n"+b.getData().split(" ")[2];
            }else if(b.getDatatype().equals("CB_Order")){
                strMess=b.getId()+"\n"+b.getMaker()+"\n"+b.getData().split(" ")[2]+"\n"+b.getData().split(" ")[3];
            }
            holder.text_message.setText(strMess);
            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            //}
            return view;
            //return convertView;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = view.findViewById(R.id.icon);
            vh.text_title = view.findViewById(R.id.title);
            vh.text_message = view.findViewById(R.id.message);
            vh.text_time = view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mReceiver, mIntentFilter);
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mReceiver);
    }

    public void setIsWifiP2pEnabled(Boolean isWifiP2pEnabled){
        this.isWifiP2pEnabled = isWifiP2pEnabled;
        //showAlertDialog2("setIsWifiP2pEnabled",String.valueOf(isWifiP2pEnabled));
    }

    public class WiFiPeerListAdapter extends ArrayAdapter<WifiP2pDevice> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public WiFiPeerListAdapter(Context context, int textViewResourceId, List<WifiP2pDevice> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        @NonNull
        public View getView(int position, View convertView, ViewGroup parent) {
            final View view;
            final ViewHolder holder;
            WifiP2pDevice w = getItem(position);
            if (convertView == null) {
                //Toast.makeText(BlockchainList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(BlockchainList.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(BlockchainList.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();
            String dn="";
            String da="";
            if(w!=null){
                dn = w.deviceName;
                da = w.deviceAddress;
            }
            int icon = R.drawable.logo;
            holder.text_title.setText(dn);
            holder.text_message.setText(da);
            holder.text_time.setText("");
            holder.image_icon.setImageResource(icon);
            //}
            return view;
            //return convertView;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = view.findViewById(R.id.icon);
            vh.text_title = view.findViewById(R.id.title);
            vh.text_message = view.findViewById(R.id.message);
            vh.text_time = view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

    public void show_Dialog(String title,String message,String submessage) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = BlockchainList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_title = view.findViewById(R.id.tv_title);
        tv_title.setText(title);
        TextView tv_message = view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        TextView tv_submessage = view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 20) {
            super.onActivityResult(requestCode, resultCode, data);
            Uri uri = data.getData();
            Intent serviceIntent = new Intent(BlockchainList.this,
                    FileTransferService.class);

            serviceIntent.setAction(FileTransferService.ACTION_SEND_FILE);
            serviceIntent.putExtra(FileTransferService.EXTRAS_FILE_PATH,
                    uri.toString());

            serviceIntent.putExtra(FileTransferService.EXTRAS_GROUP_OWNER_ADDRESS,
                    info.groupOwnerAddress.getHostAddress());
            serviceIntent.putExtra(FileTransferService.EXTRAS_GROUP_OWNER_PORT,
                    8988);
            startService(serviceIntent);
        }
    }

    private class AsyncCallWS_uploadBlockchain2 extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            uploadBlockchain(jsonarray);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {

        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private void uploadBlockchain(JSONArray jsonArray) {
        String METHOD_NAME = "blockChain";
        //String NAMESPACE = "http://152.101.178.115:8081/";
        String NAMESPACE = staticVar.Server_url;
        String SOAP_ACTION = NAMESPACE + METHOD_NAME;
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        //String timeStamp = String.valueOf(new Date().getTime());
        String URL_WS = NAMESPACE + "webService.asmx";
        String timeStamp = String.valueOf(new Date().getTime());
        String encryptStr = HCID + "@HyperConn@" + timeStamp.trim();
        String identifyStr = getHashCode(encryptStr).toUpperCase();
        request.addProperty("blockJSONArray", jsonArray.toString());
        request.addProperty("HCID", HCID);
        request.addProperty("timeStamp",  timeStamp);
        request.addProperty("identifyStr", identifyStr);
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        //Set output SOAP object
        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        //Create HTTP call object
        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL_WS);

        SoapPrimitive soapPrimitive = null;
        try {
            androidHttpTransport.call(SOAP_ACTION, envelope);
            soapPrimitive = (SoapPrimitive) envelope.getResponse();
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
        }
        /*String tmp = soapPrimitive.toString();
        //一開始從網路接收通常為String型態,tmp為接收到的String,為避免串流內有其他資料只需抓取{}間的內容
        tmp = tmp.substring(tmp.indexOf("{"), tmp.lastIndexOf("}") + 1);
        JSONObject json_read;
        //將資料丟進JSONObject
        //接下來選擇型態使用get並填入key取值
        try {
            json_read = new JSONObject(tmp);
            fileName = json_read.getString("fileName");
        } catch (Exception e) {
            errMsg = e.getMessage();
        }*/
    }

    private class AsyncCallWS_uploadBlockchain1 extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            jsonarray=new BlockchainDAO(context).getResults();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            show_Dialog("jasonArray.Upload.done","Blocks count: "+jsonarray.length(),"");
            AsyncCallWS_uploadBlockchain2 uploadBlockchainTask=new AsyncCallWS_uploadBlockchain2();
            uploadBlockchainTask.execute();
            //String msg=jsonarray.toString();
            //sendReceive.write(msg.getBytes());
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private void deleteCell(final View v, final int index) {
        Animation.AnimationListener al = new Animation.AnimationListener() {
            //@Override
            public void onAnimationEnd(Animation arg0) {
                listBlockchain.remove(index);
                count--;
                if (count < 2) {
                    fab.setVisibility(View.INVISIBLE);
                    if (count < 1) {
                        listview.setVisibility(View.GONE);
                    }
                }
                if (count == 0) {
                    RL_nothing.setVisibility(View.VISIBLE);
                }
                //tv.setText("(" + count + ")");
                ViewHolder vh = (ViewHolder) v.getTag();
                vh.needInflate = true;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        };
        collapse(v, al);
    }

    private void collapse(final View v, Animation.AnimationListener al) {
        final int initialHeight = v.getMeasuredHeight();
        final int top = v.getTop();
        //Toast.makeText(getApplicationContext(), "collapsetop:"+top , Toast.LENGTH_SHORT).show();
        final int ANIMATION_DURATION = 200;
        Animation anim = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {

                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (al != null) {
            anim.setAnimationListener(al);
        }
        anim.setDuration(ANIMATION_DURATION);
        v.startAnimation(anim);
    }

    private void makeBlock(String datatype, String data) {
        Intent intent = new Intent(BlockchainList.this, CoreService.class);
        intent.putExtra("Message", datatype + ":" + data);
        startService(intent);
    }

    private class AsyncCallWS_getBlockLength extends AsyncTask<String, Void, Integer> {
        @Override
        protected Integer doInBackground(String... params) {
            return getBlockLength();
        }

        @Override
        protected void onPostExecute(Integer result) {
             if(result-new BlockchainDAO(context).getCount()>100){
                 String title=getResources().getString(R.string.Dialog_blochchain_hint_title);
                 int count = result-new BlockchainDAO(context).getCount();
                 String message=getResources().getString(R.string.Dialog_blochchain_hint_message);
                 String submessage=getResources().getString(R.string.Dialog_blochchain_hint_submessage);
                 Dialog_getBlockLength(title,count+" "+message,submessage,1);
             }
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private int getBlockLength() {
        int block_count = 0;
        String METHOD_NAME = "getBlockLength";
        //String NAMESPACE = "http://152.101.178.115:8081/";
        String NAMESPACE = staticVar.Server_url;

        String SOAP_ACTION = NAMESPACE + METHOD_NAME;
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        //String timeStamp = String.valueOf(new Date().getTime());
        String URL_WS = NAMESPACE + "webService.asmx";
        //String encryptStr = target_maakki_id.trim() + "MDF-M@@kki.cc" + timeStamp.trim();

        //String identifyStr = getHashCode(encryptStr).toUpperCase();
        //request.addProperty("fileName", filename);
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        //Set output SOAP object
        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        //Create HTTP call object
        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL_WS);

        SoapPrimitive soapPrimitive = null;
        try {
            androidHttpTransport.call(SOAP_ACTION, envelope);
            soapPrimitive = (SoapPrimitive) envelope.getResponse();
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
        }
        String tmp = soapPrimitive.toString();
        //一開始從網路接收通常為String型態,tmp為接收到的String,為避免串流內有其他資料只需抓取{}間的內容
        tmp = tmp.substring(tmp.indexOf("{"), tmp.lastIndexOf("}") + 1);
        JSONObject json_read;
        //將資料丟進JSONObject
        //接下來選擇型態使用get並填入key取值
        try {
            json_read = new JSONObject(tmp);
            block_count = json_read.getInt("block_count");
        } catch (Exception e) {
            //errMsg = e.getMessage();
        }
    return block_count;
    }

    private void Dialog_getBlockLength(String title,String message,String submessage,int REQUEST_CODE){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = BlockchainList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_blockchainlength, null);
        ImageView iv=(ImageView) view.findViewById(R.id.iv);
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(submessage);
        TextView tv_ok = (TextView) view.findViewById(R.id.tv_ok);
        tv_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(REQUEST_CODE==1){
                    String title=getResources().getString(R.string.Dialog_blochchain_hint2_title);
                    String message=getResources().getString(R.string.Dialog_blochchain_hint2_message);
                    String submessage=getResources().getString(R.string.Dialog_blochchain_hint2_submessage);
                    Dialog_getBlockLength(title,message,submessage,2);
                }else{
                    Intent intentservice = new Intent(context, CoreService.class);
                    intentservice.putExtra("Message", "SyncBlockchain_Start");
                    context.startService(intentservice);
                    finish();
                }
                alertDialog.dismiss();
            }
        });
        TextView tv_cancel = (TextView) view.findViewById(R.id.tv_cancel);
        if(REQUEST_CODE==1){
            tv_cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                }
            });
        }else{
            tv_cancel.setVisibility(View.INVISIBLE);
        }

        alertDialog.setView(view);
        alertDialog.show();
    }

    public static String getHashCode(String Gkey) { //得到毫秒数

        MessageDigest shaCode = null;
        Date curDate = new Date();
        String dataStructure = Gkey;
        try {
            shaCode = MessageDigest.getInstance("SHA-256");
            shaCode.update(dataStructure.getBytes());
            //System.out.println("dataStructure="+Gkey);
        } catch (Exception e) {
            //e.printStackTrace();
            return "";
        }
        return byte2Hex(shaCode.digest());
    }

    private static String byte2Hex(byte[] data) {
        String hexString = "";
        String stmp = "";

        for (int i = 0; i < data.length; i++) {
            stmp = Integer.toHexString(data[i] & 0XFF);

            if (stmp.length() == 1) {
                hexString = hexString + "0" + stmp;
            } else {
                hexString = hexString + stmp;
            }
        }
        return hexString.toUpperCase();
    }

    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = null;
        if(cm != null){
            networkInfo=cm.getActiveNetworkInfo();
        }
        if(networkInfo != null){
            return networkInfo.isConnected();
        }
        return false;
    }

}
