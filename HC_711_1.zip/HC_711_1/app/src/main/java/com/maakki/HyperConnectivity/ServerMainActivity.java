package com.maakki.HyperConnectivity;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public class ServerMainActivity extends Activity {
    ServerSocket serverSocket;
    static final int SocketServerPORT = 8080;
    String address;
    TextView info, textResponse;
    String response = "";
    SendReceive sendReceive;

    Block block;
    List<Block> blockList;
    Context context;
    SocketServerThread socketServerThread;
    Thread socketThread;
    Button buttonConnect, buttonClear,buttonDisconnect;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servermain);
        blockList=new ArrayList<>();
        textResponse = (TextView) findViewById(R.id.textResponse);
        //infoip = (TextView) findViewById(R.id.infoip);
        buttonConnect = (Button) findViewById(R.id.connect);
        buttonClear = (Button) findViewById(R.id.clear);
        buttonDisconnect = (Button) findViewById(R.id.disconnect);
        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textResponse.setText("");
            }
        });
        buttonDisconnect = (Button) findViewById(R.id.disconnect);
        buttonDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(ServerMainActivity.this,BlockchainList.class);
                intent.putExtra("isConnect",false);
                startActivity(intent);
            }
        });
        //socketServerThread=new SocketServerThread();
        //socketServerThread.start();
        socketThread = new Thread(new SocketThread());
        socketThread.start();
    }

    /*View.OnClickListener buttonConnectOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View arg0) {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            if(blockList.size()>0){
                for(Block block:blockList){
                    //sendReceive.write(block);
                    BlockSendTask blockSendTask = new BlockSendTask();
                    blockSendTask.execute(block);
                }
                blockList.clear();
                buttonConnect.setBackgroundColor(getResources().getColor(R.color.greyscale3));
                buttonConnect.setEnabled(false);
            }else{
                Toast.makeText(context, "No block is sended", Toast.LENGTH_SHORT).show();
            }
        }
    };*/

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    /*public class BlockSendTask extends AsyncTask<Block, Void, Void> {
        @Override
        protected Void doInBackground(Block... arg0) {
            Block block=arg0[0];
            Socket socket = null;
            DataOutputStream dataOutputStream = null;
            DataInputStream dataInputStream = null;

            try {
                //socket = new Socket(address, Integer.parseInt(port));
                //serverSocket = new ServerSocket(SocketServerPORT);
                serverSocket = new ServerSocket(socket_thread_port);
                socket = serverSocket.accept();

                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeUTF(block.toString());

                dataInputStream = new DataInputStream(socket.getInputStream());
                response += dataInputStream.readUTF();

            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "UnknownHostException: " + e.toString()+"\n";
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "IOException: " + e.toString()+"\n";
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            textResponse.setText(response);
            super.onPostExecute(result);
        }

    }*/

    public class BlockSendTask extends AsyncTask<Block, Void, Void> {
        @Override
        protected Void doInBackground(Block... arg0) {
            Block block=arg0[0];
            Socket socket = null;
            DataOutputStream dataOutputStream = null;
            DataInputStream dataInputStream = null;

            try {
                socket = new Socket(address, SocketServerPORT);
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeUTF(block.toString());

                dataInputStream = new DataInputStream(socket.getInputStream());
                response += dataInputStream.readUTF();

            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "UnknownHostException: " + e.toString()+"\n";
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response += "IOException: " + e.toString()+"\n";
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            textResponse.setText(response);
            super.onPostExecute(result);
        }

    }

    private class SocketThread extends Thread {
        Socket socket = null;
        int count = 0;
        Long target_index;
        Long start_index;
        Long end_index;
        //String msgReply = "";
        //Boolean isServerBigger=false;
        @Override
        public void run() {
            Socket socket = null;
            DataInputStream dataInputStream = null;
            DataOutputStream dataOutputStream = null;
            try {
                serverSocket = new ServerSocket(SocketServerPORT);
                while (true) {
                    socket = serverSocket.accept();
                    address=String.valueOf(socket.getInetAddress());
                    dataInputStream = new DataInputStream(
                            socket.getInputStream());
                    dataOutputStream = new DataOutputStream(
                            socket.getOutputStream());

                    String messageFromClient = "";
                    String msgReply = "";
                    //If no message sent from client, this code will block the program
                    messageFromClient = dataInputStream.readUTF();
                    //response=messageFromClient;
                    if (messageFromClient.startsWith("Block #")) {
                        block = messageToBlock(messageFromClient);
                        count++;
                        response = "#" + count + " from " + socket.getInetAddress()
                                + " : " + socket.getPort() + "\n"
                                + "Block#" + block.getIndex() + " is received..\n" + response;

                        msgReply = "Block#" + block.getIndex() + " is sended..\n";
                    }
                    else if (messageFromClient.startsWith("Block_Max_Index")) {
                        msgReply = "Block_Max_Index in Blockchain of target is : " + new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
                        response = "Block_Max_Index in Blockchain of target is : " + Long.parseLong(messageFromClient.split(" : ")[1]);
                        target_index = Long.parseLong(messageFromClient.split(" : ")[1]);
                        start_index = target_index + 1;
                        end_index=new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
                        if(end_index > target_index){
                            //isServerBigger=true;
                            blockList=new BlockchainDAO(context).getBlockList(start_index,end_index);
                            if(blockList.size()>1){
                                response+=". blockList from #"+start_index+" to #"+end_index+" ("+blockList.size()+") is sending..\n";
                            }else if(blockList.size()>0){
                                response+=". Block #"+end_index+" is sending.. \n";
                            }
                        }else if(end_index == target_index){
                            response+="\nthat is same as mine("+end_index+"), no need to synchronize.\n";
                        }else if(end_index < target_index){
                            response+="\nthat is bigger than mine("+end_index+"), waiting for incoming blocks.\n";
                        }
                    }
                    else if (messageFromClient.startsWith("Block_index:")) {
                        Long index= Long.parseLong(messageFromClient.split(":")[1]);
                        msgReply = new BlockchainDAO(context).getByIndex(index).toString();
                        //dataOutputStream.writeUTF(msgReply);
                        response = "Block #" + index +" is sended.\n"+response;
                    }

                    dataOutputStream.writeUTF(msgReply);
                    ServerMainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            /*if(isServerBigger){
                                buttonConnect.setOnClickListener(buttonConnectOnClickListener);
                                buttonConnect.setBackgroundColor(getResources().getColor(R.color.colorBlue));
                            }*/

                            textResponse.setText(response);
                        }
                    });

                }

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                final String errMsg = e.toString();
                ServerMainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textResponse.setText(errMsg);
                    }
                });

            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }

    }

    private class SocketServerThread extends Thread {
        Socket socket;
        //ServerSocket serverSocket;
        @Override
        public void run() {
            try {
                //this.serverSocket=serverSocket;
                serverSocket = new ServerSocket(SocketServerPORT);
                while(true){
                    socket = serverSocket.accept();
                    sendReceive=new SendReceive(socket);
                    sendReceive.start();
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                final String errMsg = e.toString();
                ServerMainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textResponse.setText(errMsg);
                    }
                });
            } /*finally {
                if (serverSocket != null) {
                    try {
                        serverSocket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }*/
        }

    }

    private class SendReceive extends Thread{
        private Socket socket;
        int count = 0;
        DataInputStream dataInputStream = null;
        DataOutputStream dataOutputStream = null;
        Long target_index;
        Long start_index;
        Long end_index;
        String msgReply = "";
        Boolean isServerBigger=false;

        public  SendReceive(Socket skt){
            socket=skt;
            try{
                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());

            }catch (IOException e){}
        }

        @Override
        public  void run() {
            //while (true) {
            String messageFromClient = "";
            //If no message sent from client, this code will block the program
            while(socket!=null) {
                try {
                    messageFromClient = dataInputStream.readUTF();
                    //response=messageFromClient;
                    if (messageFromClient.startsWith("Block #")) {
                        block = messageToBlock(messageFromClient);
                        count++;
                        response += "#" + count + " from " + socket.getInetAddress()
                                + " : " + socket.getPort() + "\n"
                                + block.toShow() + "\n\n";

                        msgReply = "Block#" + block.getIndex() + " is sended..\n";
                    }
                    else if (messageFromClient.startsWith("Block_Max_Index")) {
                        msgReply = "Block_Max_Index in Blockchain of target is : " + new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
                        response = "Block_Max_Index in Blockchain of target is : " + Long.parseLong(messageFromClient.split(" : ")[1]);
                        target_index = Long.parseLong(messageFromClient.split(" : ")[1]);
                        start_index = target_index + 1;
                        end_index=new BlockchainDAO(context).getBlock_MaxIndex().getIndex();
                        if(end_index > target_index){
                            isServerBigger=true;
                            blockList=new BlockchainDAO(context).getBlockList(start_index,end_index);
                            if(blockList.size()>1){
                                response+=". blockList from #"+start_index+" to #"+end_index+" ("+blockList.size()+") is ready to send. Go now?\n";
                            }else if(blockList.size()>0){
                                response+=". Block #"+end_index+" is ready to send. Go now?\n";
                            }
                        }else if(end_index == target_index){
                            response+="\nthat is same as mine("+end_index+"), no need to synchronize.\n";
                        }else if(end_index < target_index){
                            response+="\nthat is bigger than mine("+end_index+"), waiting for incoming blocks.\n";
                        }
                        //response=end_index+" / "+target_index +" / "+start_index +" / "+blockList.size();
                    }
                    dataOutputStream.writeUTF(msgReply);
                    ServerMainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(isServerBigger){
                                //buttonConnect.setOnClickListener(buttonConnectOnClickListener);
                                //buttonConnect.setBackgroundColor(getResources().getColor(R.color.colorBlue));
                            }
                            textResponse.setText(response);
                        }
                    });
                } catch (IOException e) {
                }
            }
        }
        public void write(Block block){
            //msgReply=block.toString();
            try {
                dataOutputStream.writeUTF(block.toString());
            }catch (IOException e){
                ServerMainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String err=e.getMessage();
                        textResponse.setText(err);
                    }
                });
            }
        }
    }

    private Block messageToBlock(String message){
        block=new Block();
        String[] eachlineStr = message.split("\n");
        int index = Integer.parseInt(eachlineStr[0].split("#")[1].split(" ")[0]);
        String datatype = eachlineStr[0].split(" ")[2];
        int nonce = Integer.parseInt(eachlineStr[0].split(" ")[3]);
        long timestamp = Long.parseLong(eachlineStr[1].split(":")[1]);
        String maker = eachlineStr[2].split(":")[1];
        String Hash = eachlineStr[3].split(":")[1];
        //if(!new BlockDAO(context).isExisted(Hash)){}
        String previousHash = eachlineStr[4].split(":")[1];
        //String data = eachlineStr[5].split(":")[1];
        String data =  message.split("\ndata:")[1];
        block.setIndex(index);
        block.setMaker(maker);
        block.setTimestamp(timestamp);
        block.setData(data);
        block.setDatatype(datatype);
        block.setNonce(nonce);
        block.setHash(Hash);
        block.setPreviousHash(previousHash);
        addToBlockDAO(block);
        return block;
    }

    private void addToBlockDAO(Block b) {
        //BlockDAO bD = new BlockDAO(context);
        //Create a child thread
        /*Thread childThread = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    //ignore
                }*/

                if (!new BlockDAO(context).isExisted(b.getHash())) {
                    new BlockDAO(context).insert(b);
                }
            /*}
        };
        // Start the thread.
        childThread.start();*/
    }

    private String getIpAddress() {
        String ip = "";
        try {
            Enumeration<NetworkInterface> enumNetworkInterfaces = NetworkInterface
                    .getNetworkInterfaces();
            while (enumNetworkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = enumNetworkInterfaces
                        .nextElement();
                Enumeration<InetAddress> enumInetAddress = networkInterface
                        .getInetAddresses();
                while (enumInetAddress.hasMoreElements()) {
                    InetAddress inetAddress = enumInetAddress.nextElement();

                    if (inetAddress.isSiteLocalAddress()) {
                        ip += "SiteLocalAddress: "
                                + inetAddress.getHostAddress() + "\n";
                    }

                }

            }

        } catch (SocketException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            ip += "Something Wrong !" + e.toString() + "\n";
        }

        return ip;
    }
}
