package com.maakki.HyperConnectivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// 資料功能類別
public class HyperConnectivityDAO {
    // 表格名稱
    public static final String TABLE_NAME = "HyperConnectivityDAO";

    // 編號表格欄位名稱，固定不變
    public static final String KEY_ID = "_id";
    Context context;

    // 其它表格欄位名稱
    public static final String Hcid_COLUMN = "hcid";
    public static final String Amount_COLUMN = "Amount";
    public static final String note_COLUMN = "note";
    public static final String BlockIndex_COLUMN = "block_index";
    public static final String CreateTime_COLUMN = "createtime";


    // 提醒日期時間
    //public static final String ALARMDATETIME_COLUMN = "alarmdatetime";

    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    Hcid_COLUMN + " TEXT NOT NULL, " +
                    Amount_COLUMN + " REAL NOT NULL, " +
                    note_COLUMN + " TEXT NOT NULL, " +
                    BlockIndex_COLUMN +" INTEGER NOT NULL, " +
                    CreateTime_COLUMN +" INTEGER NOT NULL) ";

    // 資料庫物件
    private SQLiteDatabase db;

    // 建構子，一般的應用都不需要修改
    public HyperConnectivityDAO(Context context) {
        this.context=context;
        db = HyperConnDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public HyperConnectivity insert(HyperConnectivity hc) {
        // 建立準備新增資料的ContentValues物件

        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的新增資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(Hcid_COLUMN, hc.getHcid());
        cv.put(Amount_COLUMN,hc.getAmount());
        cv.put(note_COLUMN, hc.getNote());
        cv.put(BlockIndex_COLUMN, hc.getBlockIndex());
        cv.put(CreateTime_COLUMN, hc.getCreateTime());

        long id = db.insert(TABLE_NAME, null, cv);
        // 設定編號
        hc.setId(id);

        return hc;
    }

    // 修改參數指定的物件
    public boolean update(HyperConnectivity hc) {
        // 建立準備修改資料的ContentValues物件
        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(Hcid_COLUMN, hc.getHcid());
        cv.put(Amount_COLUMN,hc.getAmount());
        cv.put(note_COLUMN, hc.getNote());
        cv.put(BlockIndex_COLUMN, hc.getBlockIndex());
        cv.put(CreateTime_COLUMN, hc.getCreateTime());
        // 設定修改資料的條件為編號
        String where = KEY_ID + "=" + hc.getId();

        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_ID + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }

    public void clear() {
        for(HyperConnectivity hc:getAll()){
            delete(hc.getId());
        }
    }

    // 讀取所有联络人資料
    public List<HyperConnectivity> getAll() {
        List<HyperConnectivity> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, KEY_ID+" DESC", null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    // 讀取所有联络人資料
    public Double getSum() {
        double result=0d;
        for(HyperConnectivity hc:getAll()){
            //if(hc.getHcid().equals(getAll().get(0).getSender())){
                result+=hc.getAmount();
            //}
        }
        return result;
    }

    // 取得与某个HCID相关的所有记录
    public List<HyperConnectivity> getByHcid(String hcid) {
        // 準備回傳結果用的物件
        List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = Hcid_COLUMN +"='"+hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, KEY_ID+" DESC", null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public Double getSumByHcid(String hcid) {
        // 準備回傳結果用的物件
        Double result=0d;
        //List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = Hcid_COLUMN +"='"+hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount();
        }
        cursor.close();
        return result;
    }

    public Double getSumtoPCBByHcid(String hcid) {
        // 準備回傳結果用的物件
        Double result=0d;
        //List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = Hcid_COLUMN +"='"+hcid+"' AND "+ note_COLUMN + "='toPCB'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result-=getRecord(cursor).getAmount();
        }
        cursor.close();
        return result;
    }

    public Double getHCSumfromCB(String hcid) {
        double result=0d;
        for(HyperConnectivity hc:getByHcid(hcid)){
            if(hc.getNote().equals("fromCB")){
                result+=hc.getAmount();
            }
        }
        return result;
    }

    public Double getHCSum_fromAll(String hcid) {
        double result=0d;
        for(HyperConnectivity hc:getByHcid(hcid)){
            if(hc.getNote().equals("fromCB")||
                    hc.getNote().equals("self_activation")||
                    hc.getNote().equals("intro_activation")||
                    hc.getNote().equals("intro_fromCB")||
                    hc.getNote().equals("intro_reg")
            ){
                result+=hc.getAmount();
            }
        }
        return result;
    }

    public String getStrHCSum_fromAll(String hcid) {
        String result="";
        for(HyperConnectivity hc:getByHcid(hcid)){
            if(hc.getNote().equals("fromCB")){
                result+="fromCB: "+hc.getAmount()+"\n";
            }else if(hc.getNote().equals("self_activation")){
                result+="self_activation: "+hc.getAmount()+"\n";
            }else if(hc.getNote().equals("intro_activation")){
                result+="intro_activation: "+hc.getAmount()+"\n";
            }
        }
        return result;
    }


    public Double getSumfromCBByHcid(String hcid) {
        // 準備回傳結果用的物件
        Double result=0d;
        //List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = Hcid_COLUMN +"='"+hcid+"' AND "+ note_COLUMN + "='fromCB'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount();
        }
        cursor.close();
        return result;
    }

    public Double getSumintro_fromCBByHcid(String hcid) {
        // 準備回傳結果用的物件
        Double result=0d;
        //List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = Hcid_COLUMN +"='"+hcid+"' AND "+ note_COLUMN + "='intro_fromCB'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount();
        }
        cursor.close();
        return result;
    }

    public double multiply(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.multiply(b2).doubleValue();
    }

    public Double getAmount_HCtoPCB(String hcid){
        double amount=0d;
        double gr=Double.parseDouble(context.getResources().getString(R.string.Basic_Growth_Rate))*(1+new MemberDAO(context).getExtensioncountIn24hr(hcid));
        if(gr>0.028){gr=0.028;}
        amount=multiply(getSumByHcid(hcid),gr);
        return  amount;
    }

    public Long getLastTimeToPcbByHcid(String hcid){
        Long result=0L;
        //List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = Hcid_COLUMN +"='"+hcid+"' AND "+ Amount_COLUMN + "<0";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, KEY_ID+" DESC", null);

        if (cursor.moveToFirst()) {
            result=getRecord(cursor).getCreateTime();
        }
        cursor.close();
        return result;
    }

    public double getBalanceByHCID(String hcid){
        double balance=0d;
        HyperConnectivityDAO hcDAO=new HyperConnectivityDAO(context);
        List<HyperConnectivity> hclist = hcDAO.getByHcid(hcid);
        for (HyperConnectivity cb:hclist){
            balance+=cb.getAmount();
        }
        return balance;
    }

    // 把Cursor目前的資料包裝為物件
    public HyperConnectivity getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        HyperConnectivity result = new HyperConnectivity();
        result.setId(cursor.getLong(0));
        result.setHcid(cursor.getString(1));
        result.setAmount(cursor.getDouble(2));
        result.setNote(cursor.getString(3));
        result.setBlockIndex(cursor.getLong(4));
        result.setCreateTime(cursor.getLong(5));

        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }

}