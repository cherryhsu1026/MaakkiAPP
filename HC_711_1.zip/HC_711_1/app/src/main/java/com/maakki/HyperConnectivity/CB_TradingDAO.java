package com.maakki.HyperConnectivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

// 資料功能類別
public class CB_TradingDAO {
    // 表格名稱
    public static final String TABLE_NAME = "CB_Trading";

    // 編號表格欄位名稱，固定不變
    public static final String KEY_ID = "_id";
    Context context;

    // 其它表格欄位名稱
    public static final String hash_seller_Column = "hash_seller";
    public static final String hash_buyer_COLUMN = "hash_buyer";
    public static final String amount_COLUMN = "_amount";
    public static final String currency_COLUMN = "_currency";
    public static final String cashflow1_COLUMN = "_cashflow1";
    public static final String cashflow2_COLUMN = "_cashflow2";
    public static final String cb_amount_COLUMN = "cb_amount";
    public static final String CR_COLUMN = "cbt_cr";
    public static final String hash_COLUMN = "cbt_hash";
    public static final String exchange_fee_COLUMN = "exchange_fee";
    public static final String status_COLUMN = "cbt_status";
    public static final String note_COLUMN = "cbt_note";
    public static final String block_index_COLUMN = "block_index";
    public static final String CreateTime_COLUMN = "createtime";


    // 提醒日期時間
    //public static final String ALARMDATETIME_COLUMN = "alarmdatetime";

    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    hash_seller_Column + " TEXT NOT NULL, " +
                    hash_buyer_COLUMN + " TEXT NOT NULL, " +
                    amount_COLUMN + " REAL NOT NULL, " +
                    currency_COLUMN + " TEXT NOT NULL, " +
                    cashflow1_COLUMN + " TEXT, " +
                    cashflow2_COLUMN + " TEXT, " +
                    cb_amount_COLUMN + " REAL NOT NULL, " +
                    CR_COLUMN + " REAL NOT NULL, " +
                    hash_COLUMN +" TEXT NOT NULL, " +
                    exchange_fee_COLUMN +" REAL NOT NULL, " +
                    status_COLUMN +" INTEGER NOT NULL, " +
                    note_COLUMN +" TEXT, " +
                    block_index_COLUMN +" INTEGER NOT NULL, " +
                    CreateTime_COLUMN +" INTEGER NOT NULL) ";

    // 資料庫物件
    private SQLiteDatabase db;

    // 建構子，一般的應用都不需要修改
    public CB_TradingDAO(Context context) {
        this.context=context;
        db = CB_TradingDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public CB_Trading insert(CB_Trading cbt) {
        // 建立準備新增資料的ContentValues物件
        if (!update(cbt) & getByHash(cbt.getHash())==null) {
            ContentValues cv = new ContentValues();
            // 加入ContentValues物件包裝的新增資料
            // 第一個參數是欄位名稱， 第二個參數是欄位的資料
            cv.put(hash_seller_Column, cbt.getHash_seller());
            cv.put(hash_buyer_COLUMN, cbt.getHash_buyer());
            cv.put(amount_COLUMN, cbt.getAmount());
            cv.put(currency_COLUMN, cbt.getCurrency());
            cv.put(cashflow1_COLUMN, cbt.getCashflow_1());
            cv.put(cashflow2_COLUMN, cbt.getCashflow_2());
            cv.put(cb_amount_COLUMN, cbt.getCB_Amount());
            cv.put(CR_COLUMN, cbt.getCR());
            cv.put(hash_COLUMN, cbt.getHash());
            cv.put(exchange_fee_COLUMN, cbt.getExchnge_fee());
            cv.put(status_COLUMN, cbt.getStatus());
            cv.put(note_COLUMN, cbt.getNote());
            cv.put(block_index_COLUMN, cbt.getBlockIndex());
            cv.put(CreateTime_COLUMN, cbt.getCreateTime());

            long id = db.insert(TABLE_NAME, null, cv);
            // 設定編號
            cbt.setId(id);
        }
        return cbt;
    }


    public CB_Trading getByHash(String hash) {
        // 準備回傳結果用的物件
        CB_Trading cbt = null;
        // 使用編號為查詢條件
        String SELECTION = hash_COLUMN + "='" + hash +"'";
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTION, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            cbt = getRecord(result);
        }
        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return cbt;
    }

    // 修改參數指定的物件
    public boolean update(CB_Trading cbt) {
        // 建立準備修改資料的ContentValues物件
        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(hash_seller_Column, cbt.getHash_seller());
        cv.put(hash_buyer_COLUMN, cbt.getHash_buyer());
        cv.put(amount_COLUMN, cbt.getAmount());
        cv.put(currency_COLUMN, cbt.getCurrency());
        cv.put(cashflow1_COLUMN, cbt.getCashflow_1());
        cv.put(cashflow2_COLUMN, cbt.getCashflow_2());
        cv.put(cb_amount_COLUMN,cbt.getCB_Amount());
        cv.put(CR_COLUMN, cbt.getCR());
        cv.put(hash_COLUMN, cbt.getHash());
        cv.put(exchange_fee_COLUMN, cbt.getExchnge_fee());
        cv.put(status_COLUMN, cbt.getStatus());
        cv.put(note_COLUMN, cbt.getNote());
        cv.put(block_index_COLUMN, cbt.getBlockIndex());
        cv.put(CreateTime_COLUMN, cbt.getCreateTime());
        // 設定修改資料的條件為編號
        //String where = KEY_ID + "=" + cbt.getId();
        String where = hash_COLUMN + "='" + cbt.getHash()+"' AND "+ status_COLUMN +" <= "+cbt.getStatus();
        //String where = hash_COLUMN + "='" + cbt.getHash()+"'";

        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_ID + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    // 取得指定編號的資料物件
    public CB_Trading get(long id) {
        // 準備回傳結果用的物件
        CB_Trading cb = null;
        // 使用編號為查詢條件
        String NotificationID = KEY_ID + "=" + id;
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, NotificationID, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            cb = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return cb;
    }

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }
    public void clear() {
        for(CB_Trading cbt:getAll()){
            delete(cbt.getId());
        }
    }
    // 讀取所有联络人資料
    public List<CB_Trading> getAll() {
        List<CB_Trading> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    // 取得与某个HCID相关的所有记录
    public Double getUSDSum_CBBoughtByHcid(String hcid) {
        Double result=0d;
        // 準備回傳結果用的物件
        //List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hash_buyer_COLUMN +"='"+hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
             result+=Utils.multiply(getRecord(cursor).getCB_Amount(),getRecord(cursor).getCR());
        }
        cursor.close();
        return result;
    }

    // 取得与某个HCID相关的所有记录
    public Double getCBSum_Exchanged(String hcid) {
        Double result=0d;
        List<CB_Order> orderList=new CB_OrderDAO(context).getByHcid(hcid);
        for(CB_Order cbo:orderList) {
            if (cbo.getIsbuy()) {
                String querystring = hash_buyer_COLUMN + "='" + cbo.getHash() + "' AND "+status_COLUMN+">=30";
                // 執行查詢
                Cursor cursor = db.query(
                        TABLE_NAME, null, querystring, null, null, null, null, null);
                while (cursor.moveToNext()) {
                    result += getRecord(cursor).getCB_Amount();
                }
                cursor.close();
            }
        }
        return result;
    }

    public String getStrCBSum_Exchanged(String hcid) {
        String result="";
        List<CB_Order> orderList=new CB_OrderDAO(context).getByHcid(hcid);
        result+=".size():"+orderList.size()+"\n"+orderList.get(0).getHash()+"\n\n";
        for(CB_Order cbo:orderList) {
            if (cbo.getIsbuy()) {
                String querystring = hash_buyer_COLUMN + "='" + cbo.getHash() + "' AND "+status_COLUMN+">=30";
                // 執行查詢
                Cursor cursor = db.query(
                        TABLE_NAME, null, querystring, null, null, null, null, null);
                while (cursor.moveToNext()) {
                    result += getRecord(cursor).getHash()+"\n"+getRecord(cursor).getStatus()+" "+getRecord(cursor).getCB_Amount()+"\n\n";
                }
                cursor.close();
            }
        }
        return result;
    }

    // 取得与某个HCID相关的所有记录
    public Double getUSDSum_Order(String hcid) {
        Double result=0d;
        //Double result=new RequestActivationDAO(context).getActivationFeeUSD(hcid);
        List<CB_Order> orderList=new CB_OrderDAO(context).getByHcid(hcid);
        for(CB_Order cbo:orderList) {
            if (cbo.getIsbuy()) {
                if(cbo.getStatus()<=30)
                result+=cbo.getAmount();
            }
        }
        return result/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
    }
    // 取得与某个HCID相关的所有记录
    public Double getUSDSum_Sell(String hcid) {
        Double result=0d;
        List<CB_Order> orderList=new CB_OrderDAO(context).getByHcid(hcid);
        for(CB_Order cbo:orderList) {
            if (!cbo.getIsbuy()) {
                if(cbo.getStatus()<=30)
                    result+=cbo.getAmount();
            }
        }
        return result/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
    }
    // 取得与某个HCID相关的所有记录
    public Double getCBSum_Sold(String hcid) {
        Double result=0d;
        List<CB_Order> orderList=new CB_OrderDAO(context).getByHcid(hcid);
        for(CB_Order cbo:orderList) {
            if (!cbo.getIsbuy()) {
                String querystring = hash_seller_Column + "='" + cbo.getHash() + "' AND "+status_COLUMN+">=30";
                // 執行查詢
                Cursor cursor = db.query(
                        TABLE_NAME, null, querystring, null, null, null, null, null);
                while (cursor.moveToNext()) {
                    result += getRecord(cursor).getCB_Amount();
                }
                cursor.close();
            }
        }
        return result;
    }
    public Double getCR() {
        Double result=Double.parseDouble(context.getResources().getString(R.string.convertrate));
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, KEY_ID+" DESC", null);

        if(cursor.moveToFirst()) {
            result = getRecord(cursor).getCR();
        }
        cursor.close();
        return result;
    }
    public List<CB_Trading> getListByCBOrderHash(String hash) {
        // 準備回傳結果用的物件
        List<CB_Trading> result = new ArrayList<>();
        CB_Trading cbt = null;
        // 使用編號為查詢條件
        String SELECTION = hash_buyer_COLUMN + "='" + hash +"' OR "+hash_seller_Column+"='"+hash+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTION, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            // 讀取包裝一筆資料的物件
            result.add(getRecord(cursor));
        }
        // 關閉Cursor物件
        cursor.close();
        // 回傳結果
        return result;
    }

    // 取得与某个HCID相关的所有记录
    public List<CB_Trading> getByOrderHash(String hash) {
        // 準備回傳結果用的物件
        List<CB_Trading> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hash_seller_Column + "='" + hash+"' OR "+ hash_buyer_COLUMN +"='"+hash+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public double getBalanceByHash(String hash){
        double balance=0d;
        CB_TradingDAO cbDAO=new CB_TradingDAO(context);
        List<CB_Trading> cblist=new ArrayList<>();
        cblist=cbDAO.getByOrderHash(hash);
        for (CB_Trading cb:cblist){
            if(cb.getHash_buyer().equals(hash)){
                balance+=cb.getCB_Amount();
            }
            if(cb.getHash_seller().equals(hash)){
                balance-=cb.getCB_Amount();
            }
        }
        return balance;
    }

    public double getAmount_Exchanged(String hash){
        double amount=0d;
        CB_TradingDAO cbDAO=new CB_TradingDAO(context);
        List<CB_Trading> cblist=new ArrayList<>();
        cblist=cbDAO.getByOrderHash(hash);
        for (CB_Trading cb:cblist){
            if(cb.getHash_buyer().equals(hash)){
                amount+=cb.getAmount();
            }
        }
        return amount;
    }

    public double getAmount_Sold(String hash){
        double amount=0d;
        CB_TradingDAO cbDAO=new CB_TradingDAO(context);
        List<CB_Trading> cblist=new ArrayList<>();
        cblist=cbDAO.getByOrderHash(hash);
        for (CB_Trading cb:cblist){
            if(cb.getHash_seller().equals(hash)){
                amount+=cb.getAmount();
            }
        }
        return amount;
    }

    // 把Cursor目前的資料包裝為物件
    public CB_Trading getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        CB_Trading result = new CB_Trading();
        result.setId(cursor.getLong(0));
        result.setHash_seller(cursor.getString(1));
        result.setHash_buyer(cursor.getString(2));
        result.setAmount(cursor.getDouble(3));
        result.setCurrency(cursor.getString(4));
        result.setCashflow_1(cursor.getString(5));
        result.setCashflow_2(cursor.getString(6));
        result.setCB_Amount(cursor.getDouble(7));
        result.setCR(cursor.getDouble(8));
        result.setHash(cursor.getString(9));
        result.setExchnge_fee(cursor.getDouble(10));
        result.setStatus(cursor.getInt(11));
        result.setNote(cursor.getString(12));
        result.setBlockIndex(cursor.getLong(13));
        result.setCreateTime(cursor.getLong(14));
        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }

}