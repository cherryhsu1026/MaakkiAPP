package com.maakki.HyperConnectivity;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class Blockchain {
    private String HCID;
    private int difficulty;
    public List<Block> blocks;
    private BlockchainDAO bcd;
    private Block firstBlock;

    public List<Block> getBlockList(){
        return blocks;
    }

    public void setBlockList(List<Block> blockList){
        blocks=blockList;
        firstBlock=blocks.get(0);
    }
    public Blockchain(int difficulty) {
        this.difficulty = difficulty;
        blocks = new ArrayList<>();
        firstBlock=new Block();
    }
    public Blockchain() {
        this.difficulty = 4;
        blocks = new ArrayList<>();
    }
    public Blockchain(int difficulty, Context context) {
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        this.difficulty = difficulty;
        blocks = new ArrayList<>();
        bcd=new BlockchainDAO(context);
        if(bcd.getCount()==0){
            // create the first block
            //Block b = new Block(0, mMemID, System.currentTimeMillis(), null, "N/A","First Block");
            //String datatype="N/A";
            String datatype="Registration";
            //String first_block_data="First Block";
            String first_block_data="HyperConn 1A26AEBAF026CA9936C86B2987EF92E5 MDwwDQYJKoZIhvcNAQEBBQADKwAwKAIhAMnnljmwmPXdMRzwx/CVUrTDLKCpsS4gep6nABNpRpdrAgMBAAE=";
            Block b = new Block(0, HCID, System.currentTimeMillis(), null, datatype,first_block_data);
            b.mineBlock(difficulty);
            firstBlock=b;
            blocks.add(b);
        }else{
            blocks=bcd.getAll();
        }
    }

    public Blockchain(int difficulty,Block block) {
        this.difficulty = difficulty;
        blocks = new ArrayList<>();
        firstBlock=block;
        blocks.add(block);
    }

    public Block getFirstBlock(){
        return firstBlock;
    }

    /*public int getDifficulty() {
        return difficulty;
    }*/

    public Block latestBlock() {
        return blocks.get(blocks.size() - 1);
    }

    public Block newBlock(String maker,String datatype,String data) {
        Block latestBlock = latestBlock();
        return new Block(latestBlock.getIndex() + 1, maker , System.currentTimeMillis(),
                latestBlock.getHash(),datatype, data);
    }

    public void addExistedBlock(Block b){
        if (b != null) {
            blocks.add(b);
        }
    }

    public Block addBlock(Block b) {
        if (b != null) {
            b.mineBlock(difficulty);
            blocks.add(b);
        }
        return b;
    }

    public boolean isFirstBlockValid() {
        Block firstBlock = blocks.get(0);

        if (firstBlock.getIndex() != 0) {
            return false;
        }

        if (firstBlock.getPreviousHash() != null) {
            return false;
        }

        return firstBlock.getHash() != null &&
                Block.calculateHash(firstBlock).equals(firstBlock.getHash());

        /*if (firstBlock.getHash() == null ||
                !Block.calculateHash(firstBlock).equals(firstBlock.getHash())) {
            return false;
        }
        return true;*/
    }

    public boolean isFirstBlockValid(Block firstBlock) {
        //Block firstBlock = blocks.get(0);

        if (firstBlock.getIndex() != 0) {
            return false;
        }

        if (firstBlock.getPreviousHash() != null) {
            return false;
        }

        return firstBlock.getHash() != null &&
                Block.calculateHash(firstBlock).equals(firstBlock.getHash());

        /*if (firstBlock.getHash() == null ||
                !Block.calculateHash(firstBlock).equals(firstBlock.getHash())) {
            return false;
        }
        return true;*/
    }

    public boolean isValidNewBlock(Block newBlock, Block previousBlock) {
        if (newBlock != null  &&  previousBlock != null) {
            if (previousBlock.getIndex() + 1 != newBlock.getIndex()) {
                return false;
            }

            if (newBlock.getPreviousHash() == null  ||
                    !newBlock.getPreviousHash().equals(previousBlock.getHash())) {
                return false;
            }

            if (newBlock.getHash() == null  ||
                    !Block.calculateHash(newBlock).equals(newBlock.getHash())) {
                return false;
            }
            return previousBlock.getHash() != null &&
                    Block.calculateHash(previousBlock).equals(previousBlock.getHash());
            /*if (previousBlock.getHash() == null  ||
                    !Block.calculateHash(previousBlock).equals(previousBlock.getHash())) {
                return false;
            }
            return true;*/
        }

        return false;
    }

    public int CheckValidNewBlock(Block newBlock, Block previousBlock) {
        if (newBlock != null  &&  previousBlock != null) {
            if (previousBlock.getIndex() + 1 != newBlock.getIndex()) {
                return 1;//index error
            }

            if (newBlock.getPreviousHash() == null  ||
                    !newBlock.getPreviousHash().equals(previousBlock.getHash())) {
                return 2;//hash incorespondent
            }

            if (newBlock.getHash() == null  ||
                    !Block.calculateHash(newBlock).equals(newBlock.getHash())) {
                return 3;//newBlock.hash error
            }
            if (previousBlock.getHash() == null  ||
                    !Block.calculateHash(previousBlock).equals(previousBlock.getHash())) {
                return 4;//previousBlock.hash error
            }
            return 0;//true
        }

        return 5;//Block null
    }

    public String reasonNotValidNewBlock(Block newBlock, Block previousBlock) {
        String result="not available!";
        if (newBlock != null  &&  previousBlock != null) {
            if (previousBlock.getIndex() + 1 != newBlock.getIndex()) {
                result = "index error";
            }

            if (newBlock.getPreviousHash() == null  ||
                    !newBlock.getPreviousHash().equals(previousBlock.getHash())) {
                result = "PreviousHash error";
            }

            if (newBlock.getHash() == null  ||
                    !Block.calculateHash(newBlock).equals(newBlock.getHash())) {
                result =  "CalculateHash error"+"\n"+
                        Block.calculateHash(newBlock)+"\n"+
                        newBlock.getHash();
            }
            if (previousBlock.getHash() == null  ||
                    !Block.calculateHash(previousBlock).equals(previousBlock.getHash())) {
                result =  "CalculatePreviousHash error"+"\n"+
                        Block.calculateHash(previousBlock)+"\n"+
                        previousBlock.getHash();
            }
        }
        /*result=Block.calculateHash(newBlock)+"\n"+
                newBlock.getHash();*/
        return result;
    }

    public boolean isValidBlock(Block block) {
        if (block != null) {
            if (block.getMaker() == null) {
                return false;
            }

            if (block.getIndex() == 0 & block.getPreviousHash() != null) {
                return false;
            }

            if (block.getIndex() > 0 & block.getPreviousHash() == null) {
                return false;
            }

            if (block.getHash() == null) {
                return false;
            }

            if (block.getTimestamp() ==0) {
                return false;
            }

            if (block.getDatatype() ==null) {
                return false;
            }

            return block.getData() != null;

            /*if (block.getData() ==null) {
                return false;
            }
            return true;*/
        }
        return false;
    }

    public boolean isBlockChainValid() {
        if (!isFirstBlockValid()) {
            return false;
        }
        for (int i = 1; i < blocks.size(); i++) {
            Block currentBlock = blocks.get(i);
            Block previousBlock = blocks.get(i - 1);
            if (!isValidNewBlock(currentBlock, previousBlock)) {
                return false;
            }
        }
        return true;
    }
    public String  reasonBlockChainNotValid() {
        String result="";
        if (!isFirstBlockValid()) {
            result= "!isFirstBlockValid()";
        }
        for (int i = 1; i < blocks.size(); i++) {
            Block currentBlock = blocks.get(i);
            Block previousBlock = blocks.get(i - 1);
            if (!isValidNewBlock(currentBlock, previousBlock)) {
                result= "Block#"+currentBlock.getIndex()+" "+reasonNotValidNewBlock(currentBlock, previousBlock);
            }
            /*if(i<3760 & i>3750){
                result+= "Block#"+currentBlock.getIndex()+"\n"+reasonNotValidNewBlock(currentBlock, previousBlock)+"\n\n";
            }*/
        }
        return result;
    }
    public String toString() {
        StringBuilder builder = new StringBuilder();

        for (Block block : blocks) {
            builder.append(block).append("\n");
        }

        return builder.toString();
    }
    public int count(){
        return blocks.size();
    }

    public Block get(long index){
        return blocks.get(Integer.parseInt(String.valueOf(index)));
    }
}
