package com.maakki.HyperConnectivity;

        import android.content.ContentValues;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;

        import java.util.ArrayList;
        import java.util.Date;
        import java.util.List;

public class Envelope_Info_recordDAO {
    // 表格名稱
    public static final String TABLE_NAME = "Envelope_Info_record";
    // 編號表格欄位名稱，固定不變
    public static final String KEY_Id = "_id";
    public static final String ad_hash_Column = "ad_hash";
    public static final String record_hash_column = "record_hash";
    public static final String publisher_id_Column = "publisher_id";
    public static final String subscriber_id__Column = "subscriber_id";
    public static final String cbperclickColumn = "cbperclick";
    public static final String isConfirmed_Column = "isConfirmed";
    public static final String CreateTime_COLUMN = "_CreateTime";
    Context context;
    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_Id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    ad_hash_Column + " TEXT NOT NULL, " +
                    record_hash_column + " TEXT NOT NULL, " +
                    publisher_id_Column + " TEXT NOT NULL, " +
                    subscriber_id__Column + " TEXT NOT NULL, " +                    
                    cbperclickColumn + " REAL NOT NULL, " +                    
                    isConfirmed_Column + " TEXT NOT NULL, " +
                    CreateTime_COLUMN + " REAL NOT NULL) ";
    // 資料庫物件
    private SQLiteDatabase db;
    // 建構子，一般的應用都不需要修改
    public Envelope_Info_recordDAO(Context context) {
        this.context=context;
        db = Envelope_InfoDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public Envelope_Info_record insert(Envelope_Info_record eir) {
        // 建立準備新增資料的ContentValues物件
        if(!update(eir)){
            ContentValues cv = new ContentValues();
            cv.put(ad_hash_Column, eir.getAd_hash());
            cv.put(record_hash_column, eir.getRecord_hash());
            cv.put(publisher_id_Column, eir.getPublisher_id());
            cv.put(subscriber_id__Column, eir.getSubscriber_id());
            cv.put(cbperclickColumn, eir.getCBPerClick());
            cv.put(isConfirmed_Column, eir.getIsConfirmed().toString());
            cv.put(CreateTime_COLUMN, new Date().getTime());
            // 新增一筆資料並取得編號
            // 第一個參數是表格名稱
            // 第二個參數是沒有指定欄位值的預設值
            // 第三個參數是包裝新增資料的ContentValues物件
            long id = db.insert(TABLE_NAME, null, cv);

            // 設定編號
            eir.setId(id);
        }
        // 回傳結果
        return eir;
    }

    // 修改參數指定的物件
    public boolean update(Envelope_Info_record eir) {
        // 建立準備修改資料的ContentValues物件
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        ContentValues cv = new ContentValues();
        cv.put(KEY_Id,eir.getId());
        cv.put(ad_hash_Column, eir.getAd_hash());
        cv.put(record_hash_column, eir.getRecord_hash());
        cv.put(publisher_id_Column, eir.getPublisher_id());
        cv.put(subscriber_id__Column, eir.getSubscriber_id());
        cv.put(cbperclickColumn, eir.getCBPerClick());
        cv.put(isConfirmed_Column, eir.getIsConfirmed().toString());
        cv.put(CreateTime_COLUMN, eir.getCreateTime());
        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = record_hash_column + "='" + eir.getRecord_hash()+"'";
        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    public Envelope_Info_record setConfirmed(String hash) {
        ContentValues cv = new ContentValues();
        Envelope_Info_record eir=getByRecord_Hash(hash);
        cv.put(isConfirmed_Column, "true");
        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = record_hash_column + "='" + eir.getRecord_hash()+"'";
        // 執行修改資料並回傳修改的資料數量是否成功
        db.update(TABLE_NAME, cv, where, null);
        return get(eir.getId());
    }

    public Envelope_Info_record getByRecord_Hash(String hash) {
        // 準備回傳結果用的物件
        Envelope_Info_record Envelope_Info_record = null;
        // 使用編號為查詢條件
        String SELECTSTRING = record_hash_column + "='" + hash+"'";
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            Envelope_Info_record = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return Envelope_Info_record;
    }
    public int getCoutByAdHash(String ad_hash) {
        // 準備回傳結果用的物件
        int result=0;
        // 使用編號為查詢條件
        String SELECTSTRING = ad_hash_Column + "='" + ad_hash +"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            result+=1;
        }

        // 關閉Cursor物件
        cursor.close();
        // 回傳結果
        return result;
    }

    public Double getCB_AmountByAdHash(String ad_hash) {
        // 準備回傳結果用的物件
        Double result=0d;
        // 使用編號為查詢條件
        String SELECTSTRING = ad_hash_Column + "='" + ad_hash +"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        while (cursor.moveToNext()) {
            result+=(getRecord(cursor)).getCBPerClick();
        }

        // 關閉Cursor物件
        cursor.close();
        // 回傳結果
        return result;
    }
    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_Id + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    public boolean deleteByAdHash(String hash) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = ad_hash_Column + "='" + hash +"'";
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    // 刪除參數指定編號的資料

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }

    public void clear() {
        for(Envelope_Info_record ra:getAll()){
            delete(ra.getId());
        }
    }

    // 讀取所有記事資料
    public List<Envelope_Info_record> getAll() {
        List<Envelope_Info_record> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null,CreateTime_COLUMN+" DESC" , null);
        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public Envelope_Info_record getAd_NotConfirmed(String hcid) {
        Envelope_Info_record result = null;
        List<Envelope_Info_record> list = new ArrayList<>();
        String SELECTIONSTRING = subscriber_id__Column+"='"+hcid+"'";
        String ORDERSTRING =cbperclickColumn + " DESC";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTIONSTRING, null, null, null , ORDERSTRING);

        while (cursor.moveToNext()) {
            list.add(getRecord(cursor));
        }
        cursor.close();
        for(Envelope_Info_record eir:list){
            if(!eir.getIsConfirmed()){
                result=eir;
                break;
            }
        }
        return result;
    }

    public List<Envelope_Info_record> getListByAdHash(String hash) {
        List<Envelope_Info_record> result = new ArrayList<>();
        String SELECTIONSTRING = ad_hash_Column+"='"+hash+"'";
        //String ORDERSTRING =cbperclickColumn + " DESC," + CreateTime_COLUMN + " DESC";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTIONSTRING, null, null, null , null);
        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    // 讀取所有記事資料
    // 取得指定編號的資料物件
    public Envelope_Info_record get(long id) {
        // 準備回傳結果用的物件
        Envelope_Info_record Envelope_Info_record = null;
        // 使用編號為查詢條件
        String SELECTSTRING = KEY_Id + "=" + id;
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            Envelope_Info_record = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return Envelope_Info_record;
    }
    // 把Cursor目前的資料包裝為物件
    public Envelope_Info_record getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        Envelope_Info_record result = new Envelope_Info_record();
        result.setId(cursor.getLong(0));
        result.setAd_hash(cursor.getString(1));
        result.setRecord_hash(cursor.getString(2));
        result.setPublisher_id(cursor.getString(3));
        result.setSubscriber_id(cursor.getString(4));
        result.setCBPerClick(cursor.getDouble(5));
        result.setIsConfirmed(Boolean.parseBoolean(cursor.getString(6)));
        result.setCreateTime(cursor.getLong(7));
        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME , null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }

}
