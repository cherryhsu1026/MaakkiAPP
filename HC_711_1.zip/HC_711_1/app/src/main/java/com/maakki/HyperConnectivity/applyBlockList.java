package com.maakki.HyperConnectivity;


import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;

/**
 * Created by ryan on 2017/7/17.
 */

public class applyBlockList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title, tv_message, time, tv_nothing;
    ImageView icon;//,iv_nothing;
    Integer count;
    FloatingActionButton fab;

    private boolean isAscending = false;
    private Context context;
    private List<applyBlock> listapplyBlock;//, newlist;
    private applyBlockDAO applyblockDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private applyBlockAdapter adapter;
    private BroadcastReceiver receiver;
    //private ImageLoaderConfiguration config;
    //private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            switch (menuItem.getItemId()) {
                case R.id.envelope_info:
                    Intent intent = new Intent(applyBlockList.this, Envelope_InfoList.class);
                    startActivity(intent);
                    break;
                case R.id.delete:
                    AlertDialog alertDialog = new AlertDialog.Builder(applyBlockList.this).create();
                    alertDialog.setTitle("将要删除申请记录");
                    alertDialog.setMessage("您确定要删除所有的申请区块的记录吗？");
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "确定",
                            (dialog, which) -> {
                                dialog.dismiss();
                                listview.setVisibility(View.INVISIBLE);
                                fab.setVisibility(View.INVISIBLE);
                                RL_nothing.setVisibility(View.VISIBLE);
                                applyblockDAO.deleteAll();
                                applyblockDAO = new applyBlockDAO(context);
                                listapplyBlock.clear();
                                myToolbar.setTitle("");
                                adapter.notifyDataSetChanged();
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "略过",
                            (dialog, which) -> dialog.dismiss());
                    alertDialog.show();
                    break;
                case R.id.blockchain:
                    Intent i = new Intent(applyBlockList.this, BlockchainList.class);
                    startActivity(i);
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ImageLoaderConfiguration config;
        DisplayImageOptions options;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        ShortcutBadger.with(getApplicationContext()).remove();
        listapplyBlock = new ArrayList<applyBlock>();
        applyblockDAO = new applyBlockDAO(this);
        myToolbar = findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(v -> finish());
        if (applyblockDAO.getCount() > 0) {
            myToolbar.setTitle("List of applyBlock " + applyblockDAO.getCount());
        } else {
            myToolbar.setTitle("");
        }
        //
        options = new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .build();

        config = new ImageLoaderConfiguration.Builder(this)
                .memoryCache(new WeakMemoryCache())
                .defaultDisplayImageOptions(options)
                .build();
        imageLoader.getInstance().init(config);
        imageLoader = ImageLoader.getInstance();
        fab = findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = findViewById(R.id.title);
        tv_message = findViewById(R.id.message);
        time = findViewById(R.id.time);
        icon = findViewById(R.id.icon);
        listview = findViewById(R.id.listview);
        RL_nothing = findViewById(R.id.RL_nothing);
        //iv_nothing=findViewById(R.id.iv_nothing);
        //iv_nothing.setImageDrawable(getResources().getDrawable(R.drawable.no_nothing));
        tv_nothing = findViewById(R.id.tv_nothing);
        tv_nothing.setText("no applyblock created..");
        count = applyblockDAO.getCount();
        listapplyBlock = applyblockDAO.getAll();
        adapter = new applyBlockAdapter(this, R.layout.list_item, listapplyBlock);
        listview.setAdapter(adapter);
        if (count > 0) {
            Collections.reverse(listapplyBlock);
            //listtop=new ArrayList<PrevNotification>();
            //tv.setText("(" + count.toString() + ")");
            if (count > 10) {
                fab.setVisibility(View.VISIBLE);
            }
            //setOnClick();
            fab.setOnClickListener(v -> {
                if (isAscending) {
                    isAscending = false;
                    fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                } else {
                    isAscending = true;
                    fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                }

                Collections.reverse(listapplyBlock);
                adapter.notifyDataSetChanged();
            });

        } else {
            //tv.setText("");
            RL_nothing.setVisibility(View.VISIBLE);
        }

        //check if isOnlineOnSignalR
        //AsyncCallWS_isOnlineOnSignalR isOnlineOnSignalRTask = new AsyncCallWS_isOnlineOnSignalR();
        //isOnlineOnSignalRTask.execute();
        // your oncreate code should be
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_applyBlockList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

            }
        };
        registerReceiver(receiver, filter);

        //
        RL_nothing.setOnClickListener(v -> finish());
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    public void setOnClick() {
        listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener((parent, v, position, id) -> {
            applyBlock b = listapplyBlock.get(position);
            adapter.notifyDataSetChanged();
            if (swipeDetector.swipeDetected()) {
                v.setVisibility(View.GONE);
                deleteCell(v, position);
                applyblockDAO.delete(b.getId());
                myToolbar.setTitle("List of applyBlocks " + applyblockDAO.getCount());
            }
        });
    }

    private void deleteCell(final View v, final int index) {
        Animation.AnimationListener al = new Animation.AnimationListener() {
            //@Override
            public void onAnimationEnd(Animation arg0) {
                listapplyBlock.remove(index);
                count--;
                if (count < 2) {
                    fab.setVisibility(View.INVISIBLE);
                    if (count < 1) {
                        listview.setVisibility(View.GONE);
                    }
                }
                if (count == 0) {
                    RL_nothing.setVisibility(View.VISIBLE);
                }
                //tv.setText("(" + count + ")");
                ViewHolder vh = (ViewHolder) v.getTag();
                vh.needInflate = true;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        };
        collapse(v, al);
    }

    private void collapse(final View v, Animation.AnimationListener al) {
        final int initialHeight = v.getMeasuredHeight();
        //final int top = v.getTop();
        //Toast.makeText(getApplicationContext(), "collapsetop:"+top , Toast.LENGTH_SHORT).show();
        final int ANIMATION_DURATION = 200;
        Animation anim = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {

                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (al != null) {
            anim.setAnimationListener(al);
        }
        anim.setDuration(ANIMATION_DURATION);
        v.startAnimation(anim);
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_applyblocklist, menu);
        //menu.getItem(0).setVisible(true);
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
    }

    public class applyBlockAdapter extends ArrayAdapter<applyBlock> {
        private LayoutInflater mInflater;
        //private int resId;

        public applyBlockAdapter(Context context, int textViewResourceId, List<applyBlock> objects) {
            super(context, textViewResourceId, objects);
            //this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            //applyBlock ab = (applyBlock)getItem(position);
            applyBlock ab = getItem(position);

            if (convertView == null) {
                //Toast.makeText(applyBlockList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(applyBlockList.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(applyBlockList.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();

            //String dt = ab.getDatatype();
            //holder.datatype = dt;
            int icon = R.drawable.logo;
            //holder.image_icon.setBackgroundColor(ContextCompat.getColor(getApplicationContext(),R.color.colorTitleText));

            Long time = ab != null ? ab.getCreateTime() : 0;
            String fm = "";
            Date date = new Date(time);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            fm = formatter.format(date);
            //new SimpleDateFormat(dateFormat).format(new Date(p.getLastModify()));
            String title = ab != null ? ab.getDatatype() + " " + ab.getHash() : "";
            holder.text_title.setText(title);
            holder.text_message.setText(ab != null ? ab.getData().split(" ")[0] + "\n" + ab.getData().split(" ")[1] + "\n" + ab.getData().split(" ")[2] : "");
            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            //}
            return view;
            //return convertView;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = view.findViewById(R.id.icon);
            vh.text_title = view.findViewById(R.id.title);
            vh.text_message = view.findViewById(R.id.message);
            vh.text_time = view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }


    }



    /*private String getCurrentDate() {
        Date d = new Date();
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        return dt1.format(d.getTime());
    }

    private void showAlertDialog(String title, String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(applyBlockList.this).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                (dialog, which) -> dialog.dismiss());
        alertDialog.show();
    }*/

}
