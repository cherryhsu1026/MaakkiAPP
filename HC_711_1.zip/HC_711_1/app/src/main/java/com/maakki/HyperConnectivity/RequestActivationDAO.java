package com.maakki.HyperConnectivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RequestActivationDAO {
    // 表格名稱
    public static final String TABLE_NAME = "RequestActivation";
    // 編號表格欄位名稱，固定不變
    public static final String KEY_Id = "_id";
    public static final String Applicant_Column = "_applicant";
    public static final String Amount_Column = "_Amount";
    public static final String Currency_Column = "_Currency";
    public static final String Cashflow_1_Column = "_Cashflow_1";
    public static final String Cashflow_2_Column = "_Cashflow_2";
    public static final String BlockIndex_lastupdate_Column = "_blockIndex_lastupdate";
    public static final String Weight_Column = "_Weight";
    public static final String Status_Column = "_Status";
    public static final String Note_Column = "_Note";
    public static final String hash_Column = "_hash";
    public static final String CreateTime_COLUMN = "_CreateTime";
    Context context;
    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_Id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    Applicant_Column + " TEXT NOT NULL, " +
                    Amount_Column + " REAL NOT NULL, " +
                    Currency_Column + " TEXT NOT NULL, " +
                    Cashflow_1_Column + " TEXT NOT NULL, " +
                    Cashflow_2_Column + " TEXT NOT NULL, " +
                    BlockIndex_lastupdate_Column + " INTEGER NOT NULL, " +
                    Weight_Column + " INTEGER NOT NULL, " +
                    Status_Column + " INTEGER NOT NULL, " +
                    Note_Column + " TEXT NOT NULL, " +
                    hash_Column + " TEXT NOT NULL, " +
                    CreateTime_COLUMN + " REAL NOT NULL) ";
    // 資料庫物件
    private SQLiteDatabase db;
    // 建構子，一般的應用都不需要修改
    public RequestActivationDAO(Context context) {
        this.context=context;
        db = RequestActivationDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    public Double getActivationFeeUSD(String hcid){
        Double result=0d;
        RequestActivation ra=null;
        String SELECTSTRING = Applicant_Column + "='" + hcid+"' AND "+Status_Column+">=26";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);
        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            if(getRecord(cursor).getCurrency().equals("USD")){
                result += getRecord(cursor).getAmount();
            }else if(getRecord(cursor).getCurrency().equals("RMB")){
               result += getRecord(cursor).getAmount()/ Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
            }
        }
        return result;
    }

    public RequestActivation getByHash(String hash) {
        RequestActivation result=null;
        // 使用編號為查詢條件
        String SELECTSTRING = hash_Column + "='" + hash+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);
        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }

        // 關閉Cursor物件
        cursor.close();
        // 回傳結果
        return result;
    }

    // 新增參數指定的物件
    public RequestActivation insert(RequestActivation requestactivation) {
        // 建立準備新增資料的ContentValues物件
        ContentValues cv = new ContentValues();
        //long createtime=new Date().getTime();
        // 加入ContentValues物件包裝的新增資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        if(!update(requestactivation)){
            if(!isActivating(requestactivation.getApplicant())){
                cv.put(Applicant_Column, requestactivation.getApplicant());
                cv.put(Amount_Column, requestactivation.getAmount());
                cv.put(Currency_Column, requestactivation.getCurrency());
                cv.put(Cashflow_1_Column, requestactivation.getCashflow_1());
                cv.put(Cashflow_2_Column, requestactivation.getCashflow_2());
                cv.put(BlockIndex_lastupdate_Column, requestactivation.getBlockIndex_lastupdate());
                cv.put(Weight_Column, requestactivation.getWeight());
                cv.put(Status_Column, requestactivation.getStatus());
                cv.put(Note_Column, requestactivation.getNote());
                cv.put(hash_Column, requestactivation.getHash());
                cv.put(CreateTime_COLUMN, requestactivation.getCreateTime());
                // 新增一筆資料並取得編號
                // 第一個參數是表格名稱
                // 第二個參數是沒有指定欄位值的預設值
                // 第三個參數是包裝新增資料的ContentValues物件
                long id = db.insert(TABLE_NAME, null, cv);

                // 設定編號
                requestactivation.setId(id);
            }
        }else{
            update(requestactivation);
        }
        // 回傳結果
        return requestactivation;
    }

    // 修改參數指定的物件
    public boolean update(RequestActivation requestactivation) {
        // 建立準備修改資料的ContentValues物件
        //if(requestactivation.getStatus()>=10){
            //RequestActivation ra=getByHash(requestactivation.getHash());
            //Only if new status > old status, RequestActivation can be updated
            //if(requestactivation.getStatus()>ra.getStatus()){*/
                ContentValues cv = new ContentValues();
                // 加入ContentValues物件包裝的修改資料
                // 第一個參數是欄位名稱， 第二個參數是欄位的資料
                cv.put(Applicant_Column, requestactivation.getApplicant());
                cv.put(Amount_Column, requestactivation.getAmount());
                cv.put(Currency_Column, requestactivation.getCurrency());
                cv.put(Cashflow_1_Column, requestactivation.getCashflow_1());
                cv.put(Cashflow_2_Column, requestactivation.getCashflow_2());
                cv.put(BlockIndex_lastupdate_Column, requestactivation.getBlockIndex_lastupdate());
                cv.put(Weight_Column, requestactivation.getWeight());
                cv.put(Status_Column, requestactivation.getStatus());
                cv.put(Note_Column, requestactivation.getNote());
                cv.put(hash_Column, requestactivation.getHash());
                cv.put(CreateTime_COLUMN, requestactivation.getCreateTime());
                // 設定修改資料的條件為編號
                // 格式為「欄位名稱＝資料」
                String where = hash_Column + "='" + requestactivation.getHash()+"' AND "+Status_Column+"<="+requestactivation.getStatus();
                // 執行修改資料並回傳修改的資料數量是否成功
                return db.update(TABLE_NAME, cv, where, null) > 0;
            //}
        //}else{
            //return false;
        //}
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_Id + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    public boolean deleteByHash(String hash) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = hash_Column + "='" + hash +"'";
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    // 刪除參數指定編號的資料

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }

    public void clear() {
        for(RequestActivation ra:getAll()){
            delete(ra.getId());
        }
    }

    /*public long getLastActivation_estimated(long interval){
        long result=interval*(get26Count()+1);
        return  result;
    }*/
    // 讀取所有記事資料
    public List<RequestActivation> getAll() {
        List<RequestActivation> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null,Status_Column +","+ Weight_Column, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }
    // 讀取所有記事資料
    public List<RequestActivation> getAllUnder30() {
        List<RequestActivation> result = new ArrayList<>();
        String SELECTSTRING = Status_Column + "<30" ;

        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null,Status_Column +" DESC,"+ Weight_Column+" DESC", null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public List<RequestActivation> getByStatus(int status) {
        List<RequestActivation> result = new ArrayList<>();
        String SELECTSTRING="";
        String ORDERSTRING="";
        if(status==30){
            SELECTSTRING= Status_Column + "="+status ;
            ORDERSTRING=BlockIndex_lastupdate_Column +" DESC";
        }else{
            SELECTSTRING= Status_Column + "<="+status ;;
            ORDERSTRING=Status_Column +" DESC,"+ Weight_Column+" DESC";
        }
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null,ORDERSTRING, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    // 取得指定編號的資料物件
    public RequestActivation get(long id) {
        // 準備回傳結果用的物件
        RequestActivation requestactivation = null;
        // 使用編號為查詢條件
        String SELECTSTRING = KEY_Id + "=" + id;
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            requestactivation = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return requestactivation;
    }

    public boolean isActivated(String hcid){
        boolean result=false;
        for(RequestActivation ra:getAll()){
            if(ra.getApplicant().equals(hcid) & ra.getStatus()==30){
                result=true;
            }
        }
        return result;
    }
    public boolean isActivating(String hcid){
        boolean result=false;
        for(RequestActivation ra:getAll()){
            if(ra.getApplicant().equals(hcid) & ra.getStatus()>=20 & ra.getStatus()!=41){
                result=true;
                break;
            }
        }
        return result;
    }
    // 把Cursor目前的資料包裝為物件
    public RequestActivation getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        RequestActivation result = new RequestActivation();
        result.setId(cursor.getInt(0));
        result.setApplicant(cursor.getString(1));
        result.setAmount(cursor.getDouble(2));
        result.setCurrency(cursor.getString(3));
        result.setCashflow_1(cursor.getString(4));
        result.setCashflow_2(cursor.getString(5));
        result.setBlockIndex_lastupdate(cursor.getLong(6));
        result.setWeight(cursor.getInt(7));
        result.setStatus(cursor.getInt(8));
        result.setNote(cursor.getString(9));
        result.setHash(cursor.getString(10));
        result.setCreateTime(cursor.getLong(11));
        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME +" WHERE "+Status_Column+"<30 ", null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }
    // 取得資料數量
    public int getCountByApplicant(String hcid) {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME +" WHERE "+Applicant_Column+ "='" + hcid +"'", null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }
    // 取得資料數量
    public int getCountUnder30() {
        int result = 0;
        String SELECTSTRING = Status_Column + "<" + 30;

        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME +" WHERE "+Status_Column+"<30 ", null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }
    public int getRankByWeight(String hcid) {
        int result = 0;

        // 使用編號為查詢條件
        for(RequestActivation ra:getAllUnder30()){
            if(ra.getStatus()==26 & ra.getWeight()>=new MemberDAO(context).getWeight(hcid)){
                result++;
            }
        }
        return result;
    }
    // 取得資料數量
    public int getCountUniqueByHash() {
        int result = 0;
        //"SELECT COUNT(DISTINCT "+hash_Column+") FROM " + TABLE_NAME , null);
        //select count(1) from
        //(select b,max(idCulumn) as idCulumn from tableName group by b) x
        //inner join tableName z on x.idCulumn=z.idCulumn where a between 30 and 50
        String SELETSTRING="select count(1) from (select "+hash_Column+",max("+KEY_Id+") as "+KEY_Id +
                " FROM "+TABLE_NAME+" GROUP BY "+hash_Column+")x inner join "+TABLE_NAME+" z on x."+KEY_Id+"=z."+KEY_Id+
                " WHERE "+Status_Column+" BETWEEN 20 and 29";

        Cursor cursor = db.rawQuery(SELETSTRING, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }
}
