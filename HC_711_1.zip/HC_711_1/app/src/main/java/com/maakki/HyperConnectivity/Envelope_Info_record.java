
package com.maakki.HyperConnectivity;

        import java.security.MessageDigest;
        import java.security.NoSuchAlgorithmException;
        import java.util.Base64;
        import java.util.Date;

public class Envelope_Info_record {
    private String publisher_id,ad_hash,record_hash,subscriber_id;
    private Boolean isConfirmed;
    private Double cbperclick;
    private Long id;
    private long createtime;
    //private String imageStr;

    public Envelope_Info_record() {
        isConfirmed=false;
        cbperclick=0.5;
        createtime=new Date().getTime();
    }

    public void setId( Long id){this.id=id;}
    public Long getId(){return id;}

    public void setAd_hash(String ad_hash) {this.ad_hash=ad_hash;}
    public String getAd_hash() {return ad_hash;}

    public void setPublisher_id(String publisher_id) {this.publisher_id = publisher_id;}
    public String getPublisher_id() {return publisher_id;}

    public String str() {
        return  ad_hash + publisher_id + subscriber_id +createtime ;
    }

    public void setRecord_hash(String record_hash) {this.record_hash=record_hash;}
    public String getRecord_hash() {return record_hash;}

    public void setSubscriber_id(String subscriber_id){this.subscriber_id= subscriber_id;}
    public String getSubscriber_id(){return subscriber_id;}

    public void setCBPerClick(Double cbperclick){this.cbperclick=cbperclick;}
    public double getCBPerClick(){return cbperclick;}

    public void setIsConfirmed(Boolean isConfirmed){this.isConfirmed=isConfirmed;}
    public  Boolean getIsConfirmed(){return  isConfirmed;}

    public long getCreateTime() {
        return createtime;
    }
    public void setCreateTime(long createtime) {this.createtime = createtime;}

    public String calculateHash(Envelope_Info_record eir) {
        if (eir != null) {
            MessageDigest digest = null;
            try {
                digest = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException e) {
                return null;
            }
            String txt = eir.str();
            final byte bytes[] = digest.digest(txt.getBytes());
            final StringBuilder builder = new StringBuilder();
            for (final byte b : bytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    builder.append('0');
                }
                builder.append(hex);
            }
            return builder.toString();
        }
        return null;
    }
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append(ad_hash).append(":").append(record_hash).append(":").
                append(publisher_id).append(":").append(subscriber_id).append(":").
                append(cbperclick).append(":").append(isConfirmed).append(":").
                append(createtime).append(":").append(id);
        return builder.toString();
    }
}



