package com.maakki.HyperConnectivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class FileServerAsyncTask extends
        AsyncTask<Void, Void, String> {

    private Context context;
    private TextView statusText;
    String FILE_DIR = "HyperConn";
    String FILE_NAME = "HyperConn.apk";
     //* @param context
     //* @param statusText

    public FileServerAsyncTask(Context context) {
        this.context = context;
        //this.statusText = (TextView) statusText;
    }

    public File getDevicesDir() {
        File mCropFile = null;

        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File cropdir = new File(Environment.getExternalStorageDirectory(), FILE_DIR);
            if (!cropdir.exists()) {
                cropdir.mkdirs();
            }
            mCropFile = new File(cropdir, FILE_NAME);
        } else {
            File cropdir = new File(context.getFilesDir(), FILE_DIR);
            if (!cropdir.exists()) {
                cropdir.mkdirs();
            }
            mCropFile = new File(cropdir, FILE_NAME);
        }
        return mCropFile;
    }


    private void share_bluetooth() {
        ApplicationInfo app = context.getApplicationInfo();
        String filePath = app.sourceDir;

        // Append file and send Intent
        File originalApk = new File(filePath);
        try {
            //Make new directory in new location
            File tempFile = getDevicesDir();
            //Copy file to new location
            InputStream in = new FileInputStream(originalApk);
            OutputStream out = new FileOutputStream(tempFile);

            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
            Intent intent = new Intent(Intent.ACTION_SEND);
            // MIME of .apk is "application/vnd.android.package-archive".
            // but Bluetooth does not accept this. Let's use "*/*" instead.
            intent.setType("*/*");
            //intent.setType("text/plain");
            Uri apkUri = FileProvider.getUriForFile(context, "com.example.myfileprovider", tempFile);
            intent.putExtra(Intent.EXTRA_STREAM, apkUri);
            context.startActivity(Intent.createChooser(intent, "Share HyperConn via:"));
        } catch (IOException e) {
            //e.printStackTrace();
        }
    }

    @Override
    protected String doInBackground(Void... params) {
        try {
            Log.i("xyz", "file doinback");
            ServerSocket serverSocket = new ServerSocket(8988);
            Socket client = serverSocket.accept();
            /*final File f = new File(
                    Environment.getExternalStorageDirectory() + "/"
                            + FILE_DIR + "/wifip2pshared-"
                            + System.currentTimeMillis() + ".jpg");*/

            final File f = getDevicesDir();

            /*File dirs = new File(f.getParent());

            if (!dirs.exists())
                dirs.mkdirs();
            f.createNewFile();*/


            /*Returns an input stream to read data from this socket*/
            InputStream inputstream = client.getInputStream();
            copyFile(inputstream, new FileOutputStream(f));
            serverSocket.close();
            return f.getAbsolutePath();

        } catch (IOException e) {
            Log.e("xyz", e.toString());
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
     */
    @Override
    protected void onPostExecute(String result) {

        Log.i("xyz", "file onpost");
        Toast.makeText(context, "result"+result, Toast.LENGTH_SHORT).show();

        if (result != null) {
            //statusText.setText("File copied - " + result);
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse("file://" + result), "image/*");
            context.startActivity(intent);
        }

    }

    /*
     * (non-Javadoc)
     *
     * @see android.os.AsyncTask#onPreExecute()
     */
    @Override
    protected void onPreExecute() {

    }


    public static boolean copyFile(InputStream inputStream, OutputStream out) {
        byte buf[] = new byte[1024];
        int len;
        try {
            while ((len = inputStream.read(buf)) != -1) {
                out.write(buf, 0, len);

            }
            out.close();
            inputStream.close();
        } catch (IOException e) {
            return false;
        }
        return true;
    }
}
