package com.maakki.HyperConnectivity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;

public class RAList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title, tv_message, time, tv_nothing;
    ImageView icon, iv_nothing;
    Integer count;
    Menu menu;
    FloatingActionButton fab;
    private Long notification_id = 0l, notification_millisecs = 0l;
    private boolean isCBenvelope = false, isAscending = false;
    private String HCID,strAccountname;
    private Context context;
    private List<RequestActivation> listRequestActivation, newlist;
    private RequestActivationDAO raDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private RAAdapter adapter;
    private BroadcastReceiver receiver;
    //private EditText et_account_name,et_account_no,et_bank_name,et_bank_branch;
    //View view;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.hclist:
                    menuItem.setVisible(false);
                    Intent i = new Intent(RAList.this, HCList.class);
                    startActivity(i);
                    //renewlist(30);
                    break;
                case R.id.status_26:
                    menuItem.setVisible(false);
                    menu.getItem(2).setVisible(true);
                    //Intent i = new Intent(RAList.this, HCList.class);
                    //startActivity(i);
                    renewlist(26);
                    break;
                case R.id.status_30:
                    menuItem.setVisible(false);
                    menu.getItem(1).setVisible(true);
                    //Intent i = new Intent(RAList.this, HCList.class);
                    //startActivity(i);
                    renewlist(30);
                    break;
                case R.id.delete:
                    AlertDialog alertDialog = new AlertDialog.Builder(RAList.this).create();
                    alertDialog.setTitle("将要删除申请激活的记录");
                    alertDialog.setMessage("您确定要删除所有申请激活的记录吗？");
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "确定",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    listview.setVisibility(View.INVISIBLE);
                                    fab.setVisibility(View.INVISIBLE);
                                    RL_nothing.setVisibility(View.VISIBLE);
                                    raDAO.deleteAll();
                                    raDAO=new RequestActivationDAO(context);
                                    listRequestActivation.clear();
                                    myToolbar.setTitle("");
                                    adapter.notifyDataSetChanged();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "略过",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        ShortcutBadger.with(getApplicationContext()).remove();
        listRequestActivation = new ArrayList<RequestActivation>();
        raDAO = new RequestActivationDAO(this);
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();

        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        //Toast.makeText(context,"CB "+raDAO.getCount()+" "+ Utils.formatDoubleToString(raDAO.getBalanceByHCID(HCID)),Toast.LENGTH_LONG).show();
        //myToolbar.setTitle("CB "+raDAO.getCount());
        String strtoolbar=getResources().getString(R.string.RAList_toolbar)+" ";
        if (raDAO.getCount() > 0) {
            myToolbar.setTitle(strtoolbar + raDAO.getCount());
        } else {
            myToolbar.setTitle("");
        }

        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing = (RelativeLayout) findViewById(R.id.RL_nothing);
        //iv_nothing = (ImageView) findViewById(R.id.iv_nothing);
        //iv_nothing.setImageDrawable(getResources().getDrawable(R.drawable.no_cb));
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText(getResources().getString(R.string.RL_nothing_noRA));
        count = raDAO.getCountUnder30();
        listRequestActivation = raDAO.getAllUnder30();
        adapter = new RAAdapter(this, R.layout.list_item, listRequestActivation);
        listview.setAdapter(adapter);
        if (count > 0) {
            //Collections.reverse(listRequestActivation);
        } else {
            RL_nothing.setVisibility(View.VISIBLE);
        }
        /*IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_RAList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                raDAO = new RequestActivationDAO(context);
                if (raDAO.getCount() != count) {
                    renewlist();
                }
            }
        };
        registerReceiver(receiver, filter);*/
        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        if (getIntent().getExtras() != null) {
            Bundle bundle = this.getIntent().getExtras();
            feedbackRemittance(new RequestActivationDAO(context).getByHash(bundle.getString("Message")));
        }else{
            Async_checkData checkDataTask=new Async_checkData();
            checkDataTask.execute();
        }
        setOnClick();
    }

    @Override
    protected void onStop() {
        super.onStop();
        //finish();
    }

    public void setOnClick() {
        //listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                RequestActivation ra = listRequestActivation.get(position);
                if(ra.getApplicant().equals(HCID)){
                    if(ra.getStatus()==20){
                        feedbackRemittance(ra);
                    }
                }
                if(ra.getCashflow_1().equals(HCID)){
                    if(ra.getStatus()==20||ra.getStatus()==21){
                        confirmRemittance_cf1_part1(ra);
                    }
                }
                if(ra.getCashflow_2().equals(HCID)){
                    if(ra.getStatus()==22){
                        confirmRemittance_cf2(ra);
                    }
                }
                if(new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)){
                    if(ra.getStatus()==26) {
                        confirmActivation(ra);
                    }
                }
            }
        });
    }

    private void confirmActivation(RequestActivation ra){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = RAList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_activation, null);
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy.MM.dd");
        String message1=dt1.format(ra.getCreateTime())+"\n"+ra.getApplicant();
        TextView tv_message1 = (TextView) view.findViewById(R.id.tv_message1);
        tv_message1.setText(message1);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //Update RequestActivation status
                        String note="Done";
                        String datatype = "Activation";
                        String data = ra.getHash() + " " + ra.getApplicant() + " 30 " + ra.getCashflow_1() + " " + ra.getAmount() + " RMB " + ra.getCreateTime() + " " + note;
                        makeBlock(datatype,data);
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        insertRADAO(block);
                        renewlist(26);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void feedbackRemittance(RequestActivation ra){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = RAList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.feedback_remittance_dialog, null);
        String bankdata=getResources().getString(R.string.bankdata_accountname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_accountno_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_bankname_cashflow_1)+"\n"+
                getResources().getString(R.string.bankdata_branchname_cashflow_1);
        TextView tv_message=(TextView) view.findViewById(R.id.tv_message);
        String message=getResources().getString(R.string.feedback_remittance_message)+"\n\n"+bankdata+"\n"+ra.getAmount()+" "+ra.getCurrency();
        tv_message.setText(message);
        TextView tv_submessage=(TextView) view.findViewById(R.id.tv_submessage);
        String submessage=HCID+"\n"+getResources().getString(R.string.feedback_remittance_submessage);
        tv_submessage.setText(submessage);
        strAccountname="";
        final EditText et_account_name=(EditText)view.findViewById(R.id.et_accountname);
        final EditText et_account_no=(EditText)view.findViewById(R.id.et_accountno);
        final EditText et_bank_name=(EditText)view.findViewById(R.id.et_bank_name);
        //final EditText et_bank_branch=(EditText)view.findViewById(R.id.et_bank_branch);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (!et_account_name.getText().toString().trim().isEmpty() &
                                !et_account_no.getText().toString().trim().isEmpty() &
                                !et_bank_name.getText().toString().trim().isEmpty() ) {
                            String note = et_account_name.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" +
                                    et_account_no.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" +
                                    et_bank_name.getText().toString().trim().replace("_", "-").replace(" ", "-") + "_" ;

                            //String note=et_account_name.getText().toString()+" 123";
                            String datatype = "Activation";
                            String data = ra.getHash() + " " + ra.getApplicant() + " 21 " + ra.getCashflow_1() + " " + ra.getAmount() + " RMB " + ra.getCreateTime() + " " + note;
                            //String data=note;
                            makeBlock(datatype,data);
                            Block block = new Block();
                            block.setDatatype(datatype);
                            block.setData(data);
                            insertRADAO(block);
                            renewlist(26);
                        }else{
                            showMessageAlertDialog(getResources().getString(R.string.dialog_input_data_error));
                        }
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public void showMessageAlertDialog(String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        LayoutInflater inflater = RAList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(message);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        alertDialog.show();
    }

    private  void insertRADAO(Block block){
        RequestActivation ra=new RequestActivation();
        //data=hash+" "+HCID+" 20 "+cashflow1+" "+amount+" RMB "+new Date().getTime();
        ra.setHash(block.getData().split(" ")[0]);
        ra.setApplicant(block.getData().split(" ")[1]);
        ra.setStatus(Integer.parseInt(block.getData().split(" ")[2]));
        ra.setCashflow_1(block.getData().split(" ")[3]);
        ra.setAmount(Double.parseDouble(block.getData().split(" ")[4]));
        ra.setCurrency(block.getData().split(" ")[5]);
        ra.setCreateTime(Long.parseLong(block.getData().split(" ")[6]));
        ra.setCashflow_2(getResources().getString(R.string.hcid_cashflow_2));
        ra.setBlockIndex_lastupdate(block.getIndex());
        ra.setWeight(new MemberDAO(context).getWeight(block.getData().split(" ")[1]));
        ra.setNote(block.getData().split(" ")[7]);
        new RequestActivationDAO(context).insert(ra);
    }

    private void confirmRemittance_cf1_part1(RequestActivation ra){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = RAList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_remittance, null);
        String bankdata = ra.getApplicant()+"\n\n"+ra.getNote().replace("_","\n");
        TextView tv_bankdata=(TextView)view.findViewById(R.id.tv_bankdata);
        tv_bankdata.setText(bankdata);

        TextView tv_amount =(TextView)view.findViewById(R.id.tv_amount);
        tv_amount.setText(String.valueOf(ra.getAmount()));
        TextView tv_currency =(TextView)view.findViewById(R.id.tv_currency);
        tv_currency.setText(ra.getCurrency());
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        confirmRemittance_cf1_part2(ra);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void confirmRemittance_cf1_part2(RequestActivation ra){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = RAList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_remittance, null);
        TextView tv_title=(TextView)view.findViewById(R.id.tv_title);
        tv_title.setText(getResources().getString(R.string.confirm_remittance1_title_part2));
        TextView tv_message=(TextView)view.findViewById(R.id.tv_message);
        tv_message.setText(getResources().getString(R.string.confirm_remittance1_message_part2));
        TextView tv_submessage=(TextView)view.findViewById(R.id.tv_submessage);
        tv_submessage.setText(getResources().getString(R.string.confirm_remittance1_submessage_par2));
        //String[] bankdata=ra.getNote().split("_");
        TextView tv_bankdata=(TextView)view.findViewById(R.id.tv_bankdata);
        String bankdata=getResources().getString(R.string.bankdata_accountname_cashflow_2)+"\n"+
                getResources().getString(R.string.bankdata_accountno_cashflow_2)+"\n"+
                getResources().getString(R.string.bankdata_bankname_cashflow_2)+"\n"+
                getResources().getString(R.string.bankdata_branchname_cashflow_2);
        tv_bankdata.setText(bankdata);
        TextView tv_amount =(TextView)view.findViewById(R.id.tv_amount);
        tv_amount.setText(String.valueOf(ra.getAmount()));
        TextView tv_currency =(TextView)view.findViewById(R.id.tv_currency);
        tv_currency.setText(ra.getCurrency());
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String note=getResources().getString(R.string.bankdata_accountname_cashflow_1)+"_"+
                                getResources().getString(R.string.bankdata_accountno_cashflow_1)+"_"+
                                getResources().getString(R.string.bankdata_bankname_cashflow_1)+"_"+
                                getResources().getString(R.string.bankdata_branchname_cashflow_1);
                        ra.setNote(note);
                        ra.setStatus(22);
                        //new RequestActivationDAO(context).update(ra);
                        String datatype="Activation";
                        String data=ra.getHash()+" "+ra.getApplicant()+" 22 "+ra.getCashflow_2()+" "+ra.getAmount()+" RMB "+ra.getCreateTime()+" "+note;
                        makeBlock(datatype,data);
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        insertRADAO(block);
                        renewlist(26);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void confirmRemittance_cf2(RequestActivation ra){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = RAList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.confirm_remittance, null);
        TextView tv_title=(TextView)view.findViewById(R.id.tv_title);
        tv_title.setText(getResources().getString(R.string.confirm_remittance2_title));
        String bankdata=ra.getNote().replace("_","\n");

        TextView tv_bankdata=(TextView)view.findViewById(R.id.tv_bankdata);
        tv_bankdata.setText(bankdata);

        TextView tv_amount =(TextView)view.findViewById(R.id.tv_amount);
        tv_amount.setText(String.valueOf(ra.getAmount()));
        TextView tv_currency =(TextView)view.findViewById(R.id.tv_currency);
        tv_currency.setText(String.valueOf(ra.getCurrency()));
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_confirm),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String note=getResources().getString(R.string.note_status26);
                        ra.setNote(note);
                        String datatype="Activation";
                        String data=ra.getHash()+" "+ra.getApplicant()+" 26 "+ra.getCashflow_1()+" "+ra.getAmount()+" RMB "+ra.getCreateTime()+" "+note;
                        makeBlock(datatype,data);
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        insertRADAO(block);
                        renewlist(26);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private void check_waiting_situation(RequestActivation ra){

    }

    @Override
    protected void onDestroy() {
        /*if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }*/

        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu=menu;
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_ralist, menu);
        //menu.getItem(0).setVisible(true);
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class RAAdapter extends ArrayAdapter<RequestActivation> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public RAAdapter(Context context, int textViewResourceId, List<RequestActivation> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            RequestActivation ra = (RequestActivation) getItem(position);

            if (convertView == null) {
                //Toast.makeText(RAList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item_ralist, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                view = mInflater.inflate(R.layout.list_item_ralist, parent, false);
                setViewHolder(view);
            } else {
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();
            int icon = R.drawable.ic_launcher_round;
            String title = ra.getAmount() +" "+ra.getCurrency()+" #" + ra.getBlockIndex_lastupdate() + " " + ra.getStatus();
            holder.text_title.setText(title);
            String message="";
            //if(ra.getStatus()==20||ra.getStatus()==26){
                message=ra.getWeight()+" / ";
                if(ra.getStatus()==26){
                    message+=getResources().getString(R.string.note_status26).replace("_"," ")+" / "+getEstimatedDate(position);
                }else if(ra.getStatus()==20){
                    message+=getResources().getString(R.string.note_status20).replace("_"," ");
                }else if(ra.getStatus()==30){
                    message+=getResources().getString(R.string.note_status30).replace("_"," ");
                }else {
                    message+=getResources().getString(R.string.note_status_others).replace("_"," ");
                }
            //}
            //message += "\n" + ra.getApplicant() +" "+raDAO.getCountByApplicant(ra.getApplicant());
            message += "\n" + ra.getApplicant() ;

            holder.text_message.setText(message);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            String fm = formatter.format(ra.getCreateTime());
            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            return view;
        }
        public String getEstimatedDate(int position){
            Date d = new Date();
            Long startdate=d.getTime()+24*60*60*1000;
            SimpleDateFormat dt1 = new SimpleDateFormat("yyyy.MM.dd");
            long interval_time=1000*60*60*24*(position*Integer.parseInt(getResources().getString(R.string.intervalDays_activation_estimation)));
            return dt1.format(startdate+interval_time);
        }
        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

    private class Async_checkData extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            return checkData();
        }

        @Override
        protected void onPostExecute(Boolean result) {
            //RL_nothing.setVisibility(View.GONE);
            //if(result){
                renewlist(26);
            //}
        }

        @Override
        protected void onPreExecute() {
            //RL_nothing.setVisibility(View.VISIBLE);
            //tv_nothing.setText(getResources().getString(R.string.Async_checkdata_Onpre));
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private Boolean checkData() {
        BlockchainDAO blockchainDAO = new BlockchainDAO(context);
        raDAO.clear();
        for (Block block : blockchainDAO.getAll()) {
            if (block.getDatatype().equals("Activation")) {
                insertRADAO(block);
            }
        }
        for (Block block : new BlockDAO(context).getAll()) {
            if (block.getDatatype().equals("Activation")) {
                insertRADAO(block);
            }
        }
        for(RequestActivation ra:raDAO.getAll()){
            ra.setWeight(new MemberDAO(context).getWeight(ra.getApplicant()));
            raDAO.update(ra);
        }
        return true;
    }

    private void renewlist(int status){
        listRequestActivation.clear();
        for(RequestActivation cb:new RequestActivationDAO(context).getByStatus(status)){
            listRequestActivation.add(cb);
        }
        String strToolbar=getResources().getString(R.string.RAList_toolbar);
        if(status==30){
            strToolbar=getResources().getString(R.string.RAList_toolbar_30);
        }
        adapter.notifyDataSetChanged();
        if (listRequestActivation.size() > 0) {
            setOnClick();
            RL_nothing.setVisibility(View.GONE);
            myToolbar.setTitle(strToolbar+" " + listRequestActivation.size());
        }else{
            RL_nothing.setVisibility(View.VISIBLE);
            myToolbar.setTitle("");
        }
    }

    private void makeBlock(String datatype, String data) {
        Intent intent = new Intent(RAList.this, CoreService.class);
        intent.putExtra("Message", datatype + ":" + data);
        startService(intent);
    }

}