package com.maakki.HyperConnectivity;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

// 資料功能類別
public class preConnectivityBenifitDAO {
    // 表格名稱
    public static final String TABLE_NAME = "preConnectivityBenifit";

    // 編號表格欄位名稱，固定不變
    public static final String KEY_ID = "_id";
    Context context;

    // 其它表格欄位名稱
    public static final String Hcid_COLUMN = "hcid";
    public static final String Amount_COLUMN = "Amount";
    public static final String note_COLUMN = "note";
    public static final String BlockIndex_COLUMN = "block_index";
    public static final String CreateTime_COLUMN = "createtime";


    // 提醒日期時間
    //public static final String ALARMDATETIME_COLUMN = "alarmdatetime";

    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    Hcid_COLUMN + " TEXT NOT NULL, " +
                    Amount_COLUMN + " REAL NOT NULL, " +
                    note_COLUMN + " TEXT NOT NULL, " +
                    BlockIndex_COLUMN +" INTEGER NOT NULL, " +
                    CreateTime_COLUMN +" INTEGER NOT NULL) ";

    // 資料庫物件
    private SQLiteDatabase db;

    // 建構子，一般的應用都不需要修改
    public preConnectivityBenifitDAO(Context context) {
        this.context=context;
        db = HyperConnDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public preConnectivityBenifit insert(preConnectivityBenifit pcb) {
        // 建立準備新增資料的ContentValues物件

        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的新增資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(Hcid_COLUMN, pcb.getHcid());
        cv.put(Amount_COLUMN,pcb.getAmount());
        cv.put(note_COLUMN, pcb.getNote());
        cv.put(BlockIndex_COLUMN, pcb.getBlockIndex());
        cv.put(CreateTime_COLUMN, pcb.getCreateTime());

        long id = db.insert(TABLE_NAME, null, cv);
        // 設定編號
        pcb.setId(id);

        return pcb;
    }

    // 修改參數指定的物件
    public boolean update(preConnectivityBenifit pcb) {
        // 建立準備修改資料的ContentValues物件
        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(Hcid_COLUMN, pcb.getHcid());
        cv.put(Amount_COLUMN,pcb.getAmount());
        cv.put(note_COLUMN, pcb.getNote());
        cv.put(BlockIndex_COLUMN, pcb.getBlockIndex());
        cv.put(CreateTime_COLUMN, pcb.getCreateTime());


        // 設定修改資料的條件為編號
        String where = KEY_ID + "=" + pcb.getId();

        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_ID + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    // 刪除指定区块给予的資料
    public boolean deleteByBlock(Block block) {
        // 設定條件為編號，格式為「欄位名稱=資料」

        String where =BlockIndex_COLUMN + "=" + block.getIndex() +" AND "+
                      Hcid_COLUMN + "='" +block.getData().split(" ")[0]+"' AND "+
                      Amount_COLUMN +"='" +block.getData().split(" ")[1]+"' AND "+
                      note_COLUMN+"='" +block.getData().split(" ")[2]+"'";
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }
    public void clear() {
        for(preConnectivityBenifit pcb:getAll()){
            delete(pcb.getId());
        }
    }
    public void replace(List<preConnectivityBenifit> pcblist) {
        clear();
        for(preConnectivityBenifit pcb:pcblist){
            insert(pcb);
        }
    }
    // 讀取所有联络人資料
    public List<preConnectivityBenifit> getAll() {
        List<preConnectivityBenifit> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }
    // 从区块连讀取所有pcb資料
    public List<preConnectivityBenifit> getAllFromBlockchain() {
        clear();
        List<preConnectivityBenifit> result = new ArrayList<>();
        BlockchainDAO bcd=new BlockchainDAO(context);
        for (Block block : bcd.getAll()) {
            if (block.getDatatype().equals("getCB")||block.getDatatype().equals("getPCB")) {
                preConnectivityBenifit pcb=new preConnectivityBenifit();
                pcb.setHcid(block.getData().split(" ")[1]);
                if(block.getDatatype().equals("getCB")){
                    pcb.setAmount(-Double.parseDouble(block.getData().split(" ")[2]));
                }else if(block.getDatatype().equals("getPCB")){
                    pcb.setAmount(Double.parseDouble(block.getData().split(" ")[2]));
                }
                pcb.setNote(block.getData().split(" ")[3]);
                pcb.setBlockIndex(block.getIndex());
                pcb.setCreateTime(block.getTimestamp());
                insert(pcb);
                result.add(pcb);
            }
        }
        return result;
    }
    // 讀取所有联络人資料
    public Double getSum() {
        double result=0d;
        for(preConnectivityBenifit pcb:getAll()){
            result+=pcb.getAmount();
        }
        return result;
    }

    // 取得与某个HCID相关的所有记录
    public List<preConnectivityBenifit> getByHcid(String hcid) {
        // 準備回傳結果用的物件
        List<preConnectivityBenifit> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = Hcid_COLUMN +"='"+hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }
    public double getBalanceByHCID(String hcid){
        double balance=0d;
        //preConnectivityBenifitDAO pcbDAO=new preConnectivityBenifitDAO(context);
        //List<preConnectivityBenifit> pcblist=new ArrayList<>();
        //pcblist=pcbDAO.getByOrderHash(hcid);
        for (preConnectivityBenifit pcb:getByHcid(hcid)){
                balance+=pcb.getAmount();
        }
        return balance;
    }
    public Double getGR_byPhase(String hcid){
        Double gr=0d;
        int phase=0;
        Double cr=new CB_TradingDAO(context).getCR();
        Double pcb,sum_cashin,ROI,fee;
        pcb=getPCBForWhat(hcid,"fromHC")+getPCBForWhat(hcid,"Registration")+getPCBForWhat(hcid,"Introduction");
        //cb=new ConnectivityBenifitDAO(context).getBalanceByHCID(hcid);
        fee=Double.parseDouble(context.getResources().getString(R.string.exchange_fee));
        sum_cashin=Double.parseDouble(context.getResources().getString(R.string.activation_fee))+new CB_OrderDAO(context).SumUSD_CBOrder_done(hcid);
        ROI=Utils.multiply((pcb)*(1-fee),cr)/sum_cashin;

        if(ROI<0.7){
            phase=1;
        }else if(ROI<1.15){
            phase=2;
        }else if(ROI<3.0){
            phase=3;
        }else if(ROI<6.0){
            phase=4;
        }else if(ROI<10.0){
            phase=5;
        }else if(ROI<20.0){
            phase=6;
        }else {
            phase=7;
        }
        return  ROI;
    }

    public double getPCBForWhat(String hcid,String what){
        double balance=0d;
        //preConnectivityBenifitDAO pcbDAO=new preConnectivityBenifitDAO(context);
        //List<preConnectivityBenifit> pcblist=new ArrayList<>();
        //pcblist=pcbDAO.getByOrderHash(hcid);
        for (preConnectivityBenifit pcb:getByHcid(hcid)){
            if(pcb.getNote().equals(what))
            balance+=pcb.getAmount();
        }
        return balance;
    }
    // 把Cursor目前的資料包裝為物件
    public preConnectivityBenifit getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        preConnectivityBenifit result = new preConnectivityBenifit();
        result.setId(cursor.getLong(0));
        result.setHcid(cursor.getString(1));
        result.setAmount(cursor.getDouble(2));
        result.setNote(cursor.getString(3));
        result.setBlockIndex(cursor.getLong(4));
        result.setCreateTime(cursor.getLong(5));

        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        return result;
    }

}