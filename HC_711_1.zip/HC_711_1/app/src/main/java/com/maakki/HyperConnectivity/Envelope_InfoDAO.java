package com.maakki.HyperConnectivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Envelope_InfoDAO {
    // 表格名稱
    public static final String TABLE_NAME = "Envelpoe_Info";
    // 編號表格欄位名稱，固定不變
    public static final String KEY_Id = "_id";
    public static final String hash_Column = "_hash";
    public static final String status_Column = "_status";
    public static final String info_type_Column = "info_type";
    public static final String publisher_id_Column = "publisher_id";
    public static final String language_Column = "language";
    public static final String subject_Column = "subject";
    public static final String content_Column = "content";
    public static final String link_Column = "link";
    public static final String image_path_Column = "image_path";
    public static final String cb_amount_Column = "cb_amount";
    public static final String cbperclickColumn = "cbperclick";
    public static final String count_Column = "count";
    public static final String note_Column = "note";
    public static final String CreateTime_COLUMN = "_CreateTime";
    Context context;
    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_Id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    hash_Column + " TEXT NOT NULL, " +
                    status_Column + " INTEGER NOT NULL, " +
                    info_type_Column + " INTEGER NOT NULL, " +
                    publisher_id_Column + " TEXT NOT NULL, " +
                    language_Column + " TEXT NOT NULL, " +
                    subject_Column + " TEXT NOT NULL, " +
                    content_Column + " TEXT, " +
                    link_Column + " INTEGER, " +
                    image_path_Column + " TEXT, " +
                    cb_amount_Column + " REAL NOT NULL, " +
                    cbperclickColumn + " REAL NOT NULL, " +
                    count_Column + " INTEGER, " +
                    note_Column + " TEXT NOT NULL, " +
                    CreateTime_COLUMN + " REAL NOT NULL) ";
    // 資料庫物件
    private SQLiteDatabase db;
    // 建構子，一般的應用都不需要修改
    public Envelope_InfoDAO(Context context) {
        this.context=context;
        db = Envelope_InfoDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public Envelope_Info insert(Envelope_Info envelope_info) {
        // 建立準備新增資料的ContentValues物件
        if(!update(envelope_info)){
            ContentValues cv = new ContentValues();
            cv.put(hash_Column, envelope_info.getHash());
            cv.put(status_Column, envelope_info.getStatus());
            cv.put(info_type_Column, envelope_info.getInfo_type());
            cv.put(publisher_id_Column, envelope_info.getPublisher_id());
            cv.put(language_Column, envelope_info.getLanguage());
            cv.put(subject_Column, envelope_info.getSubject());
            cv.put(content_Column, envelope_info.getContent());
            cv.put(link_Column, envelope_info.getLink());
            cv.put(image_path_Column, envelope_info.getImage_path());
            cv.put(cb_amount_Column, envelope_info.getCB_Amount());
            cv.put(cbperclickColumn, envelope_info.getCBPerClick());
            cv.put(count_Column, envelope_info.getCount());
            cv.put(note_Column, envelope_info.getNote());
            cv.put(CreateTime_COLUMN, envelope_info.getCreateTime());
            // 新增一筆資料並取得編號
            // 第一個參數是表格名稱
            // 第二個參數是沒有指定欄位值的預設值
            // 第三個參數是包裝新增資料的ContentValues物件
            long id = db.insert(TABLE_NAME, null, cv);

            // 設定編號
            envelope_info.setId(id);
        }
        // 回傳結果
        return envelope_info;
    }

    // 修改參數指定的物件
    public boolean update(Envelope_Info envelope_info) {
        // 建立準備修改資料的ContentValues物件
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        ContentValues cv = new ContentValues();
        cv.put(hash_Column, envelope_info.getHash());
        cv.put(status_Column, envelope_info.getStatus());
        cv.put(info_type_Column, envelope_info.getInfo_type());
        cv.put(publisher_id_Column, envelope_info.getPublisher_id());
        cv.put(language_Column, envelope_info.getLanguage());
        cv.put(subject_Column, envelope_info.getSubject());
        cv.put(content_Column, envelope_info.getContent());
        cv.put(link_Column, envelope_info.getLink());
        cv.put(image_path_Column, envelope_info.getImage_path());
        cv.put(cb_amount_Column, envelope_info.getCB_Amount());
        cv.put(cbperclickColumn, envelope_info.getCBPerClick());
        cv.put(count_Column, envelope_info.getCount());
        cv.put(note_Column, envelope_info.getNote());
        cv.put(CreateTime_COLUMN, envelope_info.getCreateTime());
        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = hash_Column + "='" + envelope_info.getHash()+"'";
        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    public boolean updateCount(Envelope_Info envelope_info) {
        // 建立準備修改資料的ContentValues物件
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        Envelope_Info ei=getByHash(envelope_info.getHash());
        ContentValues cv = new ContentValues();
        cv.put(hash_Column, envelope_info.getHash());
        cv.put(status_Column, envelope_info.getStatus());
        cv.put(info_type_Column, envelope_info.getInfo_type());
        cv.put(publisher_id_Column, envelope_info.getPublisher_id());
        cv.put(language_Column, envelope_info.getLanguage());
        cv.put(subject_Column, ei.getSubject());
        cv.put(content_Column, ei.getContent());
        cv.put(link_Column, envelope_info.getLink());
        cv.put(image_path_Column, ei.getImage_path());
        cv.put(cb_amount_Column, ei.getCB_Amount());
        cv.put(cbperclickColumn, ei.getCBPerClick());
        cv.put(count_Column, envelope_info.getCount());
        cv.put(note_Column, envelope_info.getNote());
        cv.put(CreateTime_COLUMN, ei.getCreateTime());
        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = hash_Column + "='" + envelope_info.getHash()+"'";
        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }
    public boolean addCount(String hash) {
        // 建立準備修改資料的ContentValues物件
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        Envelope_Info ei=getByHash(hash);
        ContentValues cv = new ContentValues();
        cv.put(hash_Column, ei.getHash());
        cv.put(status_Column, ei.getStatus());
        cv.put(info_type_Column, ei.getInfo_type());
        cv.put(publisher_id_Column, ei.getPublisher_id());
        cv.put(language_Column, ei.getLanguage());
        cv.put(subject_Column, ei.getSubject());
        cv.put(content_Column, ei.getContent());
        cv.put(link_Column, ei.getLink());
        cv.put(image_path_Column, ei.getImage_path());
        cv.put(cb_amount_Column, ei.getCB_Amount());
        cv.put(cbperclickColumn, ei.getCBPerClick());
        cv.put(count_Column, new Envelope_Info_recordDAO(context).getCoutByAdHash(hash));
        cv.put(note_Column, ei.getNote());
        cv.put(CreateTime_COLUMN, ei.getCreateTime());
        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = hash_Column + "='" + ei.getHash()+"'";
        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    public Envelope_Info getByHash(String hash) {
        // 準備回傳結果用的物件
        Envelope_Info Envelope_Info = null;
        // 使用編號為查詢條件
        String SELECTSTRING = hash_Column + "='" + hash+"'";
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            Envelope_Info = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return Envelope_Info;
    }
    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_Id + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    public boolean deleteByHash(String hash) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = hash_Column + "='" + hash +"'";
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }
    // 刪除參數指定編號的資料

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }

    public void clear() {
        for(Envelope_Info ra:getAll()){
            delete(ra.getId());
        }
    }

    // 讀取所有記事資料
    public List<Envelope_Info> getAll() {
        List<Envelope_Info> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null,CreateTime_COLUMN+" DESC" , null);
        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public List<Envelope_Info> getListAD(String hcid) {
        List<Envelope_Info> result = new ArrayList<>();
        String SELECTIONSTRING = publisher_id_Column+"!='"+hcid+"' AND "+status_Column+"=21";

        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTIONSTRING, null, null, null,CreateTime_COLUMN+" DESC" , null);
        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public List<Envelope_Info> getMyAd(String hcid) {
        List<Envelope_Info> result = new ArrayList<>();
        String SELECTIONSTRING = publisher_id_Column+"='"+hcid+"' AND "+status_Column+"=21";
        String ORDERSTRING =cbperclickColumn + " DESC," + CreateTime_COLUMN + " DESC";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTIONSTRING, null, null, null , null);
        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public ArrayList getAdsOnLine(String hcid) {
        ArrayList result = new ArrayList();
        String SELECTIONSTRING = publisher_id_Column+"!='"+hcid+"' AND "+status_Column+"=21";
        //String ORDERSTRING =cbperclickColumn + " DESC," + CreateTime_COLUMN + " DESC";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTIONSTRING, null, null, null , null);
        while (cursor.moveToNext()) {
            result.add(getRecord(cursor).getPublisher_id()+":"+getRecord(cursor).getHash());
        }

        cursor.close();
        return result;
    }

    // 讀取所有記事資料
    // 取得指定編號的資料物件
    public Envelope_Info get(long id) {
        // 準備回傳結果用的物件
        Envelope_Info Envelope_Info = null;
        // 使用編號為查詢條件
        String SELECTSTRING = KEY_Id + "=" + id;
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            Envelope_Info = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return Envelope_Info;
    }
    // 把Cursor目前的資料包裝為物件
    public Envelope_Info getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        Envelope_Info result = new Envelope_Info();
        result.setId(cursor.getLong(0));
        result.setHash(cursor.getString(1));
        result.setStatus(cursor.getInt(2));
        result.setInfo_type(cursor.getInt(3));
        result.setPublisher_id(cursor.getString(4));
        result.setLanguage(cursor.getString(5));
        result.setSubject(cursor.getString(6));
        result.setContent(cursor.getString(7));
        result.setLink(cursor.getString(8));
        result.setImage_path(cursor.getString(9));
        result.setCB_Amount(cursor.getDouble(10));
        result.setCBPerClick(cursor.getDouble(11));
        result.setCount(cursor.getInt(12));
        result.setNote(cursor.getString(13));
        result.setCreateTime(cursor.getLong(14));
        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME , null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }

}
