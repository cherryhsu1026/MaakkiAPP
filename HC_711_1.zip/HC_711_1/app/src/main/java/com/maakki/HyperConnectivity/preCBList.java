package com.maakki.HyperConnectivity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;
public class preCBList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon,iv_nothing;
    Integer count;
    FloatingActionButton fab;
    private boolean isRedenvelope = false, isAscending = false;
    private String HCID;
    private Context context;
    private List<preConnectivityBenifit> listpreConnectivityBenifit;
    private preConnectivityBenifitDAO pcbDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private PCBAdapter adapter;
    private BroadcastReceiver receiver,receiver1;
    private String type="my";
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private Menu menu;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            menuItem.setVisible(false);
            switch (menuItem.getItemId()) {
                case R.id.allpcblist:
                    //menu.getItem(2).setVisible(false);
                    //Async_checkData checkDataTask1=new Async_checkData();
                    //checkDataTask1.execute("my");
                    type="my";
                    renewlist(type);
                    break;
                case R.id.mypcblist:
                    //menu.getItem(2).setVisible(false);
                    //Async_checkData checkDataTask2=new Async_checkData();
                    //checkDataTask2.execute("all");
                    type="all";
                    renewlist(type);
                    break;
                case R.id.cblist:
                    Intent i =new Intent(preCBList.this, CBList.class);
                    startActivity(i);
                    break;
            }
            return true;
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key100,"");
        HCID = Utils.setMyHCID(context);
        ShortcutBadger.with(getApplicationContext()).remove();
        listpreConnectivityBenifit = new ArrayList<preConnectivityBenifit>();
        pcbDAO = new preConnectivityBenifitDAO(this);
        //block = new preConnectivityBenifit();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        //iv_nothing=(ImageView)findViewById(R.id.iv_nothing);
        //iv_nothing.setImageDrawable(getResources().getDrawable(R.drawable.no_pcb));
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no pre-Connectivity Benifit created..");
        //tv = (TextView) findViewById(R.id.tv);
        listpreConnectivityBenifit = pcbDAO.getByHcid(HCID);
        count = listpreConnectivityBenifit.size();
        adapter = new PCBAdapter(this, R.layout.list_item, listpreConnectivityBenifit);
        listview.setAdapter(adapter);
        if (count > 0) {
            Collections.reverse(listpreConnectivityBenifit);
            myToolbar.setTitle("PCB "+Utils.formatDoubleToString(pcbDAO.getBalanceByHCID(HCID)));

        } else {
            RL_nothing.setVisibility(View.VISIBLE);
        }
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_preCBList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renewlist(type);
            }
        };
        registerReceiver(receiver, filter);

        IntentFilter filter1 = new IntentFilter();
        filter1.addAction("INVOKE_preCBList1");
        receiver1 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String message=intent.getStringExtra("What");
                showAlertDialog("PCBdata incorrect",message);
            }
        };
        registerReceiver(receiver1, filter1);
        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //renewlist("my");
        //Async_checkData checkDataTask=new Async_checkData();
        //checkDataTask.execute("my");
        //setOnClick();
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        if (receiver1 != null) {
            unregisterReceiver(receiver1);
            receiver1 = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_pcblist, menu);
        this.menu=menu;
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class PCBAdapter extends ArrayAdapter<preConnectivityBenifit> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public PCBAdapter(Context context, int textViewResourceId, List<preConnectivityBenifit> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            preConnectivityBenifit pcb = (preConnectivityBenifit) getItem(position);

            if (convertView == null) {
                //Toast.makeText(preCBList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();
            int icon = R.drawable.pcb;
            String title=pcb.getAmount()+" #"+pcb.getBlockIndex()+" "+pcb.getNote();
            holder.text_title.setText(title);
            holder.text_message.setText(pcb.getHcid());
            Long time = pcb.getCreateTime();
            String fm = "";
            Date date = new Date(time);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            fm = formatter.format(pcb.getCreateTime());
            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            return view;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }
    private void showAlertDialog(String title, String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(preCBList.this).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private class Async_checkData extends AsyncTask<String, Void, Void> {
        String type;
        @Override
        protected Void doInBackground(String... params) {
            type=params[0];
            checkData();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            menu.getItem(2).setVisible(true);
            renewlist(type);
            /*if(type.equals("all")){
                menu.getItem(1).setVisible(true);
            }else if(type.equals("my")){

                    listpreConnectivityBenifit.clear();
                    for(preConnectivityBenifit pcb:pcbDAO.getAll()){
                        if(pcb.getHcid().equals(HCID)){
                            listpreConnectivityBenifit.add(pcb);
                            result+=pcb.getAmount();
                        }
                    }

                myToolbar.setTitle("PCB "+Utils.formatDoubleToString(result));
                adapter.notifyDataSetChanged();
                menu.getItem(0).setVisible(true);
            }*/
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }

    }
    private void renewlist(String type){
        listpreConnectivityBenifit.clear();
        Double result=0d;
        if(type.equals("all")){
            menu.getItem(1).setVisible(true);
            menu.getItem(0).setVisible(false);
            for(preConnectivityBenifit pcb:new preConnectivityBenifitDAO(context).getAll()){
                listpreConnectivityBenifit.add(pcb);
                result+=pcb.getAmount();
            }
        }else if(type.equals("my")){
            menu.getItem(0).setVisible(true);
            menu.getItem(1).setVisible(false);
            listpreConnectivityBenifit.clear();
            for(preConnectivityBenifit pcb:pcbDAO.getAll()){
                if(pcb.getHcid().equals(HCID)){
                    listpreConnectivityBenifit.add(pcb);
                    result+=pcb.getAmount();
                }
            }
        }
        Collections.reverse(listpreConnectivityBenifit);
        adapter.notifyDataSetChanged();
        if (listpreConnectivityBenifit.size() > 0) {
            listview.setVisibility(View.VISIBLE);
            RL_nothing.setVisibility(View.GONE);
            myToolbar.setTitle("PCB " + Utils.formatDoubleToString(result));
        }else{
            RL_nothing.setVisibility(View.VISIBLE);
            listview.setVisibility(View.GONE);
            myToolbar.setTitle("");
        }
    }


    private void checkData() {
        //Double result=0d;
        BlockchainDAO blockchainDAO = new BlockchainDAO(context);
        pcbDAO.clear();
        for (Block block : blockchainDAO.getAll()) {
           if (block.getDatatype().equals("getPCB")) {
               //if(type.equals("all")||(type.equals("my")&block.getData().split(" ")[0].equals(HCID))) {
                   preConnectivityBenifit pcb = new preConnectivityBenifit();
                   pcb.setHcid(block.getData().split(" ")[0]);
                   pcb.setAmount(Double.parseDouble(block.getData().split(" ")[1]));
                   //for " fromHC"
                   if(!block.getData().split(" ")[2].isEmpty()){
                       pcb.setNote(block.getData().split(" ")[2]);
                   }else{
                       pcb.setNote(block.getData().split("  ")[1]);
                   }
                   pcb.setBlockIndex(block.getIndex());
                   pcb.setCreateTime(block.getTimestamp());
                   pcbDAO.insert(pcb);
               //}
            }  else if (block.getDatatype().equals("getCB")) {
               if(block.getData().split(" ")[3].equals("activity")){
                   preConnectivityBenifit pcb = new preConnectivityBenifit();
                   pcb.setHcid(block.getData().split(" ")[1]);
                   pcb.setAmount(-Double.parseDouble(block.getData().split(" ")[2]));
                   pcb.setNote(block.getData().split(" ")[3]);
                   pcb.setBlockIndex(block.getIndex());
                   pcb.setCreateTime(block.getTimestamp());
                   pcbDAO.insert(pcb);
               }
            }
        }
        //return result;
    }
}
