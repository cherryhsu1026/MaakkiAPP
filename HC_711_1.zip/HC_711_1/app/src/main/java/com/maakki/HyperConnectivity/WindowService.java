package com.maakki.HyperConnectivity;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Date;

public class WindowService extends Service {
    //private final String TAG = this.getClass().getSimpleName();
    private WindowManager.LayoutParams wmParams;
    private WindowManager mWindowManager;
    private View mWindowView1,mWindowView2;
    ImageView iv_icon,iv_envelope;
    //TextView tv_msg;
    private int mStartX;
    private int mStartY;
    private int mEndX;
    private int mEndY;
    private String getType,HCID,CBAmt,nMessage;
    Animation myAnim;
    Context context;
    //GifView mGifView;
    @Override
    public void onCreate() {
        super.onCreate();
        context=this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        // Use bounce interpolator with amplitude 0.2 and frequency 20
        MyBounceInterpolator interpolator = new MyBounceInterpolator(0.2, 20);
        myAnim.setInterpolator(interpolator);
        initWindowParams();
        initView();
        initClick();
    }

    /**
     * 是否拦截
     * @return true:拦截;false:不拦截.
     */
    private boolean needIntercept() {
        if (Math.abs(mStartX - mEndX) > 30 || Math.abs(mStartY - mEndY) > 30) {
            return true;
        }
        return false;
    }

    private void initWindowParams() {
        mWindowManager = (WindowManager) getApplication().getSystemService(getApplication().WINDOW_SERVICE);
        wmParams = new WindowManager.LayoutParams();
        // 更多type：https://developer.android.com/reference/android/view/WindowManager.LayoutParams.html#TYPE_PHONE
        if (Build.VERSION.SDK_INT < 26) {
            wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        //wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        wmParams.format = PixelFormat.TRANSLUCENT;
        // 更多falgs:https://developer.android.com/reference/android/view/WindowManager.LayoutParams.html#FLAG_NOT_FOCUSABLE
        wmParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
    }

    private void initView() {
        //switch (view){
            //case 1:
                mWindowView1 = LayoutInflater.from(getApplication()).inflate(R.layout.layout_window, null);
                iv_icon = (ImageView) mWindowView1.findViewById(R.id.iv_icon);
                iv_icon.startAnimation(myAnim);
                //break;
            //case 2:
                mWindowView2 = LayoutInflater.from(getApplication()).inflate(R.layout.cb_envelope_form, null);
                iv_envelope=(ImageView) mWindowView2.findViewById(R.id.iv_envelope);
                TextView tv_CB = (TextView) mWindowView2.findViewById(R.id.tv_CB);
                TextView tv_pcb = (TextView) mWindowView2.findViewById(R.id.tv_pcb);
                TextView tv_cb = (TextView) mWindowView2.findViewById(R.id.tv_cb);
                final String pcb =getCB_amount().split(":")[0];
                final String cb =getCB_amount().split(":")[2];
                CBAmt = getCB_amount().split(":")[1];
                tv_CB.setText(CBAmt + " " + "CB");
                tv_pcb.setText(pcb);
                tv_cb.setText(cb);
                TextView tv_greeting = (TextView) mWindowView2.findViewById(R.id.tv_greeting);
                tv_greeting.setText("Get CB!");
                iv_envelope.startAnimation(myAnim);
                //break;
        //}
    }
    private String getCB_amount(){
        Double sum=new preConnectivityBenifitDAO(context).getBalanceByHCID(HCID);
        Double cb=new ConnectivityBenifitDAO(context).getBalanceByHCID(HCID);
        if(sum/200>0.02){
            return Utils.formatDoubleToString(sum)+":"
                    +Utils.formatDoubleToString(sum/200)+":"
                    +Utils.formatDoubleToString(cb)+":";
        }else{
            return Utils.formatDoubleToString(sum)+":0.01"+":"
                    +Utils.formatDoubleToString(cb)+":";
        }
    }

    private void addWindowView2Window(int view_no) {
        //
        //if (mWindowView1  != null) {
        switch (view_no) {
            case 1:
                if (mWindowView1.getParent() == null) {
                    try {
                        mWindowManager.addView(mWindowView1, wmParams);
                    } catch (Exception e) {
                    }
                }
                break;
            case 2:
                try {
                    mWindowManager.addView(mWindowView2, wmParams);
                } catch (Exception e) {
                }
                break;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        /*if (intent.getExtras() != null) {
            Bundle bundle = intent.getExtras();
            getType = bundle.getString("getType");
        }else{
            getType="";
        }*/
        wmParams.gravity = Gravity.LEFT | Gravity.TOP;
        wmParams.x = 25;
        wmParams.y = 25;
        addWindowView2Window(1);
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //if(mWindowView1.getWindowToken() != null){
        if (mWindowView1  != null) {
            //移除悬浮窗口
            //Log.i(TAG, "removeView");
            mWindowManager.removeView(mWindowView1);
        }
        //if(mWindowView1.getWindowToken() != null){
        if (mWindowView2  != null) {
            //移除悬浮窗口
            //Log.i(TAG, "removeView");
            mWindowManager.removeView(mWindowView2);
        }
        //Log.i(TAG, "onDestroy");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void initClick() {
        //switch(view){
            //case 1:
            iv_icon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    /*if(getType.equals("backHome")){
                        Intent i= new Intent(WindowService.this,HyperConnActivity.class);
                        startActivity(i);
                        mWindowManager.removeView(mWindowView1);
                    }else if(getType.equals("getCB")){*/
                        SharedPreferencesHelper.putSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key24, new Date().getTime());
                        mWindowManager.removeView(mWindowView1);
                        wmParams.gravity = Gravity.CENTER | Gravity.CENTER;
                        wmParams.x=0;
                        wmParams.y=0;
                        addWindowView2Window(2);
                    //}
                }
            });
            //break;
            //case 2:
            iv_envelope.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //SharedPreferencesHelper.putSharedPreferencesLong(context, SharedPreferencesHelper.SharedPreferencesKeys.key24, new Date().getTime());
                    makeBlock("getCB", "HyperConn" + " " + HCID + " " + CBAmt + " activity");
                    mWindowManager.removeView(mWindowView2);
                }
            });
            //break;
        //}

    }

    private void makeBlock(String datatype, String data) {
        Intent intent = new Intent(context, CoreService.class);
        intent.putExtra("Message", datatype + ":" + data);
        startService(intent);
    }
}
