package com.maakki.HyperConnectivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;

public class NetworkChangeReceiver extends BroadcastReceiver {
    public boolean isConnected;
    String why;
    Context context;
    @Override
    public void onReceive(final Context context, final Intent intent) {
        this.context=context;
        Intent i = new Intent("INVOKE_to_HyperConn");
        Intent intentservice = new Intent(context, CoreService.class);
        /*isConnected = false;
        why = "";
        ConnectivityManager cm =
                (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = null;
        if (cm != null) {
            networkInfo = cm.getActiveNetworkInfo();
        }

        if (networkInfo != null) {
            if (networkInfo.isConnected()) {
                if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                    WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    WifiInfo wifiInfo = null;
                    if (wifiManager != null) {
                        wifiInfo = wifiManager.getConnectionInfo();
                    }
                    if (wifiInfo != null) {
                        int linkSpeed = wifiManager.getConnectionInfo().getRssi();
                        int level = WifiManager.calculateSignalLevel(linkSpeed, 5);
                        if (level >= 2 && wifiInfo.getLinkSpeed() >= 2) {
                            isConnected = true;
                        } else {
                            why = "WiFi connectivity is poor: " + level + " / " + wifiInfo.getLinkSpeed();
                        }
                    } else {
                        why = "WiFi is null.";
                    }
                } else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                    int netSubType = networkInfo.getSubtype();
                    //INVOKE_BlockChain_Broadcasting("LinkDownstreamBandwidthKbps: "+netSubType+" / "+nc.getLinkDownstreamBandwidthKbps());
                    if (netSubType != TelephonyManager.NETWORK_TYPE_GPRS &
                            netSubType != TelephonyManager.NETWORK_TYPE_EDGE &
                            netSubType != TelephonyManager.NETWORK_TYPE_1xRTT
                        //& nc.getLinkDownstreamBandwidthKbps()>80000
                    ) {
                        isConnected = true;
                        why = networkInfo.getTypeName();
                    } else {
                        why = "Mobile connectivity is poor: " + netSubType;
                        //+ " / "+ nc.getLinkDownstreamBandwidthKbps();
                    }
                }
            } else {
                why = "networkInfo.isConnected(): false";
            }
        } else {
            why = "networkInfo: null";
        }*/
        //if(isConnected){
        if(isConnected()){
            intentservice.putExtra("Message", "connected");
            INVOKE_BlockChain_Broadcasting("Network connected.." + why);
            i.putExtra("connect_status", "connected");
        }else{
            intentservice.putExtra("Message", "disconnected");
            INVOKE_BlockChain_Broadcasting("No network available: " + why);
            i.putExtra("connect_status", "disconnected");
        }
        context.sendBroadcast(i);
        context.startService(intentservice);
    }
    public boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm != null ? cm.getActiveNetworkInfo() : null;
        //should check null because in airplane mode it will be null
        return (networkInfo != null && networkInfo.isConnected());
    }
    public boolean _isConnected() {
        boolean isConnected=false;
        String why="";
        ConnectivityManager cm =
                (ConnectivityManager)context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = null;
        if(cm!=null){
            networkInfo = cm.getActiveNetworkInfo();
        }
        Intent i = new Intent("INVOKE_to_HyperConn");
        Intent intentservice = new Intent(context, CoreService.class);
        if (networkInfo != null){
            if (networkInfo.isConnected()) {
                if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                    WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    WifiInfo wifiInfo = null;
                    if(wifiManager!=null){
                        wifiInfo = wifiManager.getConnectionInfo();
                    }
                    if(wifiInfo!=null){
                        int linkSpeed = wifiManager.getConnectionInfo().getRssi();
                        int level = WifiManager.calculateSignalLevel(linkSpeed, 5);
                        if(level >= 2 && wifiInfo.getLinkSpeed() >= 2){
                            isConnected = true;
                        }else{
                            why= "WiFi connectivity is poor: "+level+ " / "+ wifiInfo.getLinkSpeed();
                        }
                    }else{
                        why= "WiFi is null.";
                    }
                }
                else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                    int netSubType = networkInfo.getSubtype();
                    //INVOKE_BlockChain_Broadcasting("LinkDownstreamBandwidthKbps: "+netSubType+" / "+nc.getLinkDownstreamBandwidthKbps());
                    if ( netSubType != TelephonyManager.NETWORK_TYPE_GPRS &
                            netSubType != TelephonyManager.NETWORK_TYPE_EDGE &
                            netSubType != TelephonyManager.NETWORK_TYPE_1xRTT
                        //& nc.getLinkDownstreamBandwidthKbps()>80000
                    ) {
                        isConnected = true;
                    }else{
                        why= "Mobile connectivity is poor: "+netSubType;
                        //+ " / "+ nc.getLinkDownstreamBandwidthKbps();
                    }
                }
            }
            else{
                why="networkInfo.isConnected(): false";
            }
        }else{
            why="networkInfo: null";
        }
        if(isConnected){
            intentservice.putExtra("Message", "connected");
            INVOKE_BlockChain_Broadcasting("Network connected.."+networkInfo.getTypeName());
            i.putExtra("connect_status", "connected");
        }else{
            intentservice.putExtra("Message", "disconnected");
            INVOKE_BlockChain_Broadcasting("No network available: "+why);
            i.putExtra("connect_status", "disconnected");
        }
        context.sendBroadcast(i);
        context.startService(intentservice);
        return isConnected;
    }



    private void INVOKE_BlockChain_Broadcasting(String mess){
        Intent i = new Intent("INVOKE_BlockChain_Broadcasting");
        mess+="\n";
        i.putExtra("What", mess);
        //context.sendBroadcast(i);
    }
}
