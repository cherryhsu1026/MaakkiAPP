package com.maakki.HyperConnectivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class CB_Trading {
    private String hash_seller,hash_buyer,cashflow_2,cashflow_1,currency,note,hash;
    private int status;
    private Double amount,cb_amount,cr,exchange_fee;
    private Long id,block_index;
    private long createtime;

    public CB_Trading() {}

    public void setId( Long id){this.id=id;}
    public Long getId(){return id;}

    public String str() {
        return hash_seller + hash_buyer + cr + amount + cb_amount + createtime ;
    }

    public void setHash(String hash) {this.hash=hash;}
    public String getHash() {return hash;}

    public void setBlockIndex( Long block_index){this.block_index=block_index;}
    public Long getBlockIndex(){return block_index;}

    public void setHash_seller(String hash_seller){this.hash_seller=hash_seller;}
    public String getHash_seller(){return hash_seller;}

    public void setHash_buyer(String hash_buyer){this.hash_buyer=hash_buyer;}
    public String getHash_buyer(){return hash_buyer;}

    public void setStatus(int status){this.status=status;}
    public int getStatus(){return status;}

    public void setAmount(double amount) {
        this.amount=amount;
    }
    public double getAmount() {
        return amount;
    }

    public void setCurrency(String currency) {
        this.currency=currency;
    }
    public String getCurrency() {
        return currency;
    }

    public void setCashflow_1(String cashflow_1) {this.cashflow_1=cashflow_1;}
    public String getCashflow_1() {return cashflow_1;}

    public void setCashflow_2(String cashflow_2) {this.cashflow_2=cashflow_2;}
    public String getCashflow_2() {return cashflow_2;}

    public void setCB_Amount(Double cb_amount){this.cb_amount=cb_amount;}
    public double getCB_Amount(){return cb_amount;}

    public void setCR(Double cr){this.cr=cr;}
    public double getCR(){return cr;}

    // 0:withdraw by applicant  1:refund to cf1 2:refund to applicant(done)
    // 1?:rejected 2?:checking
    // 10:rejected by cf1 11: refund to applicant
    // 15:rejected by cf2 16: refund to cf1 17:refund to applicant
    // 20:waiting for Remittance replied by Applicant
    // 21:by cf1 22:by cf2
    // 26:waiting for activation
    // 30:succee(done)
    // 31:New CB release
    public void setExchnge_fee(Double exchange_fee){this.exchange_fee=exchange_fee;}
    public double getExchnge_fee(){return exchange_fee;}

    public void setNote(String note){this.note=note;}
    public String getNote(){return note;}

    //TimeStamp
    public long getCreateTime() {
        return createtime;
    }
    public void setCreateTime(long createtime) {this.createtime = createtime;}

    public String calculateHash(CB_Trading cbt) {
        if (cbt != null) {
            MessageDigest digest = null;
            try {
                digest = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException e) {
                return null;
            }
            String txt = cbt.str();
            final byte bytes[] = digest.digest(txt.getBytes());
            final StringBuilder builder = new StringBuilder();
            for (final byte b : bytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    builder.append('0');
                }
                builder.append(hex);
            }
            return builder.toString();
        }
        return null;
    }
}


