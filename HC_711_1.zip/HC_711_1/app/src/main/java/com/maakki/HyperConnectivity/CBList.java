package com.maakki.HyperConnectivity;


import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by ryan on 2017/7/17.
 */

public class CBList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon;
    Integer count;
    FloatingActionButton fab;
    private String type="my";
    private boolean isAscending = false;
    private Context context;
    private List<ConnectivityBenifit> listConnectivityBenifit;
    private ConnectivityBenifitDAO cbDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private BlockAdapter adapter;
    private BroadcastReceiver receiver;
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private String HCID;
    private Menu menu;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            menuItem.setVisible(false);
            //menu.getItem(2).setVisible(false);
            switch (menuItem.getItemId()) {
                case R.id.pcblist:
                    Intent i = new Intent(CBList.this, preCBList.class);
                    startActivity(i);
                    break;
                case R.id.mycblist:
                    menu.getItem(1).setVisible(true);
                    type="all";
                    renewlist(type);
                    break;
                case R.id.allcblist:
                    menu.getItem(0).setVisible(true);
                    type="my";
                    renewlist(type);
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);

        //ShortcutBadger.with(getApplicationContext()).remove();
        listConnectivityBenifit = new ArrayList<ConnectivityBenifit>();
        cbDAO=new ConnectivityBenifitDAO(context);
        //blockDAO = new BlockDAO(this);
        //block = new Block();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        if(cbDAO.getCount() > 0) {
            //Async_getBalanceByHCID getBalanceByHCIDTask=new Async_getBalanceByHCID();
            //getBalanceByHCIDTask.execute();
            myToolbar.setTitle("CB "+Utils.formatDoubleToString(cbDAO.getBalanceByHCID(HCID)));
        } else {
            myToolbar.setTitle("");
        }
        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no block created..");
        //tv = (TextView) findViewById(R.id.tv);
        count = cbDAO.getCount();
        listConnectivityBenifit = new ConnectivityBenifitDAO(context).getByHcid(HCID);
        adapter = new BlockAdapter(this, R.layout.list_item, listConnectivityBenifit);
        listview.setAdapter(adapter);
        count = listConnectivityBenifit.size();
        if (count > 0) {
            Collections.reverse(listConnectivityBenifit);
            //listtop=new ArrayList<PrevNotification>();
            //tv.setText("(" + count.toString() + ")");
            if (count > 1) {
                fab.setVisibility(View.VISIBLE);
            }
            //setOnClick();
            fab.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }

                    Collections.reverse(listConnectivityBenifit);
                    adapter.notifyDataSetChanged();
                }
            });

        } else {
            //tv.setText("");
            RL_nothing.setVisibility(View.VISIBLE);
        }

        //check if isOnlineOnSignalR
        //AsyncCallWS_isOnlineOnSignalR isOnlineOnSignalRTask = new AsyncCallWS_isOnlineOnSignalR();
        //isOnlineOnSignalRTask.execute();
        // your oncreate code should be
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_CBList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renewlist(type);
            }
        };
        registerReceiver(receiver, filter);

        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //menu.getItem(0).setVisible(true);
        //Async_checkData checkDataTask = new Async_checkData();
        //checkDataTask.execute("my");
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cblist, menu);
        this.menu=menu;
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class BlockAdapter extends ArrayAdapter<ConnectivityBenifit> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public BlockAdapter(Context context, int textViewResourceId, List<ConnectivityBenifit> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            ConnectivityBenifit cb = (ConnectivityBenifit) getItem(position);

            if (convertView == null) {
                //Toast.makeText(CBList1.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(CBList1.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(CBList1.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();

            int icon = R.drawable.cb;
            String title = String.valueOf(cb.getAmount()) ;
            if(cb.getSender().equals(HCID)){
                title = "-"+cb.getAmount();
            }
            title += " #" + cb.getBlockIndex() + " " + cb.getNote();
            holder.text_title.setText(title);
            holder.text_message.setText(cb.getReceiver());
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            String fm = formatter.format(cb.getCreateTime());
            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            //}
            return view;
            //return convertView;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }
    private String getCurrentDate() {
        Date d = new Date();
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        return dt1.format(d.getTime());
    }

    private void showAlertDialog(String title, String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(CBList.this).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }
    private class Async_getBalanceByHCID extends AsyncTask<String, Void, String> {
        String type;
        @Override
        protected String doInBackground(String... params) {
            type=params[0];
            return getBalanceByHCID(type);
        }

        @Override
        protected void onPostExecute(String result) {
                //myToolbar.setTitle(result);
                menu.getItem(2).setVisible(true);
                if(type.equals("all")){
                    menu.getItem(1).setVisible(true);
                }else{
                    menu.getItem(0).setVisible(true);
                }
        }

        @Override
        protected void onPreExecute() {
            myToolbar.setTitle("CB");
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }

    }
    private String getBalanceByHCID(String type){
        if(type.equals("all")){
            return "CB " + Utils.formatDoubleToString(cbDAO.getSum());
        }else{
            return "CB " + Utils.formatDoubleToString(cbDAO.getBalanceByHCID(HCID));
        }
    }
    private class Async_checkData extends AsyncTask<String, Void, Void> {
        String type;
        @Override
        protected Void doInBackground(String... params) {
            type=params[0];
            //checkData(type);
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            //myToolbar.setTitle(":"+type);
            //Async_getBalanceByHCID getBalanceByHCIDTask=new Async_getBalanceByHCID();
            //getBalanceByHCIDTask.execute(type);
            menu.getItem(2).setVisible(true);
            //renewlist(type);
        }

        @Override
        protected void onPreExecute() {
            //RL_nothing.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }
    private void checkData(String type) {
        //listConnectivityBenifit.clear();
        //Boolean needrenew=false;
        /*BlockchainDAO blockchainDAO = new BlockchainDAO(context);
        List<Block> blockList=blockchainDAO.getAll();
        Double cb_amount = 0d;
        for (Block block : blockList) {
            if (block.getDatatype().equals("getCB")) {
                if(type.equals("all")){
                    cb_amount += Double.parseDouble(block.getData().split(" ")[2]);
                }else{
                    if(block.getData().split(" ")[1].equals(HCID)){
                        cb_amount += Double.parseDouble(block.getData().split(" ")[2]);
                    }
                }

            }
        }*/
        /*if (cb_amount != cbDAO.getSum()) {
            //cbDAO.deleteAll();
            //cbDAO = new ConnectivityBenifitDAO(context);
            cbDAO.clear();
            for (Block block : blockList) {
                if (block.getDatatype().equals("getCB")) {
                    //if(type.equals("all")||(type.equals("my")&block.getData().split(" ")[1].equals(HCID))){
                        ConnectivityBenifit cb = new ConnectivityBenifit();
                        cb.setSender(block.getData().split(" ")[0]);
                        cb.setReceiver(block.getData().split(" ")[1]);
                        cb.setAmount(Double.parseDouble(block.getData().split(" ")[2]));
                        cb.setNote(block.getData().split(" ")[3]);
                        cb.setBlockIndex(block.getIndex());
                        cb.setCreateTime(block.getTimestamp());
                        cbDAO.insert(cb);
                    //}
                }
            }
            *//*if(type.equals("my")){
                listConnectivityBenifit.clear();
                for(ConnectivityBenifit cb:cbDAO.getAll()){
                    if(cb.getReceiver().equals(HCID)){
                        listConnectivityBenifit.add(cb);
                    }
                }
            }*//*
            //needrenew=true;
        }*/
        //return  needrenew;
    }

    private void renewlist(String type){
        listConnectivityBenifit.clear();
        if(type.equals("all")){
            menu.getItem(1).setVisible(true);
            for(ConnectivityBenifit cb:new ConnectivityBenifitDAO(context).getAll()){
                listConnectivityBenifit.add(cb);
            }
        }else if(type.equals("my")){
            for(ConnectivityBenifit cb:cbDAO.getAll()){
                if(cb.getReceiver().equals(HCID)){
                    listConnectivityBenifit.add(cb);
                }
            }
            menu.getItem(0).setVisible(true);
        }
        if (listConnectivityBenifit.size() > 0) {
            RL_nothing.setVisibility(View.GONE);
            if(type.equals("all")){
                myToolbar.setTitle("CB " + Utils.formatDoubleToString(cbDAO.getSum()));
            }else if(type.equals("my")){
                myToolbar.setTitle("CB " + Utils.formatDoubleToString(cbDAO.getBalanceByHCID(HCID)));
            }
            Collections.reverse(listConnectivityBenifit);
            adapter.notifyDataSetChanged();
        }else{
            RL_nothing.setVisibility(View.VISIBLE);
            myToolbar.setTitle("");
        }
    }
}

