package com.maakki.HyperConnectivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Date;

public class Envelope_Info {
    private String publisher_id,language,note,hash,subject,content,link,image_path;
    private int status,info_type,count;
    private Double cb_amount,cbperclick;
    private Long id;
    private long createtime;
    private String imageStr;

    public Envelope_Info() {
        image_path="_";
        cb_amount=20d;
        cbperclick=0.5;
        createtime=new Date().getTime();
        info_type=1;
        count=0;
        link="_";
        note="_";
        status=21;
    }

    public void setId( Long id){this.id=id;}
    public Long getId(){return id;}

    public String str() {
        return publisher_id + subject + info_type + cb_amount + createtime ;
    }

    public void setHash(String hash) {this.hash=hash;}
    public String getHash() {return hash;}

    public void setPublisher_id(String publisher_id) {this.publisher_id = publisher_id;}
    public String getPublisher_id() {return publisher_id;}

    public void setLanguage(String language){this.language=language;}
    public String getLanguage(){return language;}

    public void setSubject(String subject){this.subject=subject;}
    public String getSubject(){return subject;}

    public void setContent(String content){this.content=content;}
    public String getContent(){return content;}

    public void setLink(String link){this.link=link;}
    public String getLink(){return link;}

    public void setImage_path(String image_path){this.image_path=image_path;}
    public String getImage_path(){return image_path;}

    //public void setBlockIndex(Long block_index){this.block_index=block_index;}
    //public Long getBlockIndex(){return block_index;}

    // 0:withdraw by applicant  1:refund to cf1 2:refund to applicant(done)
    // 1?:rejected 2?:checking
    // 10:rejected by cf1 11: refund to applicant
    // 15:rejected by cf2 16: refund to cf1 17:refund to applicant
    // 20:waiting for Remittance replied by Applicant
    // 21:by cf1 22:by cf2
    // 26:waiting for activation
    // 30:succee(done)
    // 41:Blocked
    public void setStatus(int status){this.status=status;}
    public int getStatus(){return status;}

    public void setInfo_type(int info_type){this.info_type=info_type;}
    public int getInfo_type(){return info_type;}

    public void setCB_Amount(Double cb_amount){this.cb_amount=cb_amount;}
    public double getCB_Amount(){return cb_amount;}

    public void setCBPerClick(Double cbperclick){this.cbperclick=cbperclick;}
    public double getCBPerClick(){return cbperclick;}

    public void setCount(int count){this.count=count;}
    public int getCount(){return count;}

    public void setNote(String note){this.note=note;}
    public String getNote(){return note;}

    //TimeStamp
    public long getCreateTime() {
        return createtime;
    }
    public void setCreateTime(long createtime) {this.createtime = createtime;}

    public String calculateHash(Envelope_Info ei) {
        if (ei != null) {
            MessageDigest digest = null;
            try {
                digest = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException e) {
                return null;
            }
            String txt = ei.str();
            final byte bytes[] = digest.digest(txt.getBytes());
            final StringBuilder builder = new StringBuilder();
            for (final byte b : bytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    builder.append('0');
                }
                builder.append(hex);
            }
            return builder.toString();
        }
        return null;
    }
    public void setImageStr(String imageStr){this.imageStr=imageStr;}
    public String getImageStr(){return imageStr;}
}



