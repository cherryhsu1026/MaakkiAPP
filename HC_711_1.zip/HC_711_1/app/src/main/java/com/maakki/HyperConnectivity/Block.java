package com.maakki.HyperConnectivity;

import android.content.Context;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

public class Block {
    private long index,id;
    private long timestamp;
    private String previousHash;
    private String hash;
    private String datatype;
    private String data,maker;
    private int nonce;
    private long createtime;

    public void setId(long id){
        this.id=id;
    }
    public long getId() {
        return id;
    }

    public void setIndex(long index){
        this.index=index;
    }
    public long getIndex() {
        return index;
    }

    public Block() {
        maker="";
        datatype="";
        data="";
        hash="";
    }

    public Block(long index,String maker, long timestamp, String previousHash,String datatype, String data) {
        this.index = index;
        this.maker = maker;
        this.timestamp = timestamp;
        this.previousHash = previousHash;
        this.datatype=datatype;
        this.data = data;
        nonce = 0;
        hash = Block.calculateHash(this);
    }
    public void setTimestamp(long timestamp) {
        this.timestamp= timestamp;
    }
    public long getTimestamp() {
        return timestamp;
    }

    public void setHash(String hash) {this.hash=hash;}
    public String getHash() {return hash;}

    public void setPreviousHash(String previousHash) {this.previousHash=previousHash;}
    public String getPreviousHash() {
        return previousHash;
    }

    public void setData(String data) {
        this.data=data;
    }
    public String getData() {
        return data;
    }

    public String str() {
        return maker + timestamp + previousHash + datatype + data + nonce;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Block #").append(index).append(" ").append(datatype).append(" ").append(nonce).
                append("\ntimestamp:").append(timestamp).
                append("\nmaker:").append(maker).
                append("\nhash:").append(hash).
                append("\npreviousHash:").append(previousHash).
                append("\ndata:").append(data);
        return builder.toString();
    }
    public String toShow() {
        StringBuilder builder = new StringBuilder();
        builder.append("Block #").append(index).append(" ").append(datatype).append(" ").append(nonce).
                append("\ntimestamp:").append(timestamp).
                append("\nmaker:").append(maker);
        switch (datatype) {
            case "Activation":
                builder.append("\ndata:").append(data.split(" ")[0]).append(" ").append(data.split(" ")[2]);
                break;
            case "Registration":
                builder.append("\ndata:").append(data.split(" ")[0]).append("\n").append(data.split(" ")[1]);
                break;
            case "CB_Order":
                //data=cbo.getHash()+" "+cbo.getHcid()+" 22 "+cbo.getCashflow_2()+" "+cbo.getAmount()+" RMB "+cbo.getCreateTime()+" "+note;
                builder.append("\ndata:").append(data.split(" ")[0]).append("\n").append(data.split(" ")[1]).append("\n").append(data.split(" ")[2]);
                break;
            default:
                builder.append("\ndata:").append(data);
                break;
        }

        /*if(datatype.equals("Activation")){
            builder.append("\ndata:").append(data.split(" ")[0]).append(" ").append(data.split(" ")[2]);
        }else if(datatype.equals("Registration")){
            builder.append("\ndata:").append(data.split(" ")[0]).append("\n").append(data.split(" ")[1]);
        }else if(datatype.equals("CB_Order")){
            //data=cbo.getHash()+" "+cbo.getHcid()+" 22 "+cbo.getCashflow_2()+" "+cbo.getAmount()+" RMB "+cbo.getCreateTime()+" "+note;
            builder.append("\ndata:").append(data.split(" ")[0]).append("\n").append(data.split(" ")[1]).append("\n").append(data.split(" ")[2]);
        }else{
            builder.append("\ndata:").append(data);
        }*/
        return builder.toString();
    }

    public static String calculateHash(Block block) {
        if (block != null) {
            MessageDigest digest;
            try {
                digest = MessageDigest.getInstance("SHA-256");
            } catch (NoSuchAlgorithmException e) {
                return null;
            }

            String txt = block.str();
            final byte bytes[] = digest.digest(txt.getBytes());
            final StringBuilder builder = new StringBuilder();

            for (final byte b : bytes) {
                String hex = Integer.toHexString(0xff & b);

                if (hex.length() == 1) {
                    builder.append('0');
                }

                builder.append(hex);
            }

            return builder.toString();
        }

        return null;
    }

    public void mineBlock(int difficulty) {
        nonce = 0;
        while (!getHash().substring(0,  difficulty).equals(Utils.zeros(difficulty))) {
            nonce++;
            hash = Block.calculateHash(this);
        }
    }

    public void setNonce(int nonce) {this.nonce=nonce;}
    public int getNonce() {return nonce;}

    public void setDatatype(String datatype) {this.datatype=datatype;}
    public String getDatatype() {return datatype;}

    public void setCreateTime(long createtime) {this.createtime=createtime;}
    public long getCreateTime() {return createtime;}

    public void setMaker(String maker) {this.maker=maker;}
    public String getMaker() {return maker;}

    public void insertCB_OrderDAO(Context context,Block block){
        CB_Order cbo=new CB_Order();
        //data=cbo.getHash()+" "+cbo.getHcid()+" 26 "+cbo.getCashflow_1()+" "+cbo.getAmount()+" RMB "+cbo.getCreateTime()+" "+note;
        Boolean isBuy=Boolean.parseBoolean(block.getData().split(" ")[0]);
        cbo.setIsbuy(isBuy);
        cbo.setHash(block.getData().split(" ")[1]);
        cbo.setHcid(block.getData().split(" ")[2]);
        cbo.setStatus(Integer.parseInt(block.getData().split(" ")[3]));
        if(isBuy){
            cbo.setCashflow_1(block.getData().split(" ")[4]);
            cbo.setCashflow_2(context.getResources().getString(R.string.hcid_cashflow_2));
            cbo.setAmount(Double.parseDouble(block.getData().split(" ")[5]));
        }else{
            cbo.setCB_Amount(Double.parseDouble(block.getData().split(" ")[5]));
        }
        //cbo.setCreateTime(Long.parseLong(block.getData().split(" ")[6]));
        cbo.setCreateTime(block.getTimestamp());
        cbo.setCurrency(block.getData().split(" ")[7]);
        cbo.setNote(block.getData().split(" ")[8]);
        cbo.setBlockIndex(block.getIndex());
        new CB_OrderDAO(context).insert(cbo);
    }

    public void insertCB_TradingDAO(Context context,Block block){
        CB_Trading cbt=new CB_Trading();
        String data=block.getData();
        //data = "HyperConn " + cbo.getHash() + " 360 RMB "+strCR+" 31 "+strCB_amount ;
        cbt.setHash_seller(data.split(" ")[0]);
        cbt.setHash_buyer(data.split(" ")[1]);
        cbt.setCashflow_1(new CB_OrderDAO(context).getByHash(cbt.getHash_buyer()).getCashflow_1());
        cbt.setCashflow_2(new CB_OrderDAO(context).getByHash(cbt.getHash_buyer()).getCashflow_2());
        cbt.setAmount(Double.parseDouble(data.split(" ")[2]));
        cbt.setCurrency(data.split(" ")[3]);
        cbt.setCR(Double.parseDouble(data.split(" ")[4]));
        if(data.startsWith("HyperConn")){
            cbt.setExchnge_fee(0d);
        }else {
            cbt.setExchnge_fee(Utils.multiply(cbt.getAmount(), 0.15));
        }
        cbt.setStatus(Integer.parseInt(data.split(" ")[5]));
        cbt.setCB_Amount(Double.parseDouble(data.split(" ")[6]));
        cbt.setBlockIndex(block.getIndex());
        cbt.setCreateTime(new Date().getTime());
        cbt.setHash(cbt.calculateHash(cbt));
        new CB_TradingDAO(context).insert(cbt);
    }

    public void insertHCDAO(Context context,Block block) {
        HyperConnectivity hc = new HyperConnectivity();
        //data=ra.getApplicant()+" "+amount+" "+note;
        hc.setHcid(block.getData().split(" ")[0]);
        hc.setAmount(Double.parseDouble(block.getData().split(" ")[1].replace(",", "")));
        if (!block.getData().split(" ")[2].isEmpty()) {
            hc.setNote(block.getData().split(" ")[2]);
        } else {
            hc.setNote(block.getData().split("  ")[1]);
        }
        hc.setBlockIndex(block.getIndex());
        hc.setCreateTime(block.getTimestamp());
        new HyperConnectivityDAO(context).insert(hc);
    }

}
