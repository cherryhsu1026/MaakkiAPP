package com.maakki.HyperConnectivity;

/**
 * Created by ryan on 2016/8/4.
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by ryan on 2016/2/27.
 * 儲存如帳號、設定、上一次登入時間、遊戲關卡或電子郵件等，好讓APP在下一次執行時可讀取到這些上一次儲存下來的資料。
 * 資料的儲存格式是XML檔，儲存在Android手機中每個APP都會擁有的一個專用目錄下。
 * referenceManager.getDefaultSharedPreferences(context) 此偏好設定會儲存在
 * (/data/data/[packageName]/shared_prefs/[packageName]_preferences.xml)
 */
public class SharedPreferencesHelper {
    public static void putSharedPreferencesInt(Context context, String key, int value) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor edit = preferences.edit();
        edit.putInt(key, value);
        edit.commit();
    }

    public static void putSharedPreferencesBoolean(Context context, String key, boolean val) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor edit = preferences.edit();
        edit.putBoolean(key, val);
        edit.commit();
    }

    public static void putSharedPreferencesString(Context context, String key, String val) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor edit = preferences.edit();
        edit.putString(key, val);
        edit.commit();
    }

    public static void putSharedPreferencesFloat(Context context, String key, float val) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor edit = preferences.edit();
        edit.putFloat(key, val);
        edit.commit();
    }

    public static void putSharedPreferencesLong(Context context, String key, long val) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor edit = preferences.edit();
        edit.putLong(key, val);
        edit.commit();
    }

    public static long getSharedPreferencesLong(Context context, String key, long _default) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getLong(key, _default);
    }

    public static float getSharedPreferencesFloat(Context context, String key, float _default) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getFloat(key, _default);
    }

    public static String getSharedPreferencesString(Context context, String key, String _default) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getString(key, _default);
    }

    public static int getSharedPreferencesInt(Context context, String key, int _default) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getInt(key, _default);
    }

    public static boolean getSharedPreferencesBoolean(Context context, String key, boolean _default) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getBoolean(key, _default);
    }

    public static class SharedPreferencesKeys {
        //public static final String key0 = "mMaakkiID";
        public static final String key1 = "mMemID";
        public static final String key2 = "mName";
        public static final String key3 = "mPicfile";
        public static final String key4 = "isServiceOn";
        public static final String key5 = "isPageErr";

        //
        public static final String key24 ="Last_getCB_Time";
        public static final String key25 ="language";
        public static final String key26 ="Last_HCtoPCB_Time";
        public static final String key27 ="Last_checkData_Time";
        public static final String key28 ="account_name";
        public static final String key29 ="account_no";
        public static final String key30 ="bank_name";
        public static final String key31 ="bank_branch";

        public static final String key100 ="HCID";          //會員的HCID
        public static final String key101 ="strPrivateKey"; //會員的私鑰
        public static final String key102 ="strPublicKey";  //會員的公鑰
        public static final String key103 ="APK_link";
        public static final String key104 ="Introducer";
        public static final String key105 ="nickname";
        public static final String key106 ="photo_realpath";
        public static final String key107 ="Register_Time";
        public static final String key108 ="service_term_time";


    }

}

