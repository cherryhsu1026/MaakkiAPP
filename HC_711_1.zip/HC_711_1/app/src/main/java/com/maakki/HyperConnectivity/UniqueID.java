package com.maakki.HyperConnectivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * @author liangjun on 2018/1/21.
 */

public class UniqueID {

    //保存文件的路径
    //private final String CACHE_IMAGE_DIR = "HyperConn";
    //保存的文件 采用隐藏文件的形式进行保存
    //private final String DEVICES_FILE_NAME = "HC_ID.txt";

    //region  取得設備唯一識別碼；

    /**
     * 获取设备唯一标识符
     *
     * @param context context
     * @return IMIE Code
     */
    public String getDeviceId(Context context) {

        StringBuilder s = new StringBuilder();
        //获取IMES(也就是常说的DeviceId)
        //Log.e("cherry", "讀取IMIE碼");
        String IMEICode = getIMEICode(context);
        String DateStr=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(new Date());
        saveFile(context, "IMIECode.txt",  DateStr+ ":" + IMEICode, false);

        //获取设备的MACAddress地址 去掉中间相隔的冒号
        //Log.e("cherry", "讀取MAC Address");
        String MacAdr = getLocalMac();
        saveFile(context, "MACAddress.txt", DateStr+":"+MacAdr, false);

        //兩者皆不是空白，才串在一起取得MD5當作HCID
        if (!Utils.isBlank(IMEICode) && !Utils.isBlank(MacAdr)) {
            s.append(IMEICode);
            MacAdr = MacAdr.replace(":", "");
            s.append(MacAdr);
        }


        //如果沒有獲取相應的ID，則以GUID作为相应设备唯一标识符
        if (s.toString().isEmpty()) {
            Log.e("cherry", "Unable to get IMEI code and Mac address, so get HCID via UUID");
            //String uuid = UUID.randomUUID().toString().replace("-", "");
            //s.append(uuid);
            try {
                String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
                UUID uuid1 = UUID.nameUUIDFromBytes(androidId.getBytes(StandardCharsets.UTF_8));
                Log.e(context.toString(), "Android ID:" + uuid1.toString());
                saveFile(context, "Android_ID.txt", DateStr+":"+uuid1.toString(), true);
                s.append(uuid1.toString());
            } catch (Exception e) {
                //e.printStackTrace();
                Log.e("cherry", "取得Android識別碼錯誤:" + e.toString());
            }
        }
        //將HCID保存到SD卡中
        //saveDeviceID(md5, context);
        //Log.e("cherry", "新寫法MD5:" + getMD5String(s.toString()));
        //Log.e("cherry", "原寫法MD5:" + getMD5(s.toString()));
        //为了统一格式对设备的唯一标识进行md5加密 最终生成32位字符串
        return getMD5(s.toString());
    }
    //endregion

    //region 讀取HC_ID.txt 並回傳 HC_ID.txt 的文字檔內容

    /**
     * 讀取HC_ID.txt 並回傳 HC_ID.txt 的文字檔內容
     *
     * @param context context
     * @return HCID
     */
    public String readDeviceID(Context context) {
        File file = getDevicesDir(context); //取得HC_ID.txt  檔案
        //將檔案內容讀出
        //StringBuffer buffer = new StringBuffer();
        StringBuilder sb = new StringBuilder();
        try {
            FileInputStream fis = new FileInputStream(file);
            //InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
            InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
            Reader in = new BufferedReader(isr);
            int i;
            while ((i = in.read()) > -1) {
                sb.append((char) i);
            }
            in.close();
            Log.e("cherry", "讀到HC_ID.txt 的內容了");
            return sb.toString();
        } catch (java.io.FileNotFoundException e) {
            Log.e("cherry", "The File doesn't not exist.  UniqueID.java:readDeviceID(Context context)");
            return null;
        } catch (IOException e) {
            //e.printStackTrace();
            Log.e("cherry", "讀取HC_ID.txt 發生錯誤, UniqueID.java:readDeviceID(Context context)");
            return null;
        }
    }
    //endregion

    //region 到HyperConn 目錄下抓取HC_ID.txt 檔案，若沒有，則建立目錄

    /**
     * 统一处理设备唯一标识 保存的文件的地址
     *
     * @param context context
     * @return File HC_ID.txt
     */
    public File getDevicesDir(Context context) {
        File mCropFile = null;
        String FILE_NAME = "HC_ID.txt";
        /*
         * 如果我們想要讀取或者向SD卡寫入檔案，這時就必須先要判斷SD卡的狀態，否則有可能出錯。
         * MEDIA_MOUNTED 代表SD卡正常掛載，並且有讀寫的權限 （這種情況下才能對 SD 卡做存取)
         */
        //如果有SD卡，並且有讀寫的權限，則以存取SD卡為優先
        //Log.e("cherry", "StorageState:" + Environment.getExternalStorageState());
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            try {
                //Environment.getExternalStorageDirectory()
                File cropdir = new File(Environment.getExternalStorageDirectory(), staticVar.APP_dir);
                if (!cropdir.exists()) {
                    if (!cropdir.mkdirs()) {
                        Log.e("cherry", "在Extenal Storage 建立目錄失敗");
                    }
                }
                //Log.e("cherry", "有SD卡存取權限:目錄是" + cropdir.getAbsolutePath());
                mCropFile = new File(cropdir, FILE_NAME);
            } catch (Exception e) {
                Log.e("cherry", "讀取SD卡目錄發生問題");
            }
        } else {
            //沒有SD卡或沒有SD卡的存取權限或沒有Extenal Storage，就讀手機本身的內存(Intenal Storage)
            try {
                File cropdir = new File(context.getFilesDir(), staticVar.APP_dir);
                if (!cropdir.exists()) {
                    if (!cropdir.mkdirs())
                        Log.e("cherry", "建立目錄錯誤");
                }
                Log.e("cherry", " 手機內部儲存目錄是" + cropdir.getAbsolutePath());
                mCropFile = new File(cropdir, FILE_NAME);
            } catch (Exception e) {
                Log.e("cherry", "讀取內存目錄發生問題");
            }
        }
        return mCropFile;
    }
    //endregion

    //region 取得設備的IMEI 碼

    /**
     * 获取设备的DeviceId(IMES) 这里需要相应的权限
     * 需要 READ_PHONE_STATE 权限
     *
     * @param context context
     * @return IMEI code
     */

    @SuppressLint("HardwareIds")
    private String getIMEICode(Context context) {
        //String deviceid = "";
        try {
            TelephonyManager manager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            /*
             *  其實android sdk不低於23的API提供了一個帶參數的getDeviceId方法，參數是卡槽號（0或者1），
             *  所以對於android 6.0 (API Level 23)及以上的系統，正確獲取手機 IMEI的寫法應該是下面這種形式：
             *  而API Level 26 以上建議用 getImei() 這個method , 因為getDeviceId() 已在新版本中不建議使用了
             */
            try {
                String imeiCode;
                if (Build.VERSION.SDK_INT >= 26) {
                    Log.e("cherry", "SDK version more than level 26, so using getImei method");
                    imeiCode = manager != null ? manager.getImei(0) : null;  //API level 26 以上才有此method
                } else if (Build.VERSION.SDK_INT >= 23) {
                    imeiCode = manager != null ? manager.getDeviceId(0) : null;
                    Log.e("cherry", "SDK version more than level 23 and less than level 26");
                } else {
                    imeiCode = manager != null ? manager.getDeviceId() : null;
                    Log.e("cherry", "SDK version less than level 23");
                }
                Log.e("cherry", "取到IMIE碼:" + imeiCode);
                return imeiCode;
            } catch (Exception e) {
                Log.d("cherryError", "UniqueID.java==>讀取IMIE error:" + e.toString());
                return null;
            }

        } catch (SecurityException s) {
            //deviceid=s.getMessage();
            Log.e("cherry", "UniquelID.java:get IMIE code error,沒有權限:" + s.getMessage());
            return null;
        }
    }
    //endregion

    //region 取得電話號碼
    public String getPhonenumber(Context context) {
        try {
            TelephonyManager manager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            return manager != null ? manager.getLine1Number() : "";

        } catch (SecurityException s) {
            return "";
        }
    }
    //endregion

    //region 取得MacAddress

    /**
     * 获取设备MAC 地址 由于 6.0 以后 WifiManager 得到的 MacAddress得到都是 相同的没有意义的内容
     * 所以采用以下方法获取Mac地址
     *
     * @return Mac Address
     */
    private String getLocalMac() {
        String macAddress;
        StringBuilder sb = new StringBuilder();
        NetworkInterface networkInterface;
        try {
            networkInterface = NetworkInterface.getByName("eth1");
            if (networkInterface == null) {
                networkInterface = NetworkInterface.getByName("wlan0");
            }
            if (networkInterface == null) {
                return "";
            }
            byte[] addr = networkInterface.getHardwareAddress();


            for (byte b : addr) {
                sb.append(String.format("%02X:", b));
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
            macAddress = sb.toString();
            Log.e("cherry", "macAddress:" + macAddress);
            return macAddress;
        } catch (SocketException e) {
            e.printStackTrace();
            return "";
        }
    }
    //endregion

    //region 將HCID 存入HC_ID.txt

    /**
     * 保存内容到SD卡中,  这里保存的就是 设备唯一标识符
     *
     * @param str     HCID
     * @param context context
     */
    public void saveDeviceID(String str, Context context) {
        try {
            File file = getDevicesDir(context);
            Log.e("cherry","要將device id存入HC_ID.txt中"+str);
            FileOutputStream fos = new FileOutputStream(file);
            Writer out = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
            out.write(str);
            out.close();
        } catch (IOException e) {
            //e.printStackTrace();
            Log.e("cherry", "無法存檔");
        }
    }
    //endregion

    //region md5加密

    /**
     * 对挺特定的 内容进行 md5 加密 (一律轉大寫)
     *
     * @param message 加密明文
     * @return MD5 String
     */
    private String getMD5(String message) {
        String md5str = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");

            byte[] input = message.getBytes();

            byte[] buff = md.digest(input);

            md5str = bytesToHex(buff);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return md5str;
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder md5str = new StringBuilder();
        int digital;

        for (byte aByte : bytes) {
            digital = aByte;
            if (digital < 0) {
                digital += 256;
            }
            if (digital < 16) {
                md5str.append("0");
            }
            md5str.append(Integer.toHexString(digital));
        }

        //if (upperCase) {
        return md5str.toString().toUpperCase();
        //}
        //return md5str.toString().toLowerCase();
    }

    private String getMD5String(String str) {
        try {
            // Create MD5 Hash
            byte[] hash = MessageDigest.getInstance("MD5").digest(str.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                if ((b & 0xFF) < 0x10) {
                    hex.append("0");
                }
                hex.append(Integer.toHexString(b & 0xFF));
            }
            return hex.toString().toUpperCase();
        } catch (Exception e) {
            //e.printStackTrace();
            Log.e("cherry", "getMD5String error:" + e.toString());
            return "";
        }
    }
    //endregion

    /**
     * 存檔
     *
     * @param context  context
     * @param fileName 檔案名稱（不用路徑，一律存至應用程式的目錄底下(HyperConn))
     * @param data     存入的資料
     * @param append   如果檔案已存在，存入的資料是否串接在原內容之後，true:Yes, false:No
     */
    private void saveFile(Context context, String fileName, String data, boolean append) {
        File cropdir = null;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            try {
                cropdir = new File(Environment.getExternalStorageDirectory(), staticVar.APP_dir);
                if (!cropdir.exists()) {
                    if (!cropdir.mkdirs())
                        Log.e("cherry", "在Extenal Storage 建立目錄失敗");
                }
            } catch (Exception e) {
                Log.e("cherry", "讀取Extenal Storage 發生問題");
            }
        } else {
            //沒有Extenal Storage or SD卡 情形下，就讀手機本身的內存(Intenal Storage)
            try {
                cropdir = new File(context.getFilesDir(), staticVar.APP_dir);
                if (!cropdir.exists()) {
                    if (!cropdir.mkdirs())
                        Log.e("cherry", "在intenal Storage 建立目錄失敗");
                }
                Log.e("cherry", " 手機內部儲存目錄是" + cropdir.getAbsolutePath());
            } catch (Exception e) {
                Log.e("cherry", "讀取intenal Storage發生問題");
            }
        }

        File mCropFile;
        if (cropdir != null) {
            data = data != null ? data : "NULL";
            mCropFile = new File(cropdir, fileName);
            if (!mCropFile.exists()) {
                try {
                    if (!mCropFile.createNewFile()) {
                        Log.e("cherry", "無法產生新檔案");
                        return;
                    }
                } catch (IOException e) {
                    Log.e("cherry", "無法產生新檔案:" + e.toString());
                    return;
                }
            } else
                data += "\n" + data;
            try {

                FileOutputStream fos = new FileOutputStream(mCropFile, append);
                Writer out = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
                out.write(data);
                out.close();

            } catch (IOException e) {
                Log.e("cherry", "無法存檔");
            }
        }
    }

}




