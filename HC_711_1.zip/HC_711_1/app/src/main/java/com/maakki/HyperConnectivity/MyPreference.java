package com.maakki.HyperConnectivity;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.preference.Preference;
import android.provider.ContactsContract;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MyPreference extends Preference {
    private int value = 0;
    public ImageView iv_icon;
    Context context;
    View view;

    public MyPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


    @Override
    protected Object onGetDefaultValue(TypedArray a, int index) {
        return a.getInteger(index,8);
    }

    @Override
    protected View onCreateView( ViewGroup parent ) {
        super.onCreateView(parent);
        //LayoutInflater li = (LayoutInflater)getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
        //view = li.inflate(R.layout.mypreference_layout, parent, false);
        return view;
    }

    @Override
    protected void onBindView(View view) {
        this.view=view;
        iv_icon=(ImageView) view.findViewById(R.id.Iv_icon);
        String app_ver = getContext().getResources().getString(R.string.app_ver);
        setSummary(app_ver);
        super.onBindView(view);
    }

    @Override
    protected void onSetInitialValue(boolean restorePersistedValue, Object defaultValue) {
        if (restorePersistedValue) {
            // Restore existing state
            value = this.getPersistedInt(value);
        } else {
            // Set default state from the XML attribute
            value = (Integer) defaultValue;
            persistInt(value);
        }
    }

    public void needToDownloadImage(){
        iv_icon.setImageResource(R.drawable.baseline_cloud_download_green_18dp);
        //notifyChanged();
    }
}