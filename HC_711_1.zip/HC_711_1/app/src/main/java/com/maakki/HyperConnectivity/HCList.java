package com.maakki.HyperConnectivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;

public class HCList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title, tv_message, time, tv_nothing;
    ImageView icon, iv_nothing;
    Integer count;
    FloatingActionButton fab;
    Menu menu;
    private String HCID;
    private Context context;
    private List<HyperConnectivity> listHyperConnectivity, newlist;
    private HyperConnectivityDAO hcDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private HCAdapter adapter;
    private String type = "my";
    BroadcastReceiver receiver;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            menuItem.setVisible(false);
            //menu.getItem(3).setVisible(false);
            switch (menuItem.getItemId()) {
                case R.id.request_hc:
                    String title = "";
                    String message = "";
                    if (getRequestHCAvailable() == 0) {
                        show_RequestHC_Dialog();
                    } else if (getRequestHCAvailable() == 1) {
                        message = getResources().getString(R.string.RequestHC_fail_message1);
                    } else if (getRequestHCAvailable() == 2) {
                        message = getResources().getString(R.string.RequestHC_fail_message2);
                    } else if (getRequestHCAvailable() == 3) {
                        message = getResources().getString(R.string.RequestHC_fail_message3);
                    } else if (getRequestHCAvailable() == 4) {
                        message = getResources().getString(R.string.RequestHC_fail_message4);
                    }
                    if (getRequestHCAvailable() > 0) {
                        title = getResources().getString(R.string.RequestHC_fail_title);
                        showMessageAlertDialog(title, message);
                    }
                    break;
                case R.id.request_activation:
                    //Async_checkisAativate checkisAativate = new Async_checkisAativate();
                    //checkisAativate.execute();
                    if (!new RequestActivationDAO(context).isActivating(HCID)) {
                        showActivationDialog1();
                    } else {
                        showActivationDialog();
                    }
                    break;
                case R.id.ralist:
                    Intent i = new Intent(HCList.this, RAList.class);
                    startActivity(i);
                    break;
                case R.id.myhclist:
                    //Async_checkData checkDataTask1=new Async_checkData();
                    //checkDataTask1.execute("all");
                    type = "all";
                    renewlist(type);
                    break;
                case R.id.allhclist:
                    //Async_checkData checkDataTask2=new Async_checkData();
                    //checkDataTask2.execute("my");
                    type = "my";
                    renewlist(type);

                    break;
            }
            return true;
        }
    };

    private int getRequestHCAvailable() {
        int result = 0;
        if (new ConnectivityBenifitDAO(context).getBalanceByHCID(HCID) < 1000) {
            result = 1;
        } else if (new MemberDAO(context).isRegistered(HCID) & new MemberDAO(context).getExtensioncount(HCID) < 3) {
            result = 2;
        } else if (!new MemberDAO(context).isRegistered(HCID) & new MemberDAO(context).getExtensioncount(HCID) < 6) {
            result = 3;
        } else if (new MemberDAO(context).getHCQ_balance(HCID)<850 ) {
            result = 4;
        }
        return result;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        ShortcutBadger.with(getApplicationContext()).remove();
        listHyperConnectivity = new ArrayList<HyperConnectivity>();
        hcDAO = new HyperConnectivityDAO(this);
        //block = new HyperConnectivity();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();

        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing = (RelativeLayout) findViewById(R.id.RL_nothing);
        //iv_nothing = (ImageView) findViewById(R.id.iv_nothing);
        //iv_nothing.setImageDrawable(getResources().getDrawable(R.drawable.no_cb));
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText(getResources().getString(R.string.RL_nothing_noHC));
        listHyperConnectivity = hcDAO.getByHcid(HCID);
        count = listHyperConnectivity.size();
        adapter = new HCAdapter(this, R.layout.list_item, listHyperConnectivity);
        listview.setAdapter(adapter);
        if (count > 0) {
            //Collections.reverse(listHyperConnectivity);
            myToolbar.setTitle(getResources().getString(R.string.HCList_toolbar) + " " + Utils.formatDoubleToString(hcDAO.getSumByHcid(HCID)));
        } else {
            RL_nothing.setVisibility(View.VISIBLE);
        }
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_HCList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renewlist(type);

            }
        };
        registerReceiver(receiver, filter);
        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Boolean b1 = new MemberDAO(context).isRegistered(HCID) ;
        Boolean b2 = !new RequestActivationDAO(context).isActivating(HCID);
        //Toast.makeText(context,"isRegistered: "+b1+" / notActivating: "+b2,Toast.LENGTH_LONG).show();
        //Async_checkData checkDataTask = new Async_checkData();
        //checkDataTask.execute("all");
        /*if(new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)){
            setOnClick();
        }*/
    }
    public void setOnClick() {
        listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                HyperConnectivity hc = listHyperConnectivity.get(position);
                if (swipeDetector.swipeDetected()) {
                    deleteCell(v, position);
                    hcDAO.delete(hc.getId());
                    myToolbar.setTitle(getResources().getString(R.string.HCList_toolbar)+" "+hcDAO.getCount());
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        //finish();
    }


    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_hclist, menu);
        this.menu = menu;
        if (new MemberDAO(context).isRegistered(HCID) &
                !new RequestActivationDAO(context).isActivating(HCID)) {
                menu.getItem(1).setVisible(true);
        }else{
            menu.getItem(4).setVisible(true);
        }
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class HCAdapter extends ArrayAdapter<HyperConnectivity> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public HCAdapter(Context context, int textViewResourceId, List<HyperConnectivity> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            HyperConnectivity hc = (HyperConnectivity) getItem(position);

            if (convertView == null) {
                //Toast.makeText(HCList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();
            int icon = R.drawable.ic_launcher;
            String title = Utils.formatDoubleToString(hc.getAmount()) + " #" + hc.getBlockIndex() + " " + hc.getNote();
            holder.text_title.setText(title);
            holder.text_message.setText(hc.getHcid());
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            String fm = formatter.format(hc.getCreateTime());
            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            return view;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

    private void renewlist(String type) {
        listHyperConnectivity.clear();
        if (type.equals("all")) {
            for (HyperConnectivity hc : new HyperConnectivityDAO(context).getAll()) {
                listHyperConnectivity.add(hc);
            }
            //Collections.reverse(listHyperConnectivity);
            menu.getItem(3).setVisible(true);
        } else if (type.equals("my")) {
            for (HyperConnectivity hc : hcDAO.getByHcid(HCID)) {
                listHyperConnectivity.add(hc);
            }
            menu.getItem(2).setVisible(true);
        }
        adapter.notifyDataSetChanged();
        if (listHyperConnectivity.size() > 0) {
            RL_nothing.setVisibility(View.GONE);
            if (type.equals("all")) {
                myToolbar.setTitle(getResources().getString(R.string.HCList_toolbar) + " " + Utils.formatDoubleToString(hcDAO.getSum()));
            } else {
                myToolbar.setTitle(getResources().getString(R.string.HCList_toolbar) + " " + Utils.formatDoubleToString(hcDAO.getSumByHcid(HCID)));
            }
        } else {
            RL_nothing.setVisibility(View.VISIBLE);
            myToolbar.setTitle("");
        }
    }


    public void showActivationDialog() {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = HCList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        ImageView iv = (ImageView) view.findViewById(R.id.iv);
        iv.setImageDrawable(getResources().getDrawable(R.drawable.ic_launcher));
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        String title = getResources().getString(R.string.hclist_dialog_fail_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        String message = getResources().getString(R.string.hclist_dialog_fail_message);
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        String submessage = getResources().getString(R.string.hclist_dialog_fail_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(HCList.this, RAList.class);
                        startActivity(i);
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public void showActivationDialog1() {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = HCList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        ImageView iv = (ImageView) view.findViewById(R.id.iv);
        iv.setImageDrawable(getResources().getDrawable(R.drawable.ic_launcher));
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        String title = getResources().getString(R.string.hclist_dialog_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        String message1 = getResources().getString(R.string.hclist_dialog_message1);
        String message2 = getResources().getString(R.string.hclist_dialog_message2);
        String message = message1 + getEstimatedDate() + message2;
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        String submessage = getResources().getString(R.string.hclist_dialog_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        RequestActivation ra = new RequestActivation();
                        ra.setApplicant(HCID);
                        String cashflow1 = getResources().getString(R.string.hcid_cashflow_1);
                        ra.setCashflow_1(cashflow1);
                        Double amount = multiply(
                                Double.parseDouble(getResources().getString(R.string.activation_fee)),
                                Double.parseDouble(getResources().getString(R.string.exchangerate_RMB)));

                        ra.setAmount(amount);
                        ra.setCurrency("RMB");
                        ra.setCreateTime(new Date().getTime());
                        String hash = ra.calculateHash(ra);
                        ra.setHash(hash);
                        String datatype = "Activation";
                        String note = getResources().getString(R.string.note_status20);
                        String data = hash + " " + HCID + " 20 " + cashflow1 + " " + amount + " RMB " + new Date().getTime() + " " + note;
                        makeBlock(datatype, data);
                        Block block = new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        //showAlertDialog("BlockMessage",block.toString());
                        insertRADAO(block);
                        showActivationDialog2(hash);
                        dialog.dismiss();
                    }
                });

        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_termsofservice),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i=new Intent(context,ServiceTerm_Activity.class);
                        startActivity(i);
                        //dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        Button theButton = alertDialog.getButton(DialogInterface.BUTTON_NEUTRAL);
        theButton.setOnClickListener(new CustomListener(alertDialog));
    }

    public void showActivationDialog2(String hash) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = HCList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        ImageView iv = (ImageView) view.findViewById(R.id.iv);
        iv.setImageDrawable(getResources().getDrawable(R.drawable.ic_launcher));
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        String title = getResources().getString(R.string.hclist_dialog2_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        String message1 = getResources().getString(R.string.hclist_dialog2_message);
        String message2 = getResources().getString(R.string.bankdata_accountname_cashflow_1) + "\n" +
                getResources().getString(R.string.bankdata_accountno_cashflow_1) + "\n" +
                getResources().getString(R.string.bankdata_bankname_cashflow_1) + "\n" +
                getResources().getString(R.string.bankdata_branchname_cashflow_1);
        String message = message1 + "\n\n" + message2;
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        String submessage = getResources().getString(R.string.hclist_dialog2_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_now),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(HCList.this, RAList.class);
                        i.putExtra("Message", hash);
                        startActivity(i);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_later),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(HCList.this, RAList.class);
                        startActivity(i);
                        dialog.dismiss();

                    }
                });
        alertDialog.show();
    }

    public String getEstimatedDate() {
        Date d = new Date();
        Long satrtdate = d.getTime() + 24 * 60 * 60 * 1000;
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy.MM.dd");
        int rank = new RequestActivationDAO(context).getRankByWeight(HCID);
        long interval_time = 1000 * 60 * 60 * 24 * rank * Long.parseLong(getResources().getString(R.string.intervalDays_activation_estimation));
        return dt1.format(satrtdate + interval_time);
        //return String.valueOf(interval_time);
    }

    public void showAlertDialog(String title, String message) {
        //is_Dialog_Display = true;
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //is_Dialog_Display = false;
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //is_Dialog_Display = false;
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public double multiply(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.multiply(b2).doubleValue();
    }

    private void insertRADAO(Block block) {
        RequestActivation ra = new RequestActivation();
        //data=hash+" "+HCID+" 20 "+cashflow1+" "+amount+" RMB "+new Date().getTime();
        ra.setHash(block.getData().split(" ")[0]);
        ra.setApplicant(block.getData().split(" ")[1]);
        ra.setStatus(Integer.parseInt(block.getData().split(" ")[2]));
        ra.setCashflow_1(block.getData().split(" ")[3]);
        ra.setAmount(Double.parseDouble(block.getData().split(" ")[4]));
        ra.setCurrency(block.getData().split(" ")[5]);
        ra.setCreateTime(Long.parseLong(block.getData().split(" ")[6]));
        ra.setCashflow_2(getResources().getString(R.string.hcid_cashflow_2));
        ra.setBlockIndex_lastupdate(block.getIndex());
        ra.setWeight(new MemberDAO(context).getWeight(block.getData().split(" ")[1]));
        ra.setNote(block.getData().split(" ")[7]);
        new RequestActivationDAO(context).insert(ra);
    }

    private class Async_checkisAativate extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            return checkData();
        }

        @Override
        protected void onPostExecute(Boolean result) {
            //RL_nothing.setVisibility(View.GONE);
            //if (!result) {
                showActivationDialog1();
            /*} else {
                showActivationDialog();
            }*/
        }

        @Override
        protected void onPreExecute() {
            //RL_nothing.setVisibility(View.VISIBLE);
            //tv_nothing.setText(getResources().getString(R.string.Async_checkdata_Onpre));
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }
    }

    private Boolean checkData() {
        BlockchainDAO blockchainDAO = new BlockchainDAO(context);
        RequestActivationDAO raDAO = new RequestActivationDAO(context);
        raDAO.clear();
        for (Block block : blockchainDAO.getAll()) {
            if (block.getDatatype().equals("Activation")) {
                insertRADAO(block);
            }
        }
        for (Block block : new BlockDAO(context).getAll()) {
            if (block.getDatatype().equals("Activation")) {
                insertRADAO(block);
            }
        }
        for (RequestActivation ra : raDAO.getAll()) {
            ra.setWeight(new MemberDAO(context).getWeight(ra.getApplicant()));
            raDAO.update(ra);
        }
        return raDAO.isActivating(HCID);
    }

    public void showMessageAlertDialog(String title, String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        LayoutInflater inflater = HCList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        alertDialog.show();
    }

    public void show_RequestHC_Dialog() {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        LayoutInflater inflater = HCList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.cb_order_dialog, null);
        ImageView iv = (ImageView) view.findViewById(R.id.iv);
        iv.setImageDrawable(getResources().getDrawable(R.drawable.ic_launcher_round));
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        String title = getResources().getString(R.string.RequestHC_title);
        tv_title.setText(title);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        String message1 = getResources().getString(R.string.RequestHC_message1);
        String message2 = getResources().getString(R.string.RequestHC_message2);
        String message3 = getResources().getString(R.string.RequestHC_message3);
        String message4 = getResources().getString(R.string.addorder_sell_message5);
        //String message=message1 +new MemberDAO(context).getCBQ_balance(HCID)+ " " +message2+ getEstimatedDate() + message3;
        String message = message1 + "1,000" + message2 + getEstimatedHC() + " " + message3 + getEstimatedFee(1000d) + " " + message4;
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        String submessage = getResources().getString(R.string.hclist_dialog_submessage);
        tv_submessage.setText(submessage);
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String datatype="getHC";
                        String amount=getEstimatedHC();
                        String note="fromCB";
                        String data= HCID +" "+amount+" "+note;
                        Block block=new Block();
                        block.setDatatype(datatype);
                        block.setData(data);
                        block.insertHCDAO(context,block);
                        makeBlock(datatype,data);
                        type="my";
                        renewlist(type);
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_termsofservice),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i=new Intent(context,ServiceTerm_Activity.class);
                        startActivity(i);
                        //dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        Button theButton = alertDialog.getButton(DialogInterface.BUTTON_NEUTRAL);
        theButton.setOnClickListener(new CustomListener(alertDialog));
    }

    public String getEstimatedHC() {
        return Utils.formatDoubleToString(1000 * 0.85);
    }

    private String getEstimatedFee(Double d){
        Double result;
        if(new MemberDAO(context).isRegistered(HCID)){
            result=d*0.15;
        }else {
            result=d*0.5;
        }
        return Utils.formatDoubleToString(result);
    }

    private void makeBlock(String datatype, String data) {
        Intent intent = new Intent(HCList.this, CoreService.class);
        intent.putExtra("Message", datatype + ":" + data);
        startService(intent);
        /*String message=datatype + ":" + data;
        String data1 = message.split(":")[1];
        if(data.split(" ")[2].equals("fromCB")){
            String applicant=new MemberDAO(context).getIntroducerHCID(data.split(" ")[0]);
            String amount=Utils.formatDoubleToString(Double.parseDouble(data.split(" ")[1])*0.05);
            String note="intro_fromCB";
            String datatype1="getHC";
            data=applicant+" "+amount+" "+note;
            message=datatype1+":"+data1;
            Block block=new Block();
            block.setDatatype(datatype1);
            block.setData(data1);
            insertHCDAO(block);
        }*/
    }

    private void deleteCell(final View v, final int index) {
        Animation.AnimationListener al = new Animation.AnimationListener() {
            //@Override
            public void onAnimationEnd(Animation arg0) {
                listHyperConnectivity.remove(index);
                count--;
                if (count < 2) {
                    fab.setVisibility(View.INVISIBLE);
                    if (count < 1) {
                        listview.setVisibility(View.GONE);
                    }
                }
                if (count == 0) {
                    RL_nothing.setVisibility(View.VISIBLE);
                }
                //tv.setText("(" + count + ")");
                ViewHolder vh = (ViewHolder) v.getTag();
                vh.needInflate = true;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        };
        collapse(v, al);
    }

    private void collapse(final View v, Animation.AnimationListener al) {
        final int initialHeight = v.getMeasuredHeight();
        final int top = v.getTop();
        //Toast.makeText(getApplicationContext(), "collapsetop:"+top , Toast.LENGTH_SHORT).show();
        final int ANIMATION_DURATION = 200;
        Animation anim = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {

                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (al != null) {
            anim.setAnimationListener(al);
        }
        anim.setDuration(ANIMATION_DURATION);
        v.startAnimation(anim);
    }
    class CustomListener implements View.OnClickListener {
        private final Dialog dialog;

        public CustomListener(Dialog dialog) {
            this.dialog = dialog;
        }

        @Override
        public void onClick(View v) {
            // Do whatever you want here
            Intent i=new Intent(context,ServiceTerm_Activity.class);
            startActivity(i);
            // If you want to close the dialog, uncomment the line below
            //dialog.dismiss();
        }
    }
}
