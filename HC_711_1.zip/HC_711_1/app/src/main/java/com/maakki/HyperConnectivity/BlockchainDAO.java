package com.maakki.HyperConnectivity;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


// 資料功能類別
public class BlockchainDAO {
    Context context;
    // 表格名稱
    public static final String TABLE_NAME = "Blockchain";
    //保存的文件 采用隐藏文件的形式进行保存
    //private static final String FILE_DIR = "HyperConn";
    //private static final String FILE_NAME = TABLE_NAME + ".txt";

    // 編號表格欄位名稱，固定不變
    public static final String KEY_Id = "_id";
    public static final String maker_Column = "maker";
    public static final String KEY_INDEX = "_index";
    public static final String timestamp_Column = "timestamp";
    public static final String nonce_Column = "nonce";
    public static final String previousHash_Column = "previousHash";
    public static final String hash_Column = "hash";
    public static final String datatype_Column = "datatype";
    public static final String data_COLUMN = "data";
    public static final String CreateTime_COLUMN = "CreateTime";
//public static final String CreateTime_COLUMN = "CreateTime";

    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_Id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    maker_Column + " TEXT NOT NULL, " +
                    KEY_INDEX + " REAL NOT NULL, " +
                    timestamp_Column + " REAL NOT NULL, " +
                    nonce_Column + " INTEGER NOT NULL, " +
                    previousHash_Column + " TEXT, " +
                    hash_Column + " TEXT NOT NULL, " +
                    datatype_Column + " TEXT NOT NULL, " +
                    data_COLUMN + " TEXT NOT NULL, " +
                    CreateTime_COLUMN + " REAL NOT NULL)";
    // 資料庫物件
    private SQLiteDatabase db;

    // 建構子，一般的應用都不需要修改
    public BlockchainDAO(Context context) {
        this.context = context;
        db = BlockchainDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public Block insert(Block block) {
        // 建立準備新增資料的ContentValues物件
        ContentValues cv = new ContentValues();
        long createtime = new Date().getTime();

        // 加入ContentValues物件包裝的新增資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(maker_Column, block.getMaker());
        cv.put(KEY_INDEX, block.getIndex());
        cv.put(timestamp_Column, block.getTimestamp());
        cv.put(nonce_Column, block.getNonce());
        cv.put(previousHash_Column, block.getPreviousHash());
        cv.put(hash_Column, block.getHash());
        cv.put(datatype_Column, block.getDatatype());
        cv.put(data_COLUMN, block.getData());
        cv.put(CreateTime_COLUMN, createtime);
        // 新增一筆資料並取得編號
        // 第一個參數是表格名稱
        // 第二個參數是沒有指定欄位值的預設值
        // 第三個參數是包裝新增資料的ContentValues物件
        long id = db.insert(TABLE_NAME, null, cv);

        // 設定編號
        block.setId(id);

        // 回傳結果
        return block;
    }

    // 修改參數指定的物件
    public boolean update(Block block) {
        // 建立準備修改資料的ContentValues物件
        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(KEY_INDEX, block.getIndex());
        cv.put(maker_Column, block.getMaker());
        cv.put(timestamp_Column, block.getTimestamp());
        cv.put(nonce_Column, block.getNonce());
        cv.put(previousHash_Column, block.getPreviousHash());
        cv.put(hash_Column, block.getHash());
        cv.put(datatype_Column, block.getDatatype());
        cv.put(data_COLUMN, block.getData());
        cv.put(CreateTime_COLUMN, block.getCreateTime());
        // 提醒日期時間
        //cv.put(ALARMDATETIME_COLUMN, store.getAlarmDatetime());

        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        String where = KEY_Id + "=" + block.getId();

        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_Id + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    // 刪除參數指定編號的資料
    public void deletebyIndex(long index) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_INDEX + "=" + index;
        // 刪除指定編號資料並回傳刪除是否成功
        db.delete(TABLE_NAME, where, null);
        //return db.delete(TABLE_NAME, where, null) > 0;
    }

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }
    public void clear() {
        for(Block block:getAll()){
            delete(block.getId());
        }
    }
    // 讀取所有記事資料
    public List<Block> getAll() {
        List<Block> result = new ArrayList<>();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }
        cursor.close();
        return result;
    }

    // 讀取所有記事資料
    public List<Block> getBlockList(long start_index, long end_index) {
        List<Block> result = new ArrayList<>();
        String SELECTION = KEY_INDEX + ">=" + start_index + " AND " + KEY_INDEX + "<=" + end_index;
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTION, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }
        cursor.close();
        return result;
    }

    public boolean isExisted(String hash) {
        boolean result = false;
        String SELECTSTRING = hash_Column + "='" + hash + "'";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result = true;
        }
        cursor.close();
        return result;
    }

    // 取得指定編號的資料物件
    public Block get(long id) {
        // 準備回傳結果用的物件
        Block result = new Block();
        // 使用編號為查詢條件
        String SELECTSTRING = KEY_Id + "=" + id;
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }
        // 關閉Cursor物件
        cursor.close();
        // 回傳結果
        return result;
    }

    // 取得最大id的区块
    public Block getBlock_MaxId() {
        // 準備回傳結果用的物件
        Block result = new Block();
        // 使用編號為查詢條件
        //String SELECTSTRING = KEY_Id + "=" + id;
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, KEY_Id + " DESC", null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }
        // 關閉Cursor物件
        cursor.close();
        // 回傳結果
        return result;
    }

    // 讀取所有記事資料
    public Block getByIndex(long index) {
        Block result = new Block();
        String SELECTSTRING = KEY_INDEX + "=" + index;

        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }
        cursor.close();
        return result;
    }

    public Block getPreviousblock(Block b) {
        Block result = null;
        String SELECTSTRING = hash_Column + "='" + b.getPreviousHash() + "'";

        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            if(new Blockchain(4,context).isValidNewBlock(b,getRecord(cursor))) {
                result = getRecord(cursor);
            }
        }
        cursor.close();
        return result;
    }

    /*public Block getAskMaker_StartBlock(Block block) {
        Block result = new Block();
        String SELECTSTRING = maker_Column + "='" + block.getMaker() + "' AND " +
                KEY_INDEX + "<" + block.getIndex();

        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, KEY_INDEX + " DESC", null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }
        cursor.close();
        return result;
    }*/

    //region 依dataType 取得block 的資料
    /*public List<Block> getBlockListByDatatype(String datatype) {
        List<Block> result = new ArrayList<>();
        String SELECTION = datatype_Column + "='" + datatype + "'";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTION, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }
        cursor.close();
        return result;
    }*/
    //endregion

    //region 取得最後一個block 的maker
    /*public String getMakerofLastestBlock() {
        String result = "";
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, KEY_INDEX + " DESC", null);

        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            result = getRecord(cursor).getMaker();
        }
        cursor.close();
        return result;
    }*/
    //endregion

    //region 取得最後一筆block (order by _index desc)
    public Block getBlock_MaxIndex() {
        Block result = new Block();
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, KEY_INDEX + " DESC", null);
        // 如果有查詢結果
        if (cursor.moveToFirst()) {
            //讀取包裝一筆資料的物件
            result = getRecord(cursor);
        }
        cursor.close();
        return result;
    }
    //endregion

    //region 把Cursor目前的資料包裝為block物件
    public Block getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        Block result = new Block();
        result.setId(cursor.getLong(0));
        result.setMaker(cursor.getString(1));
        result.setIndex(cursor.getLong(2));
        result.setTimestamp(cursor.getLong(3));
        result.setNonce(cursor.getInt(4));
        result.setPreviousHash(cursor.getString(5));
        result.setHash(cursor.getString(6));
        result.setDatatype(cursor.getString(7));
        result.setData(cursor.getString(8));
        result.setCreateTime(cursor.getLong(9));

        // 回傳結果
        return result;
    }
    //endregion

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }
    /*public Boolean testRegistering(String HCID,Block b){
        if (!b.getMaker().equals(HCID)) {
            //As a maker of Block#0 ,Although not the maker of registration ,help to repack block "Registration" not registered yet
            if(b.getDatatype().equals("Registration") &
                    isRegistering(b.getData().split(" ")[1]) == null &
                    getByIndex(0).getMaker().equals(HCID)) {
                //repackBlock(b);
                return true;
            }
        }else{
            if(b.getDatatype().equals("Registration") &
                    isRegistering(b.getData().split(" ")[1]) != null) {
            }else{
                if(b.getDatatype().equals("getPCB") &
                        !(getByIndex(0).getMaker().equals(HCID) & b.getMaker().equals(HCID))){
                }else{
                    //repackBlock(b);
                    return true;
                }
            }
        }
        return  false;
    }*/
    public Block isRegistering(String hcid) {
        Block block = null;
        List<Block> listBlock = new ArrayList<>();
        String SELECTSTRING = datatype_Column + "='Registration'";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTSTRING, null, null, null, null, null);

        while (cursor.moveToNext()) {
            listBlock.add(getRecord(cursor));
        }
        cursor.close();
        for (Block b : listBlock) {
            if (b.getData().split(" ")[1].equals(hcid)) {
                block = b;
                break;
            }
        }
        return block;
    }


    public long getLastTimeOfHCtoPCB(String hcid){
        long result=0L;
        List<Block> resultlist=new ArrayList<>();
        //List<HyperConnectivity> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = datatype_Column+"='getHC'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, KEY_Id+" DESC", null);

        while (cursor.moveToNext()) {
            resultlist.add(getRecord(cursor));
        }
        for(Block block:resultlist){
            if(block.getData().split(" ")[0].equals(hcid)&
               block.getData().split(" ")[1].startsWith("-")){
                result=block.getTimestamp();
                break;
            }
        }
        cursor.close();
        return result;
    }

    public JSONArray getResults() {

        //String myPath = FILE_DIR + FILE_NAME;// Set path to your database
        //String myPath = context.getDatabasePath(BlockchainDBHelper.DATABASE_NAME).getPath();

        File outFile =context.getDatabasePath(BlockchainDBHelper.DATABASE_NAME);
        String myPath =outFile.getPath() ;

        //String myTable = TABLE_NAME; //Set name of your table
        //or you can use `context.getDatabasePath("my_db_test.db")`

        SQLiteDatabase myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY);

        String searchQuery = "SELECT  * FROM " + TABLE_NAME;
        Cursor cursor = myDataBase.rawQuery(searchQuery, null);

        JSONArray resultSet = new JSONArray();

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int totalColumn = cursor.getColumnCount();
            JSONObject rowObject = new JSONObject();

            for (int i = 0; i < totalColumn; i++) {
                if (cursor.getColumnName(i) != null) {
                    if(cursor.getColumnName(i).equals(CreateTime_COLUMN)||cursor.getColumnName(i).equals(timestamp_Column)){
                        try {
                            rowObject.put(cursor.getColumnName(i), String.valueOf(cursor.getLong(i)));
                        } catch (Exception e) {
                            Log.d("TAG_NAME", e.getMessage());
                        }
                    } else if(cursor.getColumnName(i).equals(data_COLUMN)){
                        //cursor.getString(i).replaceAll(""+(char)(10),"c##10");
                        //cursor.getString(i).replaceAll(""+(char)(13),"c##13");
                        //cursor.getString(i).replaceAll("\\r","c##13").replaceAll("\\n","c##10");
                        try {
                            rowObject.put(cursor.getColumnName(i), cursor.getString(i).replaceAll("\\r","c##13").replaceAll("\\n","c##10"));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    } else {
                        try {
                            if (cursor.getString(i) != null) {
                                Log.d("TAG_NAME", cursor.getString(i));
                                rowObject.put(cursor.getColumnName(i), cursor.getString(i));
                            } else {
                                rowObject.put(cursor.getColumnName(i), "");
                            }
                        } catch (Exception e) {
                            Log.d("TAG_NAME", e.getMessage());
                        }
                    }

                }
            }
            resultSet.put(rowObject);
            cursor.moveToNext();
        }
        cursor.close();
        Log.d("TAG_NAME", resultSet.toString());
        return resultSet;
    }
}