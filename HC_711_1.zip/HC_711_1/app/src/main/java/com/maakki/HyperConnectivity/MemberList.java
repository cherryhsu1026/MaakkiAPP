package com.maakki.HyperConnectivity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;

public class MemberList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon,iv_nothing;
    Integer count;
    FloatingActionButton fab;
    private boolean isRedenvelope = false, isAscending = false;
    private String sendernickname = "", message = "", contactnick = "", mMemID,mMaakkiID,HCID;
    private Boolean isActivate;
    private Context context;
    private List<Member> listMember, newlist;
    private MemberDAO memberDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private MemberAdapter adapter;
    private BroadcastReceiver receiver,receiver1;
    //String cMemid = "";
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private Double pcb_registration=25d;
    private int Multipy_HCtoPCB=3;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            switch (menuItem.getItemId()) {
                case R.id.delete:
                    if(memberDAO.getCount()>0){
                        AlertDialog alertDialog = new AlertDialog.Builder(MemberList.this).create();
                        alertDialog.setTitle("将要删除会员记录");
                        alertDialog.setMessage("您确定要删除所有的会员记录吗？");
                        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "确定",
                                (dialog, which) -> {
                                    dialog.dismiss();
                                    listview.setVisibility(View.INVISIBLE);
                                    fab.setVisibility(View.INVISIBLE);
                                    RL_nothing.setVisibility(View.VISIBLE);
                                    memberDAO.deleteAll();
                                    memberDAO=new MemberDAO(context);
                                    listMember.clear();
                                    myToolbar.setTitle("");
                                    adapter.notifyDataSetChanged();
                                });
                        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "略过",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                    }else{
                        showAlertDialog("Not Available","No any member record!");
                    }
                    break;
                case R.id.applyblock:
                    Intent i =new Intent(MemberList.this,applyBlockList.class);
                    startActivity(i);
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //mMaakkiID=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key0,"");
        //HCID=SharedPreferencesHelper.getSharedPreferencesString(context,SharedPreferencesHelper.SharedPreferencesKeys.key100,"");
        HCID = Utils.setMyHCID(context);
        ShortcutBadger.with(getApplicationContext()).remove();
        listMember = new ArrayList<Member>();
        memberDAO = new MemberDAO(this);
        listMember = memberDAO.getAll();
        count = listMember.size();
        myToolbar = findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        if(memberDAO.getCount()>0){
            myToolbar.setTitle(getResources().getString(R.string.title_particiapnt)+" "+memberDAO.getCount());
        }else{
            myToolbar.setTitle("");
        }
        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no member recorded..");
        //iv_nothing=(ImageView)findViewById(R.id.iv_nothing);
        //iv_nothing.setImageDrawable(getResources().getDrawable(R.drawable.no_nothing));
        //tv = (TextView) findViewById(R.id.tv);

        Collections.reverse(listMember);
        adapter = new MemberAdapter(this, R.layout.list_item, listMember);
        listview.setAdapter(adapter);
        if (count > 0) {
            if (count > 10) {
                fab.setVisibility(View.VISIBLE);
            }
            fab.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }

                    Collections.reverse(listMember);
                    adapter.notifyDataSetChanged();
                }
            });

        } else {
            //tv.setText("");
            RL_nothing.setVisibility(View.VISIBLE);
        }
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_MemberList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renewlist();
            }
        };
        registerReceiver(receiver, filter);
        IntentFilter filter1 = new IntentFilter();
        filter1.addAction("INVOKE_MemberList1");
        receiver1 = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String message=intent.getStringExtra("What");
                showAlertDialog("Memderdata incorrect",message);
            }
        };
        registerReceiver(receiver1, filter1);
        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //Async_checkData checkDataTask=new Async_checkData();
        //checkDataTask.execute();
        if(new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)){
            setOnClick();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }
    public void setOnClick() {
        //listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Member m = listMember.get(position);
                int status=0;
                Double pcb_comp_reg=pcb_registration-new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(), "registration");
                Double pcb_comp_intro=new MemberDAO(context).getintro_PCB(m.getHcid())-new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(), "introduction");
                Double pcb_comp_fromHC=new HyperConnectivityDAO(context).getSumtoPCBByHcid(m.getHcid())*3-new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(),"fromHC");
                Double HC_comp_fromCB= new ConnectivityBenifitDAO(context).getSumtoHC(m.getHcid())*0.85-new HyperConnectivityDAO(context).getSumfromCBByHcid(m.getHcid());
                Double HC_comp_fromintroCB= new ConnectivityBenifitDAO(context).getSumintrotoHC(m.getHcid())*0.85*0.05-new HyperConnectivityDAO(context).getSumintro_fromCBByHcid(m.getHcid());
                Double CB_sell_CBOrder=new CB_OrderDAO(context).getCBSum_SellByHcid(m.getHcid());
                Double CB_sellCB = new ConnectivityBenifitDAO(context).getCBSum_SellByHcid(m.getHcid());
                Double CB_comp_sellCB=CB_sell_CBOrder-CB_sellCB;
                //Long intervaTime = new Date().getTime() - new HyperConnectivityDAO(context).getLastTimeToPcbByHcid(m.getHcid());
                //Long intervaTime0 = new Date().getTime() - new BlockchainDAO(context).getLastTimeOfHCtoPCB(m.getHcid());
                //Long intervaTime1 = new Date().getTime() - new BlockDAO(context).getLastTimeOfHCtoPCB(m.getHcid());
                String message=
                                "Block #"+new BlockchainDAO(context).isRegistering(m.getHcid()).getIndex()+"\n"+
                                "ROI: "+ Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getGR_byPhase(m.getHcid())*100)+" %\n"+
                                "PCB_Balance: "+Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getBalanceByHCID(m.getHcid()))+"\n"+ "PCB_Registration: "+Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(),"registration"))+"\n"+
                                "PCB_Introduction: "+new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(), "introduction")+"\n"+
                                //"PCB_Introduction: "+Utils.formatDoubleToString(new MemberDAO(context).getintro_PCB(m.getHcid()))+" / "+new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(), "introduction")+"\n"+
                                "Extension member: "+memberDAO.getExtensioncount(m.getHcid())+"\n"+
                                "HC_Balance: "+Utils.formatDoubleToString(new HyperConnectivityDAO(context).getBalanceByHCID(m.getHcid()))+"\n"+
                                "HC_toPCB: "+Utils.formatDoubleToString(new HyperConnectivityDAO(context).getSumtoPCBByHcid(m.getHcid()))+"\n"+
                                //"HC_fromCB: "+Utils.formatDoubleToString(new HyperConnectivityDAO(context).getSumfromCBByHcid(m.getHcid()))+"\n"+
                                //"HC_fromCB: "+ new ConnectivityBenifitDAO(context).getSumtoHC(m.getHcid())*0.85+" / "+new HyperConnectivityDAO(context).getSumfromCBByHcid(m.getHcid())+"\n"+
                                 "HC_introfromCB: "+Utils.formatDoubleToString(new HyperConnectivityDAO(context).getSumintro_fromCBByHcid(m.getHcid()))+"\n"+
                                        "HCQ " + getResources().getString(R.string.HA_sum) + ": "+Utils.formatDoubleToString(new MemberDAO(context).getHCQ_sum(m.getHcid()))+"\n"+
                                        "HCQ " + context.getResources().getString(R.string.HA_Oedered) + ": "+Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getSumtoHC(m.getHcid())*0.85)+"\n"+
                                        "HCQ " + getResources().getString(R.string.HA_balance) + ": "+Utils.formatDoubleToString(new MemberDAO(context).getHCQ_balance(m.getHcid()))+"\n"+

                                        "PCB_fromHC: "+Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(),"fromHC"))+"\n"+
                                "PCB_activity: "+Utils.formatDoubleToString(new preConnectivityBenifitDAO(context).getPCBForWhat(m.getHcid(),"activity"))+"\n"+
                                "CB_Balance: "+Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getBalanceByHCID(m.getHcid()))+"\n"+
                                "CB_toHC: "+Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getSumtoHC(m.getHcid()))+"\n"+
                                "CB_introtoHC: "+Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getSumintrotoHC(m.getHcid()))+"\n"+
                                "CB_Order: "+ Utils.formatDoubleToString(new CB_TradingDAO(context).getCBSum_Exchanged(m.getHcid()))+"\n"+
                                "CB_Sold: "+ Utils.formatDoubleToString(CB_sell_CBOrder)+"\n"+
                                "CB_OnSale: "+ Utils.formatDoubleToString(CB_sellCB)+"\n"+
                                "CBQ " + context.getResources().getString(R.string.HA_sum) + ": "+Utils.formatDoubleToString(new MemberDAO(context).getCBQ_sum(m.getHcid()))+"\n"+
                                "CBQ " + context.getResources().getString(R.string.HA_Oedered) + ": "+Utils.formatDoubleToString(new CB_OrderDAO(context).getUSDSum_CBOrderByHcid(m.getHcid()))+"\n"+
                                //"CBQ order details" + ": "+new CB_OrderDAO(context).getUSDSum_CBOrderDetails(m.getHcid())+"\n"+
                                "CBQ " + context.getResources().getString(R.string.HA_balance) + ": "+Utils.formatDoubleToString(new MemberDAO(context).getCBQ_balance(m.getHcid()))+"\n"+
                                /*"PCB_ShouldTake: "+Utils.formatDoubleToString(memberDAO.getCalculatedPCB_registration_introduction(m.getHcid()))+"\n"+*/
                                "pcb_comp_reg: "+pcb_comp_reg+"\n"+
                                "pcb_comp_intro: "+pcb_comp_intro+"\n"+
                                "pcb_comp_fromHC: "+ Utils.formatDoubleToString(pcb_comp_fromHC)+"\n"+
                                "HC_comp_fromCB: "+ Utils.formatDoubleToString(HC_comp_fromCB)+"\n"+
                                "HC_comp_fromintroCB: "+ Utils.formatDoubleToString(HC_comp_fromintroCB)+"\n"+
                                "CB_comp_sellCB: "+Utils.formatDoubleToString(CB_comp_sellCB)
                        ;


                showMessageAlertDialog(m.getHcid(),message,pcb_comp_reg,pcb_comp_intro,pcb_comp_fromHC,HC_comp_fromCB,HC_comp_fromintroCB,CB_comp_sellCB);
            }
        });
    }
    public void showMessageAlertDialog(String hcid,String message,Double pcb_comp_reg,Double pcb_comp_intro,Double pcb_comp_fromHC,Double HC_comp_fromCB,Double HC_comp_fromintroCB,Double CB_comp_sellCB) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();        //String apk_name="HyperConn.apk";
        LayoutInflater inflater = MemberList.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.download_newapk_dialog, null);
        TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
        tv_title.setText(hcid);
        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        tv_message.setText(message);
        TextView tv_submessage = (TextView) view.findViewById(R.id.tv_submessage);
        tv_submessage.setText("make a block?");
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        //if(pcb_compensate1!=0d){
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL,"校正",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            if(new ConnectivityBenifitDAO(context).getBalanceByHCID(hcid)<0){
                                String datatype="getHC";
                                String amount="-850";
                                String note="fromCB";
                                String data= hcid +" "+amount+" "+note;
                                Block block=new Block();
                                block.setDatatype(datatype);
                                block.setData(data);
                                block.insertHCDAO(context,block);
                                makeBlock(datatype,data);
                            }
                            if(pcb_comp_reg!=0d){
                                String what = "registration";
                                String datatype="getPCB";
                                //Double amount=new preConnectivityBenifitDAO(context).getPCBForWhat(hcid,"registration")-pcb_registration;
                                String data = hcid + " "+Utils.formatDoubleToString(pcb_comp_reg)+" " + what;
                                makeCompBlock(datatype,data);
                            }
                            if(pcb_comp_intro!=0d){
                                String what = "introduction";
                                String datatype="getPCB";
                                String data = hcid + " "+Utils.formatDoubleToString(pcb_comp_intro)+" " + what;
                                makeCompBlock(datatype,data);
                            }
                            if(pcb_comp_fromHC>10){
                                String note = "fromHC";
                                String datatype="getPCB";
                                //Double amount=new preConnectivityBenifitDAO(context).getPCBForWhat(hcid,"registration")-pcb_registration;
                                String data = hcid + " "+Utils.formatDoubleToString(pcb_comp_fromHC)+" " + note;
                                makeCompBlock(datatype,data);
                            }else if(pcb_comp_fromHC<-10){
                                String note = "toPCB";
                                String datatype="getHC";
                                //data=HCID+" -"+Utils.formatDoubleToString(amount)+" "+note;
                                String data = hcid + " "+Utils.formatDoubleToString(pcb_comp_fromHC/3)+ " " + note;
                                makeCompBlock(datatype,data);
                            }
                            if(HC_comp_fromCB>10||HC_comp_fromCB<-10){
                                String note = "fromCB";
                                String datatype = "getHC";
                                String data = hcid + " "+ HC_comp_fromCB +" " + note;
                                makeCompBlock(datatype,data);
                            }
                            if(HC_comp_fromintroCB>10||HC_comp_fromintroCB<-10){
                                String note = "intro_fromCB";
                                String datatype = "getHC";
                                String data = hcid + " "+HC_comp_fromintroCB+" " + note;
                                makeCompBlock(datatype,data);
                            }
                            if(CB_comp_sellCB < 0){
                                String note = "sellCB";
                                String datatype = "getCB";
                                String data="HyperConn" + " " + hcid +" "+ Math.abs(CB_comp_sellCB) +" "+note;
                                makeCompBlock(datatype,data);
                            }else if(CB_comp_sellCB > 0){
                                String note = "sellCB";
                                String datatype = "getCB";
                                String data=hcid + " " + "HyperConn" +" "+ CB_comp_sellCB +" "+note;
                                makeCompBlock(datatype,data);
                            }
                            dialog.dismiss();
                        }
                    });
        //}
        /*alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });*/

        alertDialog.show();
    }

    private void makeCompBlock(String datatype, String data) {
        Intent intent = new Intent(MemberList.this, CoreService.class);
        intent.putExtra("Message", "makeBlock_Calibration:"+datatype + ":" + data);
        startService(intent);
    }
    private void makeBlock(String datatype, String data) {
        Intent intent = new Intent(MemberList.this, CoreService.class);
        intent.putExtra("Message", datatype + ":" + data);
        startService(intent);
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        if (receiver1 != null) {
            unregisterReceiver(receiver1);
            receiver1 = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_memberlist, menu);
        //menu.getItem(0).setVisible(true);
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class MemberAdapter extends ArrayAdapter<Member> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public MemberAdapter(Context context, int textViewResourceId, List<Member> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            Member m = (Member) getItem(position);

            if (convertView == null) {
                //Toast.makeText(MemberList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();
            int icon = R.drawable.noname;
            String title=m.getHcid();
            holder.text_title.setText(title);
            holder.text_message.setText(m.getId()+" / "+
                    m.getIntroducerid());
                    /*+" / "+
                    Utils.formatDoubleToString(new HyperConnectivityDAO(context).getSumByHcid(m.getHcid()))+" / "+
                    Utils.formatDoubleToString(new ConnectivityBenifitDAO(context).getBalanceByHCID(m.getHcid())));*/
            holder.text_time.setText("#"+String.valueOf(m.getBlockIndex()));
            holder.image_icon.setImageResource(icon);
            return view;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }


    }
    private void showAlertDialog(String title, String message) {
        AlertDialog alertDialog = new AlertDialog.Builder(MemberList.this).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }
    private class Async_checkData extends AsyncTask<String, Void, Integer> {
        @Override
        protected Integer doInBackground(String... params) {
            return checkData();
        }

        @Override
        protected void onPostExecute(Integer result) {
            //Toast.makeText(context,"count: "+result,Toast.LENGTH_LONG).show();
            //if(needrenew){
                renewlist();
            //}
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Log.i(TAG, "onProgressUpdate");
        }

    }
    private void renewlist(){
        memberDAO = new MemberDAO(context);
        if(memberDAO.getCount()!=count){
            listMember.clear();
            for(Member m:memberDAO.getAll()){
                listMember.add(m);
            }
            Collections.reverse(listMember);
            count=memberDAO.getCount();
            adapter.notifyDataSetChanged();
            if (count > 0) {
                listview.setVisibility(View.VISIBLE);
                RL_nothing.setVisibility(View.GONE);
                myToolbar.setTitle(getResources().getString(R.string.title_particiapnt)+" "+memberDAO.getCount());
            }else{
                listview.setVisibility(View.GONE);
                RL_nothing.setVisibility(View.VISIBLE);
                myToolbar.setTitle("");
            }
        }
    }
    private int checkData() {
        boolean needrenew=true;
        BlockchainDAO blockchainDAO = new BlockchainDAO(context);
        //BlockDAO blockDAO = new BlockDAO(context);
        //memberDAO.deleteAll();
        //memberDAO=new MemberDAO(context);
        memberDAO.clear();
        for(Block block:blockchainDAO.getAll()){
            if(block.getDatatype().equals("Registration")){
                Member member=new Member();
                member.setIntroducerid(block.getData().split(" ")[0]);
                member.setHcid(block.getData().split(" ")[1]);
                member.setPublicKey(block.getData().split(" ")[2]);
                member.setBlockIndex(block.getIndex());
                memberDAO.insert(member);
            }
        }
        return memberDAO.getCount();
    }
}