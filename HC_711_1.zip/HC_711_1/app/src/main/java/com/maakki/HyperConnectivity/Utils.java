package com.maakki.HyperConnectivity;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class Utils {
    //region 取得length個0 所組成的字串
    public static String zeros(int length) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            builder.append('0');
        }
        return builder.toString();
    }
    //endregion

    //region 待問
    public static void ImageViewAnimatedChange(Context c, final ImageView v, final Drawable start_image, final Drawable new_image) {
        final Animation anim_out = AnimationUtils.loadAnimation(c, android.R.anim.fade_out);
        final Animation anim_in = AnimationUtils.loadAnimation(c, android.R.anim.fade_in);
        anim_out.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {

                anim_in.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {
                        v.setImageDrawable(start_image);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {
                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        v.setImageDrawable(new_image);
                    }
                });
                v.startAnimation(anim_in);
            }
        });
        v.startAnimation(anim_out);
    }
    //endregion

    //region 沒用到
    /*public static void TextViewAnimatedChange(Context c, final TextView tv, final int start_color, final int end_color_) {
        final Animation anim_out = AnimationUtils.loadAnimation(c, android.R.anim.fade_out);
        final Animation anim_in  = AnimationUtils.loadAnimation(c, android.R.anim.fade_in);
        anim_out.setAnimationListener(new Animation.AnimationListener()
        {
            @Override public void onAnimationStart(Animation animation) {}
            @Override public void onAnimationRepeat(Animation animation) {}
            @Override public void onAnimationEnd(Animation animation)
            {

                anim_in.setAnimationListener(new Animation.AnimationListener() {
                    @Override public void onAnimationStart(Animation animation) {
                        tv.setTextColor(start_color);
                    }
                    @Override public void onAnimationRepeat(Animation animation) {}
                    @Override public void onAnimationEnd(Animation animation) {
                        tv.setTextColor(end_color_);
                    }
                });
                tv.startAnimation(anim_in);
            }
        });
       tv.startAnimation(anim_out);
    }*/
    //endregion

    //region 取得應用程式目錄下的檔案
    public static File getDevicesDir(Context context, String FILE_NAME) {
        //String FILE_DIR="HyperConn";
        File mCropFile = null;
        //先在SD卡找
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File cropdir = new File(Environment.getExternalStorageDirectory(), staticVar.APP_dir);
            if (!cropdir.exists()) {
                cropdir.mkdirs();
            }
            mCropFile = new File(cropdir, FILE_NAME);
        } else {
            File cropdir = new File(context.getFilesDir(), staticVar.APP_dir);
            if (!cropdir.exists()) {
                cropdir.mkdirs();
            }
            mCropFile = new File(cropdir, FILE_NAME);
        }
        return mCropFile;
    }
    //endregion

    //region 格式化數字
    public static String formatDoubleToString(Double d) {
        DecimalFormat df;
        BigDecimal a = new BigDecimal(d.toString());
        if (d > 1000) {
            df = new DecimalFormat(",###,##0");
        } else if (d > 100) {
            df = new DecimalFormat(",###,##0.0");
        } else if (d < 2) {
            df = new DecimalFormat(",###,##0.000");
        } else {
            df = new DecimalFormat(",###,##0.00");
        }
        df.format(a);
        return df.format(a);
    }
    //endregion

    public static String formatDouble_point5(Double d) {
        DecimalFormat df;
        BigDecimal a = new BigDecimal(d.toString());
        df = new DecimalFormat(",###,##0.00000");

        df.format(a);
        return df.format(a);
    }

    /**
     * 常用的加，减，乘，除，BigDecimal类提供了相应的成员方法。
     * public BigDecimal add(BigDecimal value);//加法
     * public BigDecimal subtract(BigDecimal value); //减法 
     * public BigDecimal multiply(BigDecimal value); //乘法
     * public BigDecimal divide(BigDecimal value); //除法
     *
     * @param v1 數字1
     * @param v2 數字2
     * @return double
     */
    public static double multiply(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        //doubleValue() 將變數轉為double 型態
        return b1.multiply(b2).doubleValue();
    }

    //BigDecimal 的相加
    public static double add(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.add(b2).doubleValue();
    }

    //BigDecimal 的相減
    public static double sub(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.subtract(b2).doubleValue();
    }

    public static String getCurrentTime() {
        Date d = new Date();
        SimpleDateFormat dt1 = new SimpleDateFormat("HH:mm");
        //java.util.Date.getTime() 方法返回自1970年1月1日00:00:00 GMT已經過去了多少毫秒
        return dt1.format(d.getTime());
    }

    //region 格式化日期
    public static String ConvertTimeFormat(Long d) {
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy.MM.dd");
        return dt1.format(d);
    }
    //endregion

    //region 字串是否為空白或null
    public static boolean isBlank(String string) {
        if (string != null) {
            if (!string.isEmpty()) {
                return false;
            }
        }
        return true;
    }
    //endregion

    //region 認證電子簽章

    /**
     * 認證電子簽章
     *
     * @param context    Context
     * @param signerHCID 簽名人的HCID
     * @param data       原始資料
     * @param DSignature 電子簽章
     * @return 0：找不到簽名人的公鑰 1: 電子簽章正確 2:電子簽章錯誤
     */
    public static int verifyDigitalSignature(Context context, String signerHCID, String data, String DSignature) {
        int isVerified = 0;
        Member mData = new Member();
        mData = new MemberDAO(context).get(signerHCID);
        if (mData != null) {
            RSAEncryptionJava8 rs = new RSAEncryptionJava8();
            if (rs.verfiySignature(DSignature, data, mData.getPublicKey()))
                isVerified = 1;
            else
                isVerified = 2;
        }
        return isVerified;
    }
    //endregion

    //region 取得n個英數亂數字元(含英文大小寫及數字0-9)

    /**
     * 取得n 個英數亂數字元(英文大小寫及數字0-9)
     *
     * @param wordCount 取多少個隨機亂數字元
     * @return 亂數字串(String)
     */
    public static String getRandomWord(int wordCount) {
        /*StringBuilder sb = new StringBuilder();
        for (int i = 0; i < wordCount; i++) {
            int c = (int) Math.random() * 98;
            while (c < 48 || (c>57 && c<65) || (c > 90 && c < 97) || c > 122) {
                c = (int) Math.random() * 98;
            }
            sb.append((char)c);
        }*/
        if (wordCount < 1)
            return "";
        String str = "abcdefghigklmnopkrstuvwxyzABCDEFGHIGKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        //ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < wordCount; i++) {
            int number = random.nextInt(62);//0~61
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }
    //endregion

    /**
     * 判断服务是否开启
     *
     * @param context     context
     * @param ServiceName 服務的class name
     * @return true：開啟中, false:已關閉
     */
    public static boolean isServiceRunning(Context context, String ServiceName) {
        if (("").equals(ServiceName) || ServiceName == null)
            return false;
        ActivityManager myManager = (ActivityManager) context
                .getSystemService(Context.ACTIVITY_SERVICE);
        ArrayList<ActivityManager.RunningServiceInfo> runningService = (ArrayList<ActivityManager.RunningServiceInfo>) myManager
                .getRunningServices(30);
        for (int i = 0; i < runningService.size(); i++) {
            if (runningService.get(i).service.getClassName().toString()
                    .equals(ServiceName)) {
                return true;
            }
        }
        return false;
    }

    public static String setStaticHCID() {
        String HCID = "";
        //Static 的內容被Android刪掉了，只好重抓
        if (Utils.isBlank(staticVar.myHCID)) {
            Log.e("cherry", "Utils.java line 302: 重抓HCID ");
        } else
            HCID = staticVar.myHCID;
        return HCID;
    }

    //region 判定static 的HCID是否還有值，若沒有，從sharedPreferences讀取資料即可(因為在APP開始執行時，已經將正確的HCID存入sharedPreferences)
    public static String setMyHCID(Context context) {
        String HCID = "";
        //Static 的內容被Android刪掉了，重設static 的值
        if (Utils.isBlank(staticVar.myHCID)) {
            Log.e("cherry", "Utils.java ==> staticVar.myHCID 內容被清除，從APP內存中取得HCID ");
            HCID = SharedPreferencesHelper.getSharedPreferencesString(context, staticVar.SPKey100, "");
            staticVar.myHCID = HCID;
        } else
            HCID = staticVar.myHCID;
        return HCID;
    }


    /**
     * 判断服务是否开启
     *
     * @param context      context
     * @param serviceClass class 本身
     * @return true：開啟中, false:已關閉
     */
    public boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (service.service.getClassName().contains(serviceClass.getName())) {
                return true;
            }
        }
        return false;
    }

}
