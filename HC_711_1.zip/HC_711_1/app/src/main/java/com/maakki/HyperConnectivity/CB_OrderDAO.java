package com.maakki.HyperConnectivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

// 資料功能類別
public class CB_OrderDAO {
    // 表格名稱
    public static final String TABLE_NAME = "CB_Order";

    // 編號表格欄位名稱，固定不變
    public static final String KEY_ID = "_id";
    Context context;
    // 其它表格欄位名稱
    public static final String hcid_Column = "hcid";
    public static final String isbuy_COLUMN = "cbo_isbuy";
    public static final String amount_COLUMN = "_amount";
    public static final String currency_COLUMN = "_currency";
    public static final String cashflow1_COLUMN = "_cashflow1";
    public static final String cashflow2_COLUMN = "_cashflow2";
    public static final String cb_amount_COLUMN = "cb_amount";
    public static final String hash_COLUMN = "cbo_hash";
    public static final String status_COLUMN = "cbo_status";
    public static final String note_COLUMN = "cbo_note";
    public static final String block_index_COLUMN = "block_index";
    public static final String CreateTime_COLUMN = "createtime";


    // 提醒日期時間
    //public static final String ALARMDATETIME_COLUMN = "alarmdatetime";

    // 使用上面宣告的變數建立表格的SQL指令
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    hcid_Column + " TEXT NOT NULL, " +
                    isbuy_COLUMN + " TEXT NOT NULL, " +
                    amount_COLUMN + " REAL, " +
                    currency_COLUMN + " TEXT, " +
                    cashflow1_COLUMN + " TEXT, " +
                    cashflow2_COLUMN + " TEXT, " +
                    cb_amount_COLUMN + " REAL, " +
                    hash_COLUMN +" TEXT NOT NULL, " +
                    status_COLUMN +" INTEGER NOT NULL, " +
                    note_COLUMN +" TEXT, " +
                    block_index_COLUMN +" INTEGER NOT NULL, " +
                    CreateTime_COLUMN +" INTEGER NOT NULL) ";

    // 資料庫物件
    private SQLiteDatabase db;

    // 建構子，一般的應用都不需要修改
    public CB_OrderDAO(Context context) {
        this.context=context;
        db = CB_TradingDBHelper.getDatabase(context);
    }

    // 關閉資料庫，一般的應用都不需要修改
    public void close() {
        db.close();
    }

    // 新增參數指定的物件
    public CB_Order insert(CB_Order cbo) {
        // 建立準備新增資料的ContentValues物件
        if (!update(cbo) & getByHash(cbo.getHash())==null) {
            ContentValues cv = new ContentValues();
            // 加入ContentValues物件包裝的新增資料
            // 第一個參數是欄位名稱， 第二個參數是欄位的資料
            cv.put(hcid_Column, cbo.getHcid());
            cv.put(isbuy_COLUMN, String.valueOf(cbo.getIsbuy()));
            cv.put(amount_COLUMN, cbo.getAmount());
            cv.put(currency_COLUMN, cbo.getCurrency());
            cv.put(cashflow1_COLUMN, cbo.getCashflow_1());
            cv.put(cashflow2_COLUMN, cbo.getCashflow_2());
            cv.put(cb_amount_COLUMN, cbo.getCB_Amount());

            cv.put(hash_COLUMN, cbo.getHash());
            cv.put(status_COLUMN, cbo.getStatus());
            cv.put(note_COLUMN, cbo.getNote());
            cv.put(block_index_COLUMN, cbo.getBlockIndex());
            cv.put(CreateTime_COLUMN, cbo.getCreateTime());

            long id = db.insert(TABLE_NAME, null, cv);
            // 設定編號
            cbo.setId(id);
        }
        return cbo;
    }

    // 修改參數指定的物件
    public boolean update(CB_Order cbo) {
        // 建立準備修改資料的ContentValues物件
        ContentValues cv = new ContentValues();
        // 加入ContentValues物件包裝的修改資料
        // 第一個參數是欄位名稱， 第二個參數是欄位的資料
        cv.put(hcid_Column, cbo.getHcid());
        cv.put(isbuy_COLUMN, String.valueOf(cbo.getIsbuy()));
        cv.put(amount_COLUMN, cbo.getAmount());
        cv.put(currency_COLUMN, cbo.getCurrency());
        cv.put(cashflow1_COLUMN, cbo.getCashflow_1());
        cv.put(cashflow2_COLUMN, cbo.getCashflow_2());
        cv.put(cb_amount_COLUMN, cbo.getCB_Amount());
        //cv.put(price_set_COLUMN,cbo.getPrice_set());
        //cv.put(cb_amount_deal_COLUMN, cbo.getCB_Amount_deal());
        cv.put(hash_COLUMN, cbo.getHash());
        cv.put(status_COLUMN, cbo.getStatus());
        cv.put(note_COLUMN, cbo.getNote());
        cv.put(block_index_COLUMN, cbo.getBlockIndex());
        cv.put(CreateTime_COLUMN, cbo.getCreateTime());
        // 設定修改資料的條件為編號
        // 格式為「欄位名稱＝資料」
        //String where = hash_COLUMN + "='" + cbo.getHash()+"'";

        String where = hash_COLUMN + "='" + cbo.getHash()+"' AND "+ status_COLUMN +" <= "+cbo.getStatus();
        // 執行修改資料並回傳修改的資料數量是否成功
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    public Double getBalance(String hash){
        Double result=0d;
        Double sum_trade=0d;
        List<CB_Trading> tradingList=new CB_TradingDAO(context).getListByCBOrderHash(hash);
        for(CB_Trading cbt:tradingList){
            if(cbt.getCurrency().equals(getByHash(hash).getCurrency())){
                sum_trade+=cbt.getAmount();
            }else if(cbt.getCurrency().equals("USD")&getByHash(hash).getCurrency().equals("RMB")){
                sum_trade+=Utils.multiply(cbt.getAmount(),Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB)));
            }
        }
        result = getByHash(hash).getAmount()-sum_trade;
        return result;
    }

    public Double SumUSD_CBOrder_done(String hcid){
        Double result=0d;
        //Double sum_trade=0d;
        //List<CB_Trading> tradingList=new CB_TradingDAO(context).getListByCBOrderHash(hash);
        for(CB_Order co:getByHcid(hcid)) {
            if (co.getIsbuy() & co.getStatus() == 30){
                if (co.getCurrency().equals("USD")) {
                    result += co.getAmount();
                } else if (co.getCurrency().equals("RMB")) {
                    result += co.getAmount() / Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
                }
            }
        }
        //result = getByHash(hash).getAmount()-sum_trade;
        return result;
    }

    public Double Index_prosperity(){
        Double sum_buy=0d;
        Double sum_sell=0d;
        //List<CB_Trading> tradingList=new CB_TradingDAO(context).getListByCBOrderHash(hash);
        for(CB_Order co:getAll()) {
            if(co.getStatus() == 30|| co.getStatus() == 26){
                if (co.getIsbuy()){
                    if (co.getCurrency().equals("USD")) {
                        sum_buy += co.getAmount();
                    } else if (co.getCurrency().equals("RMB")) {
                        sum_buy += co.getAmount() / Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
                    }
                }else{
                    sum_sell += co.getCB_Amount();
                }
            }
        }
        if(sum_sell>0){
            if(sum_buy/Utils.multiply(sum_sell,new CB_TradingDAO(context).getCR())>10){
                return 10.0;
            }else{
                return sum_buy/Utils.multiply(sum_sell,new CB_TradingDAO(context).getCR());
            }
        } else if(sum_buy>0) {
            return 2.0;
        } else if(sum_buy>1000) {
            return 3.0;
        } else if(sum_buy>10000) {
            return 4.0;
        } else{
            return 5.0;

        }
    }

    // 刪除參數指定編號的資料
    public boolean delete(long id) {
        // 設定條件為編號，格式為「欄位名稱=資料」
        String where = KEY_ID + "=" + id;
        // 刪除指定編號資料並回傳刪除是否成功
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    // 取得指定編號的資料物件
    public CB_Order get(long id) {
        // 準備回傳結果用的物件
        CB_Order cb = null;
        // 使用編號為查詢條件
        String NotificationID = KEY_ID + "=" + id;
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, NotificationID, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            cb = getRecord(result);
        }

        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return cb;
    }
    // 取得指定編號的資料物件
    public CB_Order getByHash(String hash) {
        // 準備回傳結果用的物件
        CB_Order cb = null;
        // 使用編號為查詢條件
        String SELECTION = hash_COLUMN + "='" + hash +"'";
        // 執行查詢
        Cursor result = db.query(
                TABLE_NAME, null, SELECTION, null, null, null, null, null);

        // 如果有查詢結果
        if (result.moveToFirst()) {
            // 讀取包裝一筆資料的物件
            cb = getRecord(result);
        }
        // 關閉Cursor物件
        result.close();
        // 回傳結果
        return cb;
    }

    public void deleteAll() {
        db.execSQL("delete from " + TABLE_NAME);
        db.close();
    }
    public void clear() {
        for(CB_Order cbo:getAll()){
            delete(cbo.getId());
        }
    }
    public Double getOrderBalance(){
        Double result=0d;
        // 準備回傳結果用的物件
        // 使用編號為查詢條件
        for(CB_Order cbo:getAll()){
            if(cbo.getIsbuy()){
                result+=cbo.getCB_Amount();
            }else{
                result-=cbo.getCB_Amount();
            }
        }
        return result;
    }
    public Double getUSDSum_CBOrder(String hcid) {
        Double result=0d;
        // 準備回傳結果用的物件
        //List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hcid_Column +"='"+hcid+"' AND "+isbuy_COLUMN + "='true'"+" AND "+status_COLUMN+"<=30";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount();
            result-=new CB_TradingDAO(context).getAmount_Exchanged(getRecord(cursor).getHash());
        }
        cursor.close();
        return result/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
    }

    public Double getUSDSum_CBExchanged(String hcid) {
        Double result=0d;
        // 準備回傳結果用的物件
        //List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hcid_Column +"='"+hcid+"' AND "+isbuy_COLUMN + "='true'"+" AND "+status_COLUMN+"<=26";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount()/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
        }
        cursor.close();
        return result;
    }

    public Double getUSDSum_CBSelling(String hcid) {
        Double result=0d;
        Double deal=0d;
        // 準備回傳結果用的物件
        List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hcid_Column +"='"+hcid+"' AND "+isbuy_COLUMN + "='false'"+" AND "+status_COLUMN+"<=30";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount()/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
            result-=new CB_TradingDAO(context).getAmount_Sold(getRecord(cursor).getHash());
        }
        cursor.close();
        return result;
    }

    public Double getUSDSum_CBSold(String hcid) {
        Double result=0d;
        // 準備回傳結果用的物件
        //List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hcid_Column +"='"+hcid+"' AND "+isbuy_COLUMN + "='false'"+" AND "+status_COLUMN+"=26";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount()/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
        }
        cursor.close();
        return result;
    }

    public Double getUSDSum_CBOrderByHcid(String hcid) {
        Double result=0d;
        // 準備回傳結果用的物件
        //List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hcid_Column +"='"+hcid+"' AND "+isbuy_COLUMN + "='true'"+" AND ("+status_COLUMN+"=26 OR "+status_COLUMN+"=30)";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getAmount()/Double.parseDouble(context.getResources().getString(R.string.exchangerate_RMB));
        }
        cursor.close();
        return result;
    }

    public String getUSDSum_CBOrderDetails(String hcid) {
        String result="";
        // 準備回傳結果用的物件
        //List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        //String querystring = hcid_Column +"='"+hcid+"' AND "+isbuy_COLUMN + "='true'"+" AND ("+status_COLUMN+"=26 OR "+status_COLUMN+"=30)";
        String querystring = hcid_Column + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getCB_Amount();
        }
        cursor.close();
        return result;
    }

    public Double getCBSum_SellByHcid(String hcid) {
        Double result=0d;
        // 準備回傳結果用的物件
        //List<CB_Trading> listtrading = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hcid_Column +"='"+hcid+"' AND "+isbuy_COLUMN + "='false'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result+=getRecord(cursor).getCB_Amount();
        }
        cursor.close();
        return result;
    }

    // 讀取所有联络人資料
    public List<CB_Order> getAll() {
        List<CB_Order> result = new ArrayList<>();
        String ORDER=status_COLUMN +" DESC,"+CreateTime_COLUMN;
        Cursor cursor = db.query(
                TABLE_NAME, null, null, null, null, null, ORDER, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    public List<CB_Order> getUnder30() {
        List<CB_Order> result = new ArrayList<>();
        String ORDER=status_COLUMN +" DESC,"+CreateTime_COLUMN;
        String SELECTION = status_COLUMN+"<30";
        Cursor cursor = db.query(
                TABLE_NAME, null, SELECTION, null, null, null, ORDER, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }

    // 取得与某个HCID相关的所有记录
    public List<CB_Order> getByHcid(String hcid) {
        // 準備回傳結果用的物件
        List<CB_Order> result = new ArrayList<>();
        // 使用編號為查詢條件
        String querystring = hcid_Column + "='" + hcid+"'";
        // 執行查詢
        Cursor cursor = db.query(
                TABLE_NAME, null, querystring, null, null, null, null, null);

        while (cursor.moveToNext()) {
            result.add(getRecord(cursor));
        }

        cursor.close();
        return result;
    }



    // 把Cursor目前的資料包裝為物件
    public CB_Order getRecord(Cursor cursor) {
        // 準備回傳結果用的物件
        CB_Order result = new CB_Order();
        result.setId(cursor.getLong(0));
        result.setHcid(cursor.getString(1));
        result.setIsbuy(Boolean.parseBoolean(cursor.getString(2)));
        result.setAmount(cursor.getDouble(3));
        result.setCurrency(cursor.getString(4));
        result.setCashflow_1(cursor.getString(5));
        result.setCashflow_2(cursor.getString(6));
        result.setCB_Amount(cursor.getDouble(7));
        //result.setPrice_set(cursor.getDouble(8));
        //result.setCB_Amount_deal(cursor.getDouble(9));
        result.setHash(cursor.getString(8));
        result.setStatus(cursor.getInt(9));
        result.setNote(cursor.getString(10));
        result.setBlockIndex(cursor.getLong(11));
        result.setCreateTime(cursor.getLong(12));
        // 回傳結果
        return result;
    }

    // 取得資料數量
    public int getCount() {
        int result = 0;
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null);
        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }
}