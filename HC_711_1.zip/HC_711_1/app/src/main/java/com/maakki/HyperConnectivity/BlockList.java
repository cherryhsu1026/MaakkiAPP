package com.maakki.HyperConnectivity;


import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import me.leolin.shortcutbadger.ShortcutBadger;

/**
 * Created by ryan on 2017/7/17.
 */

public class BlockList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon;
    Integer count;
    FloatingActionButton fab;
    String HCID;
    private boolean isAscending = false;
    private Context context;
    private List<Block> listBlock, newlist;
    private BlockDAO blockDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private BlockAdapter adapter;
    private BroadcastReceiver receiver;
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            switch (menuItem.getItemId()) {
                case R.id.delete:
                    AlertDialog alertDialog = new AlertDialog.Builder(BlockList.this).create();
                    alertDialog.setTitle("将要删除区块记录");
                    alertDialog.setMessage("您确定要删除所有的区块记录吗？");
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "确定",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    listview.setVisibility(View.INVISIBLE);
                                    fab.setVisibility(View.INVISIBLE);
                                    RL_nothing.setVisibility(View.VISIBLE);
                                    blockDAO.clear();
                                    listBlock.clear();
                                    myToolbar.setTitle("");
                                    adapter.notifyDataSetChanged();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "略过",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    break;
                case R.id.applyblock:
                    Intent i =new Intent(BlockList.this,applyBlockList.class);
                    startActivity(i);
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);

        //ShortcutBadger.with(getApplicationContext()).remove();
        listBlock = new ArrayList<Block>();
        blockDAO = new BlockDAO(this);
        //block = new Block();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
                //Intent intent = new Intent(BlockList.this, MainActivity.class);
                //startActivity(intent);
            }
        });
        if(blockDAO.getCount()>0){
            myToolbar.setTitle(getResources().getString(R.string.title_block)+" "+blockDAO.getCount());
        }else{
            myToolbar.setTitle("");
        }
        //
        fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no block created..");
        //tv = (TextView) findViewById(R.id.tv);
        count = blockDAO.getCount();
        listBlock = blockDAO.getAll();
        adapter = new BlockAdapter(this, R.layout.list_item, listBlock);
        listview.setAdapter(adapter);
        if (count > 0) {
            Collections.reverse(listBlock);
            //listtop=new ArrayList<PrevNotification>();
            //tv.setText("(" + count.toString() + ")");
            if (count > 1) {
                fab.setVisibility(View.VISIBLE);
            }
            //setOnClick();
            fab.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }

                    Collections.reverse(listBlock);
                    adapter.notifyDataSetChanged();
                }
            });

        } else {
            //tv.setText("");
            RL_nothing.setVisibility(View.VISIBLE);
        }

        //check if isOnlineOnSignalR
        //AsyncCallWS_isOnlineOnSignalR isOnlineOnSignalRTask = new AsyncCallWS_isOnlineOnSignalR();
        //isOnlineOnSignalRTask.execute();
        // your oncreate code should be
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_BlockList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                blockDAO = new BlockDAO(context);
                newlist = new ArrayList<Block>();
                newlist = blockDAO.getAll();
                Block b = newlist.get(newlist.size() - 1);
                if (isAscending) {
                    listBlock.add(b);
                } else {
                    listBlock.add(0, b);
                }
                count=blockDAO.getCount();
                adapter.notifyDataSetChanged();
                if (count > 0) {
                    if (count == 1) {
                        listview.setVisibility(View.VISIBLE);
                    }
                    if (count > 10) {
                        fab.setVisibility(View.VISIBLE);
                    }
                    //tv.setText("(" + count + ")");
                    RL_nothing.setVisibility(View.GONE);
                }
                myToolbar.setTitle(getResources().getString(R.string.title_block)+" "+blockDAO.getCount());
            }
        };
        registerReceiver(receiver, filter);

        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        if (new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)) {
            setOnClick();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    public void setOnClick() {
        listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Block b = listBlock.get(position);
                adapter.notifyDataSetChanged();
                if (swipeDetector.swipeDetected()) {
                    deleteCell(v, position);
                    blockDAO.delete(b.getId());
                    myToolbar.setTitle(getResources().getString(R.string.title_block)+" "+blockDAO.getCount());
                }else{

                }
            }
        });
    }

    private void deleteCell(final View v, final int index) {
        Animation.AnimationListener al = new Animation.AnimationListener() {
            //@Override
            public void onAnimationEnd(Animation arg0) {
                listBlock.remove(index);
                count--;
                if (count < 2) {
                    fab.setVisibility(View.INVISIBLE);
                    if (count < 1) {
                        listview.setVisibility(View.GONE);
                    }
                }
                if (count == 0) {
                    RL_nothing.setVisibility(View.VISIBLE);
                }
                //tv.setText("(" + count + ")");
                ViewHolder vh = (ViewHolder) v.getTag();
                vh.needInflate = true;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        };
        collapse(v, al);
    }

    private void collapse(final View v, Animation.AnimationListener al) {
        final int initialHeight = v.getMeasuredHeight();
        final int top = v.getTop();
        //Toast.makeText(getApplicationContext(), "collapsetop:"+top , Toast.LENGTH_SHORT).show();
        final int ANIMATION_DURATION = 200;
        Animation anim = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {

                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (al != null) {
            anim.setAnimationListener(al);
        }
        anim.setDuration(ANIMATION_DURATION);
        v.startAnimation(anim);
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_blocklist, menu);
        if (new BlockchainDAO(context).getByIndex(0).getMaker().equals(HCID)) {
            menu.getItem(1).setVisible(true);
        }
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class BlockAdapter extends ArrayAdapter<Block> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public BlockAdapter(Context context, int textViewResourceId, List<Block> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            Block b = (Block) getItem(position);

            if (convertView == null) {
                //Toast.makeText(BlockList.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(BlockList.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(BlockList.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();

            //String dt = b.getDatatype();
            //holder.datatype = dt;
            int icon = R.drawable.block;
            //holder.image_icon.setBackgroundColor(ContextCompat.getColor(getApplicationContext(),R.color.colorTitleText));
            /*switch (dt) {
                case "getRE":
                    icon = R.drawable.redenvelope;
                    break;
                case "newRE":
                    icon=R.drawable.favorite;
                    break;
                default:
            }*/

            //Long time = b.getCreateTime();
            String fm = "";
            //Date date = new Date(time);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            fm = formatter.format(b.getCreateTime());
            //new SimpleDateFormat(dateFormat).format(new Date(p.getLastModify()));
            String title="Block #"+b.getIndex()+" "+b.getDatatype()+" "+b.getNonce();
            holder.text_title.setText(title);
            //holder.text_message.setText(b.getId()+" / "+b.getTimestamp()+"\n"+b.getData());
            holder.text_message.setText(b.getId()+"\n"+b.getMaker()+"\n"+b.getData());
            if(b.getDatatype().equals("Registration")){
                holder.text_message.setText(b.getId()+"\n"+b.getMaker()+"\n"+b.getData().split(" ")[0]+"\n"+b.getData().split(" ")[1]);
            }else if(b.getDatatype().equals("Activation")){
                holder.text_message.setText(b.getId()+"\n"+b.getMaker()+"\n"+b.getData().split(" ")[2]);
            }else if(b.getDatatype().equals("CB_Order")){
                holder.text_message.setText(b.getId()+"\n"+b.getMaker()+"\n"+b.getData().split(" ")[2]+"\n"+b.getData().split(" ")[3]);
            }
            holder.text_time.setText(fm);
            holder.image_icon.setImageResource(icon);
            //}
            return view;
            //return convertView;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }


    }

    private void Invoke_BlockList(){
        Intent i = new Intent("Invoke_BlockList");
        i.putExtra("What", "");
        sendBroadcast(i);
    }
}
