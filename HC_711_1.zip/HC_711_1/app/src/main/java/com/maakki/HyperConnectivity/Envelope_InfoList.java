package com.maakki.HyperConnectivity;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by ryan on 2017/7/17.
 */

public class Envelope_InfoList extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title,tv_message,time,tv_nothing;
    ImageView icon;
    Integer count;
    Double cb_amount;
    View view;
    FloatingActionButton fab;
    Envelope_Info envelope_info;
    private static final int REQUEST_CODE_TAKE_PHOTO = 12;
    private static final int PHOTO_REQUEST_CUT = 15;// 結果

    private Bitmap icon_bitmap = null;
    private String realPath,filename;
    File tmpFile;
    private boolean isAscending = false;
    private Context context;
    private List<Envelope_Info> listEnvelope_Info;
    private Envelope_InfoDAO envelopeInfoDAO;
    private SwipeDetector swipeDetector = new SwipeDetector();
    private BlockAdapter adapter;
    private BroadcastReceiver receiver;
    private ImageLoaderConfiguration config;
    private DisplayImageOptions options;
    private ImageLoader imageLoader;
    private String HCID;
    private Menu menu;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            //String msg = "";
            menuItem.setVisible(false);
            //menu.getItem(2).setVisible(false);
            switch (menuItem.getItemId()) {
                case R.id.edit:
                    //Intent i = new Intent(Envelope_InfoList.this, preCBList.class);
                    //startActivity(i);
                    EditAdDialog(null);
                    break;
                case R.id.record_list:
                    Intent i = new Intent(Envelope_InfoList.this, Envelope_Info_recordList.class);
                    startActivity(i);
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blocklist);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        //ShortcutBadger.with(getApplicationContext()).remove();
        listEnvelope_Info = new ArrayList<Envelope_Info>();
        envelopeInfoDAO=new Envelope_InfoDAO(context);
        listEnvelope_Info = envelopeInfoDAO.getAll();
        count = listEnvelope_Info.size();
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();
        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        if(count > 0) {
            myToolbar.setTitle(getResources().getString(R.string.EIList_toolbar)+" "+count);
        } else {
            myToolbar.setTitle("");
        }
         fab = (FloatingActionButton) findViewById(R.id.setting_button);
        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
        //fab.bringToFront();
        title = (TextView) findViewById(R.id.title);
        tv_message = (TextView) findViewById(R.id.message);
        time = (TextView) findViewById(R.id.time);
        icon = (ImageView) findViewById(R.id.icon);
        listview = (ListView) findViewById(R.id.listview);
        RL_nothing=(RelativeLayout)findViewById(R.id.RL_nothing);
        tv_nothing = (TextView) findViewById(R.id.tv_nothing);
        tv_nothing.setText("no Envelope_Info Received..");
        //tv = (TextView) findViewById(R.id.tv);


        adapter = new BlockAdapter(this, R.layout.list_item, listEnvelope_Info);
        listview.setAdapter(adapter);
        if (count > 0) {
            //Collections.reverse(listEnvelope_Info);
            //listtop=new ArrayList<PrevNotification>();
            //tv.setText("(" + count.toString() + ")");
            if (count > 1) {
                fab.setVisibility(View.VISIBLE);
            }
            setOnClick();
            fab.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAscending) {
                        isAscending = false;
                        fab.setImageResource(R.drawable.ic_arrow_downward_white_18dp);
                    } else {
                        isAscending = true;
                        fab.setImageResource(R.drawable.ic_arrow_upward_white_18dp);
                    }

                    Collections.reverse(listEnvelope_Info);
                    adapter.notifyDataSetChanged();
                }
            });

        } else {
            //tv.setText("");
            RL_nothing.setVisibility(View.VISIBLE);
        }
        IntentFilter filter = new IntentFilter();
        filter.addAction("INVOKE_Envelope_InfoList");
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renewlist();
            }
        };
        registerReceiver(receiver, filter);

        //
        RL_nothing.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    public void setOnClick() {
        listview.setOnTouchListener(swipeDetector);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Envelope_Info envelope_info = listEnvelope_Info.get(position);
                //adapter.notifyDataSetChanged();
                if (swipeDetector.swipeDetected()) {
                    showAlertDialog("Parameters",envelope_info.getHash());

                    //deleteCell(v, position);
                    //envelopeInfoDAO.delete(envelope_info.getId());
                    //myToolbar.setTitle(getResources().getString(R.string.EIList_toolbar)+" "+envelopeInfoDAO.getCount());
                }else{
                    String data=new BlockchainDAO(context).getByIndex(3760).getData();
                    if(!data.isEmpty() & data.split(" ")[1].equals(HCID)){
                        if(envelope_info.getPublisher_id().equals(HCID)){
                            EditAdDialog(envelope_info);
                        }
                        /*envelope_info.setStatus(21);
                        new Envelope_InfoDAO(context).update(envelope_info);
                        renewlist();*/
                    }
                }
            }
        });
    }
    private void deleteCell(final View v, final int index) {
        Animation.AnimationListener al = new Animation.AnimationListener() {
            //@Override
            public void onAnimationEnd(Animation arg0) {
                listEnvelope_Info.remove(index);
                count--;
                if (count < 2) {
                    fab.setVisibility(View.INVISIBLE);
                    if (count < 1) {
                        listview.setVisibility(View.GONE);
                    }
                }
                if (count == 0) {
                    RL_nothing.setVisibility(View.VISIBLE);
                }
                //tv.setText("(" + count + ")");
                ViewHolder vh = (ViewHolder) v.getTag();
                vh.needInflate = true;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationStart(Animation animation) {
            }
        };
        collapse(v, al);
    }
    private void collapse(final View v, Animation.AnimationListener al) {
        final int initialHeight = v.getMeasuredHeight();
        final int top = v.getTop();
        //Toast.makeText(getApplicationContext(), "collapsetop:"+top , Toast.LENGTH_SHORT).show();
        final int ANIMATION_DURATION = 200;
        Animation anim = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {

                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (al != null) {
            anim.setAnimationListener(al);
        }
        anim.setDuration(ANIMATION_DURATION);
        v.startAnimation(anim);
    }
    @Override
    protected void onStop() {
        super.onStop();
        //finish();
    }

    @Override
    protected void onDestroy() {
        if (receiver != null) {
            unregisterReceiver(receiver);
            receiver = null;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_eilist, menu);
        String data=new BlockchainDAO(context).getByIndex(3760).getData();
        if(!data.isEmpty() & data.split(" ")[1].equals(HCID)){
            menu.getItem(0).setVisible(true);
        }
        this.menu=menu;
        return true;
    }

    public class ViewHolder {
        public TextView text_title;
        public TextView text_message;
        public TextView text_time;
        public ImageView image_icon;
        public String datatype;
        public boolean needInflate;
        public boolean isVisible;
    }

    public class BlockAdapter extends ArrayAdapter<Envelope_Info> {
        //
        private LayoutInflater mInflater;
        //
        private int resId;

        public BlockAdapter(Context context, int textViewResourceId, List<Envelope_Info> objects) {
            super(context, textViewResourceId, objects);
            this.resId = textViewResourceId;
            this.mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            final View view;
            final ViewHolder holder;
            Envelope_Info envelope_info = (Envelope_Info) getItem(position);

            if (convertView == null) {
                //Toast.makeText(Envelope_InfoList1.this, "convertView==null", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else if (((ViewHolder) convertView.getTag()).needInflate) {
                //Toast.makeText(Envelope_InfoList1.this, "needInflate==true", Toast.LENGTH_SHORT).show();
                view = mInflater.inflate(R.layout.list_item, parent, false);
                setViewHolder(view);
            } else {
                //Toast.makeText(Envelope_InfoList1.this, "else", Toast.LENGTH_SHORT).show();
                view = convertView;
            }
            holder = (ViewHolder) view.getTag();

            //int icon = R.drawable.logo;
            String title = envelope_info.getSubject() ;
            holder.text_title.setText(title);
            String message=envelope_info.getStatus()+" / "+envelope_info.getInfo_type()+" / "+envelope_info.getCBPerClick()+" / "+new Envelope_Info_recordDAO(context).getCoutByAdHash(envelope_info.getHash())+" / "+envelope_info.getCB_Amount()+"\n"+envelope_info.getPublisher_id()+"\n"+envelope_info.getHash()+"\n"+envelope_info.getContent();
            holder.text_message.setText(message);
            String dateFormat = "MM-dd\nHH:mm";
            DateFormat formatter = new SimpleDateFormat(dateFormat);
            String fm = formatter.format(envelope_info.getCreateTime());
            holder.text_time.setText(fm);
            //holder.image_icon.setImageResource(icon);
            Bitmap bitmap = BitmapFactory.decodeFile(envelope_info.getImage_path());
            holder.image_icon.setImageBitmap(ServiceUtil.getRoundedCornerBitmap(bitmap));
            //}
            return view;
            //return convertView;
        }

        private void setViewHolder(View view) {
            ViewHolder vh = new ViewHolder();
            vh.image_icon = (ImageView) view.findViewById(R.id.icon);
            vh.text_title = (TextView) view.findViewById(R.id.title);
            vh.text_message = (TextView) view.findViewById(R.id.message);
            vh.text_time = (TextView) view.findViewById(R.id.time);
            vh.needInflate = false;
            view.setTag(vh);
        }
    }

    private String getCurrentDate() {
        Date d = new Date();
        SimpleDateFormat dt1 = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        return dt1.format(d.getTime());
    }

    private void renewlist(){
        listEnvelope_Info.clear();
        for(Envelope_Info ei:new Envelope_InfoDAO(context).getAll()){
            listEnvelope_Info.add(ei);
        }
        if (listEnvelope_Info.size() > 0) {
            RL_nothing.setVisibility(View.GONE);
            myToolbar.setTitle(getResources().getString(R.string.EIList_toolbar) + " "+listEnvelope_Info.size());
            adapter.notifyDataSetChanged();
        }else{
            RL_nothing.setVisibility(View.VISIBLE);
            myToolbar.setTitle("");
        }
    }

    private void EditAdDialog(Envelope_Info envelope_info) {
        this.envelope_info=envelope_info;
        cb_amount=20d;
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        LayoutInflater inflater = Envelope_InfoList.this.getLayoutInflater();
        view = inflater.inflate(R.layout.edit_ad_dialog, null);
        final EditText et_subject = (EditText) view.findViewById(R.id.et_subject);
        final EditText et_content = (EditText) view.findViewById(R.id.et_content);
        ImageView iv_icon = (ImageView) view.findViewById(R.id.iv_icon);

        final TextView tv_alert = (TextView) view.findViewById(R.id.tv_alert);
        final TextView tv_alerttext = (TextView) view.findViewById(R.id.tv_alerttext);
        iv_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent[] intentArray;
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                filename = getPhotoFileName();
                tmpFile = new File(Environment.getExternalStorageDirectory(), filename);
                Uri outputFileUri = Uri.fromFile(tmpFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
                intentArray = new Intent[]{intent};
                Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentSelectionIntent.setType("image/*");
                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser");
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
                startActivityForResult(chooserIntent, REQUEST_CODE_TAKE_PHOTO);
            }
        });
        et_content.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                //String alerttext=et_content.getText().toString()+"\n"+et_subject.getText().toString();
                //tv_alerttext.setVisibility(View.VISIBLE);
                //tv_alerttext.setText(alerttext);
            }
        });
        et_subject.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                //nickname = et_nickname.getText().toString().trim();
            }
        });
        if(envelope_info!=null){
            et_subject.setText(envelope_info.getSubject());
            et_content.setText(envelope_info.getContent());
            if (!envelope_info.getImage_path().isEmpty()) {
                cb_amount= envelope_info.getCB_Amount();
                realPath=envelope_info.getImage_path();
                Bitmap bitmap = BitmapFactory.decodeFile(realPath);
                iv_icon.setImageBitmap(ServiceUtil.getRoundedCornerBitmap(bitmap));
            }
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getResources().getString(R.string.dialog_renew),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            if(envelope_info.getStatus()==22){
                                envelope_info.setCB_Amount(cb_amount+20d);
                                envelope_info.setStatus(21);
                            }
                            envelope_info.setSubject(et_subject.getText().toString().trim());
                            envelope_info.setContent(et_content.getText().toString().trim());
                            envelope_info.setImage_path(realPath);
                            new Envelope_InfoDAO(context).update(envelope_info);
                            renewlist();
                            dialog.dismiss();
                        }
                    });
        }else{
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getResources().getString(R.string.dialog_submit),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            Envelope_Info envelope_info=new Envelope_Info();
                            envelope_info.setPublisher_id(HCID);
                            envelope_info.setSubject(et_subject.getText().toString().trim());
                            envelope_info.setContent(et_content.getText().toString().trim());
                            envelope_info.setImage_path(realPath);
                            envelope_info.setCB_Amount(cb_amount);
                            envelope_info.setHash(envelope_info.calculateHash(envelope_info));
                            envelope_info.setLanguage(SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key25, ""));
                            envelopeInfoDAO.insert(envelope_info);
                            renewlist();
                            dialog.dismiss();
                        }
                    });
        }
        alertDialog.setView(view);
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getResources().getString(R.string.dialog_cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //is_Dialog_Display = false;
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }
    private String getPhotoFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "'IMG'_yyyyMMdd_HHmmss");
        return dateFormat.format(date) + ".jpg";
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        //showDialog("QRcode Reader Result",requestCode+" / "+result.getContents(),"right?");
        if (requestCode == REQUEST_CODE_TAKE_PHOTO) {
            String mess = "";
            Uri[] results = null;
            // Check that the response is a good one
            if (resultCode == Activity.RESULT_OK) {
                if (data == null) {
                    //results=new Uri[]{Uri.fromFile(tmpFile)};
                    //icon_bitmap = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + "/image.jpg");
                    icon_bitmap = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + "/" + filename);
                    realPath = Environment.getExternalStorageDirectory() + "/" + filename;
                    results = new Uri[]{getImageUri(icon_bitmap)};
                    //iv_icon.setImageBitmap(bitmap);
                    //String path=Environment.getExternalStorageDirectory() + "/image.jpg";
                    //results=new Uri[]{Uri.parse(path)};
                } else {
                    // SDK < API11
                    if (Build.VERSION.SDK_INT < 11)
                        realPath = RealPathUtil.getRealPathFromURI_BelowAPI11(this, data.getData());

                        // SDK >= 11 && SDK < 19
                    else if (Build.VERSION.SDK_INT < 19)
                        realPath = RealPathUtil.getRealPathFromURI_API11to18(this, data.getData());

                        // SDK > 19 (Android 4.4)
                    else
                        realPath = RealPathUtil.getRealPathFromURI_API19(this, data.getData());

                    String dataString = data.getDataString();
                    //mess="data is null:"+dataString;
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                }
                //showAlertDialog("realPath",realPath);
                startPhotoZoom(results[0]);
            }
        }
        else if (requestCode == PHOTO_REQUEST_CUT) {
            if (data != null)
                sentPicToNext(data);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public Uri getImageUri(Bitmap inImage) {
        String path =
                MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage,
                        "Title", null);
        return Uri.parse(path);
    }

    private void startPhotoZoom(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        // crop为true是設置在開启的intent中設置顯示的view可以剪裁
        intent.putExtra("crop", "true");

        // aspectX aspectY 是寬高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);

        // outputX,outputY 是剪裁圖片的寬高
        intent.putExtra("outputX", 300);
        intent.putExtra("outputY", 300);
        intent.putExtra("return-data", true);
        intent.putExtra("noFaceDetection", true);
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

    private void sentPicToNext(Intent picdata) {
        Bundle bundle = picdata.getExtras();
        if (bundle != null) {
            icon_bitmap = bundle.getParcelable("data");
            ImageView iv_icon = (ImageView) view.findViewById(R.id.iv_icon);
            if (icon_bitmap == null) {
                iv_icon.setImageResource(R.drawable.no_picture);
            } else {
                iv_icon.setImageBitmap(icon_bitmap);
                saveImage(icon_bitmap);
            }
        }
    }
    private void saveImage(Bitmap bitmap) {
        SaveImageTask saveImageTask = new SaveImageTask(context, filePath -> onSaveComplete(filePath));
        saveImageTask.execute(bitmap);
    }
    private void onSaveComplete(File filePath) {
        if (filePath == null) {
            //Log.w(TAG, "onSaveComplete: file dir error");
            return;
        }
        realPath = filePath.getPath();
        //save realpath
        //SharedPreferencesHelper.putSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key3, realPath);
    }
public void showAlertDialog(String title, String message) {
        //is_Dialog_Display = true;
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //is_Dialog_Display = false;
                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //is_Dialog_Display = false;
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }
}

