package com.maakki.HyperConnectivity;
        import android.app.AlertDialog;
        import android.content.BroadcastReceiver;
        import android.content.Context;
        import android.content.DialogInterface;
        import android.content.Intent;
        import android.content.IntentFilter;
        import android.os.AsyncTask;
        import android.os.Bundle;
        import android.support.design.widget.FloatingActionButton;
        import android.support.v4.content.ContextCompat;
        import android.support.v7.app.AppCompatActivity;
        import android.support.v7.widget.Toolbar;
        import android.view.LayoutInflater;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.View;
        import android.view.ViewGroup;
        import android.view.ViewTreeObserver;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.CompoundButton;
        import android.widget.EditText;
        import android.widget.ImageView;
        import android.widget.ListView;
        import android.widget.RelativeLayout;
        import android.widget.ScrollView;
        import android.widget.TextView;

        import java.text.SimpleDateFormat;
        import java.util.Date;
        import java.util.List;


public class ServiceTerm_Activity extends AppCompatActivity {
    RelativeLayout RL_nothing;
    ListView listview;
    Toolbar myToolbar;
    TextView title, tv_message, time, tv_nothing;
    TextView tv_agree;
    RelativeLayout rl_checkagree;
    ImageView icon;
    Integer count;
    FloatingActionButton fab;
    private String HCID,strAccountname;
    private Context context;
    private List<RequestActivation> listRequestActivation, newlist;
    private RequestActivationDAO raDAO;
    private CheckBox checkBox;
    private Boolean isAgree;
    private String agreedon;
    private Toolbar.OnMenuItemClickListener onMenuItemClick = new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.hclist:
                    menuItem.setVisible(false);
                    Intent i = new Intent(ServiceTerm_Activity.this, HCList.class);
                    startActivity(i);
                    break;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_term);
        context = this;
        //HCID = SharedPreferencesHelper.getSharedPreferencesString(context, SharedPreferencesHelper.SharedPreferencesKeys.key100, "");
        HCID = Utils.setMyHCID(context);
        agreedon=getResources().getString(R.string.dialog_iagreedon);

        myToolbar = (Toolbar) findViewById(R.id.my_toolbar); // Attaching the layout to the toolbar object
        setSupportActionBar(myToolbar);   // Setting toolbar as the ActionBar with setSupportActionBar() call
        getSupportActionBar();

        myToolbar.setOnMenuItemClickListener(onMenuItemClick);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        ScrollView scrollView=(ScrollView) findViewById(R.id.scrollView);
        tv_agree=(TextView)findViewById(R.id.tv_agree);
        rl_checkagree=(RelativeLayout) findViewById(R.id.rl_checkagree);
        checkBox=(CheckBox)findViewById(R.id.checkbox);
        Long agree_time= SharedPreferencesHelper.getSharedPreferencesLong(getApplicationContext(), SharedPreferencesHelper.SharedPreferencesKeys.key108, 0l);
        if(agree_time>0){
            setAgreedView(agree_time);
        }else{
            isAgree=false;
            scrollView.getViewTreeObserver()
                    .addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
                        @Override
                        public void onScrollChanged() {
                            if (scrollView.getChildAt(0).getBottom()
                                    <= (scrollView.getHeight() + scrollView.getScrollY())) {
                                rl_checkagree.setVisibility(View.VISIBLE);
                                //scroll view is at bottom
                            } else {
                                //scroll view is not at bottom
                                if(!isAgree){
                                    rl_checkagree.setVisibility(View.INVISIBLE);
                                }
                            }
                        }
                    });
            checkBox.setOnCheckedChangeListener(chklistener);
        }


    }

private void setAgreedView(Long agree_time){
    isAgree=true;
    rl_checkagree.setVisibility(View.VISIBLE);
    tv_agree.setText(agreedon+" "+Utils.ConvertTimeFormat(agree_time));
    checkBox.setVisibility(View.GONE);
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_ralist, menu);
        //menu.getItem(0).setVisible(true);
        return true;
    }
    private CheckBox.OnCheckedChangeListener chklistener = new CheckBox.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView,
                                     boolean isChecked) {
            // TODO Auto-generated method stub
            if (checkBox.isChecked()) {
                setAgreedView(new Date().getTime());
                SharedPreferencesHelper.putSharedPreferencesLong(getApplicationContext(), SharedPreferencesHelper.SharedPreferencesKeys.key108, new Date().getTime());
            } else {
                isAgree=false;
                SharedPreferencesHelper.putSharedPreferencesLong(getApplicationContext(), SharedPreferencesHelper.SharedPreferencesKeys.key108, 0l);
            }

        }

    };

/*
    public interface ScrollViewListener {
        void onScrollChanged(ScrollViewExt scrollView,
                             int x, int y, int oldx, int oldy);
    }*/

}